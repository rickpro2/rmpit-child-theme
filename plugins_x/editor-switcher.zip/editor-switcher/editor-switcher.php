<?php
/**
 * Plugin Name: Editor Switcher
 * Description: Allows users to switch between the Classic Editor and the Gutenberg Editor.
 * Version: 1.0
 * Author: Rickie Proctor
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class EditorSwitcher {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_filter('use_block_editor_for_post', [$this, 'switch_editor'], 10, 2);
    }

    public function add_settings_page() {
        add_options_page(
            'Editor Switcher Settings',
            'Editor Switcher',
            'manage_options',
            'editor-switcher',
            [$this, 'settings_page']
        );
    }

    public function register_settings() {
        register_setting('editor_switcher_settings', 'editor_switcher_default_editor');
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Editor Switcher Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('editor_switcher_settings');
                do_settings_sections('editor_switcher_settings');
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Default Editor</th>
                        <td>
                            <select name="editor_switcher_default_editor" id="editor_switcher_default_editor">
                                <option value="classic" <?php selected(get_option('editor_switcher_default_editor'), 'classic'); ?>>Classic Editor</option>
                                <option value="block" <?php selected(get_option('editor_switcher_default_editor'), 'block'); ?>>Gutenberg Editor</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function switch_editor($use_block_editor, $post) {
        $default_editor = get_option('editor_switcher_default_editor', 'block');
        return $default_editor === 'block';
    }
}

new EditorSwitcher();