/**
 * Internal dependencies
 */
import './register-reports';
