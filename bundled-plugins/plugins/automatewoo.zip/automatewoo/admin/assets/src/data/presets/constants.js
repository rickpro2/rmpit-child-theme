export const STORE_NAME = 'automatewoo/presets';
