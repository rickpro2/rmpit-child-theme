export const AW_NAMESPACE = '/automatewoo';
