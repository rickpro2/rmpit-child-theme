/**
 * Internal dependencies
 */
import './presets';

export { STORE_NAME as PRESETS_STORE_NAME } from './presets/constants';
