<?php
// phpcs:ignoreFile

/**
 * Contains deprecated functions.
 *
 * @package AutomateWoo
 */

defined( 'ABSPATH' ) || exit;

