<?php

namespace AutomateWoo\Entity;

/**
 * @since 5.1.0
 */
interface WorkflowTiming {

	/**
	 * @return string
	 */
	public function get_type();
}
