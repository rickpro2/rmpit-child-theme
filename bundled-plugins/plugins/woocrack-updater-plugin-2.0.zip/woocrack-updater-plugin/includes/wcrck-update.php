<?php if (!defined("ABSPATH")) {
    exit();
}
class WooCrack_Updater_Plugin_Update_API_Check
{
    protected static $_instance = null;
    public static function instance(
        $upgrade_url,
        $plugin_name,
        $product_id,
        $api_key,
        $activation_email,
        $renew_license_url,
        $instance,
        $domain,
        $software_version,
        $plugin_or_theme,
        $text_domain,
        $extra = ""
    ) {
        if (is_null(self::$_instance)) {
            self::$_instance = new self(
                $upgrade_url,
                $plugin_name,
                $product_id,
                $api_key,
                $activation_email,
                $renew_license_url,
                $instance,
                $domain,
                $software_version,
                $plugin_or_theme,
                $text_domain,
                $extra
            );
        }
        return self::$_instance;
    }
    private $upgrade_url;
    private $plugin_name;
    private $product_id;
    private $api_key;
    private $activation_email;
    private $renew_license_url;
    private $instance;
    private $domain;
    private $software_version;
    private $plugin_or_theme;
    private $text_domain;
    private $extra;
    public function __construct(
        $upgrade_url,
        $plugin_name,
        $product_id,
        $api_key,
        $activation_email,
        $renew_license_url,
        $instance,
        $domain,
        $software_version,
        $plugin_or_theme,
        $text_domain,
        $extra
    ) {
        $this->upgrade_url = $upgrade_url;
        $this->plugin_name = $plugin_name;
        $this->product_id = $product_id;
        $this->api_key = $api_key;
        $this->activation_email = $activation_email;
        $this->renew_license_url = $renew_license_url;
        $this->instance = $instance;
        $this->domain = $domain;
        $this->software_version = $software_version;
        $this->text_domain = $text_domain;
        $this->extra = $extra;
        if (strpos($this->plugin_name, ".php") !== 0) {
            $this->slug = dirname($this->plugin_name);
        } else {
            $this->slug = $this->plugin_name;
        }
        $this->plugin_or_theme = $plugin_or_theme;
        if ($this->plugin_or_theme == "plugin") {
            add_filter("pre_set_site_transient_update_plugins", [
                $this,
                "update_check",
            ]);
            add_filter("plugins_api", [$this, "request"], 10, 3);
        } elseif ($this->plugin_or_theme == "theme") {
            add_filter("pre_set_site_transient_update_themes", [
                $this,
                "update_check",
            ]);
        }
    }
    private function create_upgrade_api_url($args)
    {
        $upgrade_url = add_query_arg(
            "wc-api",
            "upgrade-api",
            $this->upgrade_url
        );
        return $upgrade_url . "&" . http_build_query($args);
    }
    public function update_check($transient)
    {
        if (empty($transient->checked)) {
            return $transient;
        }
        $args = [
            "request" => "pluginupdatecheck",
            "slug" => $this->slug,
            "plugin_name" => $this->plugin_name,
            "version" => $this->software_version,
            "product_id" => $this->product_id,
            "api_key" => $this->api_key,
            "activation_email" => $this->activation_email,
            "instance" => $this->instance,
            "domain" => $this->domain,
            "software_version" => $this->software_version,
            "extra" => $this->extra,
        ];
        $response = $this->plugin_information($args);
        $this->check_response_for_errors($response);
        if (isset($response) && is_object($response) && $response !== false) {
            $new_ver = (string) $response->new_version;
            $curr_ver = (string) $this->software_version;
        }
        if (isset($new_ver) && isset($curr_ver)) {
            if (
                $response !== false &&
                version_compare($new_ver, $curr_ver, ">")
            ) {
                if ($this->plugin_or_theme == "plugin") {
                    $transient->response[$this->plugin_name] = $response;
                } elseif ($this->plugin_or_theme == "theme") {
                    $transient->response[$this->plugin_name]["new_version"] =
                        $response->new_version;
                    $transient->response[$this->plugin_name]["url"] =
                        $response->url;
                    $transient->response[$this->plugin_name]["package"] =
                        $response->package;
                }
            }
        }
        return $transient;
        var_export($args);
    }
    public function plugin_information($args)
    {
        $target_url = esc_url_raw($this->create_upgrade_api_url($args));
        $request = wp_safe_remote_get($target_url);
        if (
            is_wp_error($request) ||
            wp_remote_retrieve_response_code($request) != 200
        ) {
            return false;
        }
        $response = unserialize(wp_remote_retrieve_body($request));
        if (is_object($response)) {
            return $response;
        } else {
            return false;
        }
    }
    public function request($false, $action, $args)
    {
        if ($this->plugin_or_theme == "plugin") {
            $version = get_site_transient("update_plugins");
        } elseif ($this->plugin_or_theme == "theme") {
            $version = get_site_transient("update_themes");
        }
        if (isset($args->slug)) {
            if ($args->slug != $this->slug) {
                return $false;
            }
        } else {
            return $false;
        }
        $args = [
            "request" => "plugininformation",
            "plugin_name" => $this->plugin_name,
            "version" => $this->software_version,
            "product_id" => $this->product_id,
            "api_key" => $this->api_key,
            "activation_email" => $this->activation_email,
            "instance" => $this->instance,
            "domain" => $this->domain,
            "software_version" => $this->software_version,
            "extra" => $this->extra,
        ];
        $response = $this->plugin_information($args);
        if (isset($response) && is_object($response) && $response !== false) {
            return $response;
        }
    }
    public function check_response_for_errors($response)
    {
        if (!empty($response)) {
            if (
                isset($response->errors["no_key"]) &&
                $response->errors["no_key"] == "no_key" &&
                isset($response->errors["no_subscription"]) &&
                $response->errors["no_subscription"] == "no_subscription"
            ) {
                add_action("admin_notices", [$this, "no_key_error_notice"]);
                add_action("admin_notices", [
                    $this,
                    "no_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["exp_license"]) &&
                $response->errors["exp_license"] == "exp_license"
            ) {
                add_action("admin_notices", [
                    $this,
                    "expired_license_error_notice",
                ]);
            } elseif (
                isset($response->errors["hold_subscription"]) &&
                $response->errors["hold_subscription"] == "hold_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "on_hold_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["cancelled_subscription"]) &&
                $response->errors["cancelled_subscription"] ==
                    "cancelled_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "cancelled_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["exp_subscription"]) &&
                $response->errors["exp_subscription"] == "exp_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "expired_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["suspended_subscription"]) &&
                $response->errors["suspended_subscription"] ==
                    "suspended_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "suspended_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["pending_subscription"]) &&
                $response->errors["pending_subscription"] ==
                    "pending_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "pending_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["trash_subscription"]) &&
                $response->errors["trash_subscription"] == "trash_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "trash_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["no_subscription"]) &&
                $response->errors["no_subscription"] == "no_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "no_subscription_error_notice",
                ]);
            } elseif (
                isset($response->errors["no_activation"]) &&
                $response->errors["no_activation"] == "no_activation"
            ) {
                add_action("admin_notices", [
                    $this,
                    "no_activation_error_notice",
                ]);
                $update = [
                    WK()->ame_api_key => "",
                    WK()->ame_activation_email => "",
                ];
                $merge_options = array_merge(WK()->ame_options, $update);
                update_option(WK()->ame_data_key, $merge_options);
                update_option(WK()->ame_activated_key, "Deactivated");
            } elseif (
                isset($response->errors["no_key"]) &&
                $response->errors["no_key"] == "no_key"
            ) {
                add_action("admin_notices", [$this, "no_key_error_notice"]);
            } elseif (
                isset($response->errors["download_revoked"]) &&
                $response->errors["download_revoked"] == "download_revoked"
            ) {
                add_action("admin_notices", [
                    $this,
                    "download_revoked_error_notice",
                ]);
            } elseif (
                isset($response->errors["switched_subscription"]) &&
                $response->errors["switched_subscription"] ==
                    "switched_subscription"
            ) {
                add_action("admin_notices", [
                    $this,
                    "switched_subscription_error_notice",
                ]);
            }
        }
    }
    public function expired_license_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The license key for %s has expired. You can reactivate or purchase a license key from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function on_hold_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The subscription for %s is on-hold. You can reactivate the subscription from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function cancelled_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The subscription for %s has been cancelled. You can renew the subscription from your account <a href="%s" target="_blank">dashboard</a>. A new license key will be emailed to you after your order has been completed.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function expired_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The subscription for %s has expired. You can reactivate the subscription from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function suspended_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The subscription for %s has been suspended. You can reactivate the subscription from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function pending_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The subscription for %s is still pending. You can check on the status of the subscription from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function trash_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'The subscription for %s has been placed in the trash and will be deleted soon. You can purchase a new subscription from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function no_subscription_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    'A subscription for %s could not be found. You can purchase a subscription from your account <a href="%s" target="_blank">dashboard</a>.',
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->renew_license_url
        );
    }
    public function no_key_error_notice($message)
    {
    }
    public function download_revoked_error_notice($message)
    {
  
    }
    public function no_activation_error_notice($message)
    {
        echo sprintf(
            '<div id="message" class="error"><p>' .
                __(
                    "%s has not been activated. Go to the settings page and enter the license key and license email to activate %s.",
                    $this->text_domain
                ) .
                "</p></div>",
            $this->product_id,
            $this->product_id
        );
    }
    public function switched_subscription_error_notice($message)
    {
    }
}
