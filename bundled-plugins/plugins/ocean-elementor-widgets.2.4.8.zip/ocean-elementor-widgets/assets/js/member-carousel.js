(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerWidget = exports.isElement = exports.getSiblings = exports.visible = exports.offset = exports.fadeToggle = exports.fadeOut = exports.fadeIn = exports.slideToggle = exports.slideUp = exports.slideDown = void 0;

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var slideDown = function slideDown(element) {
  var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  var display = window.getComputedStyle(element).display;

  if (display === "none") {
    display = "block";
  }

  element.style.transitionProperty = "height";
  element.style.transitionDuration = "".concat(duration, "ms");
  element.style.opacity = 0;
  element.style.display = display;
  var height = element.offsetHeight;
  element.style.height = 0;
  element.style.opacity = 1;
  element.style.overflow = "hidden";
  setTimeout(function () {
    element.style.height = "".concat(height, "px");
  }, 5);
  window.setTimeout(function () {
    element.style.removeProperty("height");
    element.style.removeProperty("overflow");
    element.style.removeProperty("transition-duration");
    element.style.removeProperty("transition-property");
    element.style.removeProperty("opacity");
  }, duration + 50);
};

exports.slideDown = slideDown;

var slideUp = function slideUp(element) {
  var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  element.style.boxSizing = "border-box";
  element.style.transitionProperty = "height, margin";
  element.style.transitionDuration = "".concat(duration, "ms");
  element.style.height = "".concat(element.offsetHeight, "px");
  element.style.marginTop = 0;
  element.style.marginBottom = 0;
  element.style.overflow = "hidden";
  setTimeout(function () {
    element.style.height = 0;
  }, 5);
  window.setTimeout(function () {
    element.style.display = "none";
    element.style.removeProperty("height");
    element.style.removeProperty("margin-top");
    element.style.removeProperty("margin-bottom");
    element.style.removeProperty("overflow");
    element.style.removeProperty("transition-duration");
    element.style.removeProperty("transition-property");
  }, duration + 50);
};

exports.slideUp = slideUp;

var slideToggle = function slideToggle(element, duration) {
  window.getComputedStyle(element).display === "none" ? slideDown(element, duration) : slideUp(element, duration);
};

exports.slideToggle = slideToggle;

var fadeIn = function fadeIn(element) {
  var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = {
    duration: 300,
    display: null,
    opacity: 1,
    callback: null
  };
  Object.assign(options, _options);
  element.style.opacity = 0;
  element.style.display = options.display || "block";
  setTimeout(function () {
    element.style.transition = "".concat(options.duration, "ms opacity ease");
    element.style.opacity = options.opacity;
  }, 5);
  setTimeout(function () {
    element.style.removeProperty("transition");
    !!options.callback && options.callback();
  }, options.duration + 50);
};

exports.fadeIn = fadeIn;

var fadeOut = function fadeOut(element) {
  var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = {
    duration: 300,
    display: null,
    opacity: 0,
    callback: null
  };
  Object.assign(options, _options);
  element.style.opacity = 1;
  element.style.display = options.display || "block";
  setTimeout(function () {
    element.style.transition = "".concat(options.duration, "ms opacity ease");
    element.style.opacity = options.opacity;
  }, 5);
  setTimeout(function () {
    element.style.display = "none";
    element.style.removeProperty("transition");
    !!options.callback && options.callback();
  }, options.duration + 50);
};

exports.fadeOut = fadeOut;

var fadeToggle = function fadeToggle(element, options) {
  window.getComputedStyle(element).display === "none" ? fadeIn(element, options) : fadeOut(element, options);
};

exports.fadeToggle = fadeToggle;

var offset = function offset(element) {
  if (!element.getClientRects().length) {
    return {
      top: 0,
      left: 0
    };
  } // Get document-relative position by adding viewport scroll to viewport-relative gBCR


  var rect = element.getBoundingClientRect();
  var win = element.ownerDocument.defaultView;
  return {
    top: rect.top + win.pageYOffset,
    left: rect.left + win.pageXOffset
  };
};

exports.offset = offset;

var visible = function visible(element) {
  if (!element) {
    return false;
  }

  return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
};

exports.visible = visible;

var getSiblings = function getSiblings(e) {
  // for collecting siblings
  var siblings = []; // if no parent, return no sibling

  if (!e.parentNode) {
    return siblings;
  } // first child of the parent node


  var sibling = e.parentNode.firstChild; // collecting siblings

  while (sibling) {
    if (sibling.nodeType === 1 && sibling !== e) {
      siblings.push(sibling);
    }

    sibling = sibling.nextSibling;
  }

  return siblings;
}; // Returns true if it is a DOM element


exports.getSiblings = getSiblings;

var isElement = function isElement(o) {
  return (typeof HTMLElement === "undefined" ? "undefined" : _typeof(HTMLElement)) === "object" ? o instanceof HTMLElement // DOM2
  : o && _typeof(o) === "object" && o !== null && o.nodeType === 1 && typeof o.nodeName === "string";
};

exports.isElement = isElement;

var registerWidget = function registerWidget(className, widgetName) {
  var skin = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "default";

  if (!(className || widgetName)) {
    return;
  }
  /**
   * Because Elementor plugin uses jQuery custom event,
   * We also have to use jQuery to use this event
   */


  jQuery(window).on("elementor/frontend/init", function () {
    var addHandler = function addHandler($element) {
      elementorFrontend.elementsHandler.addHandler(className, {
        $element: $element
      });
    };

    elementorFrontend.hooks.addAction("frontend/element_ready/".concat(widgetName, ".").concat(skin), addHandler);
  });
};

exports.registerWidget = registerWidget;

},{}],2:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _get(target, property, receiver) { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get; } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(receiver); } return desc.value; }; } return _get(target, property, receiver || target); }

function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var OEW_Carousel = /*#__PURE__*/function (_elementorModules$fro) {
  _inherits(OEW_Carousel, _elementorModules$fro);

  var _super = _createSuper(OEW_Carousel);

  function OEW_Carousel() {
    _classCallCheck(this, OEW_Carousel);

    return _super.apply(this, arguments);
  }

  _createClass(OEW_Carousel, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      return {
        selectors: {
          carousel: ".oew-carousel-container",
          carouselNextBtn: ".swiper-button-next-".concat(this.getID()),
          carouselPrevBtn: ".swiper-button-prev-".concat(this.getID()),
          carouselPagination: ".swiper-pagination-".concat(this.getID())
        },
        effect: "slide",
        loop: false,
        autoplay: 0,
        speed: 400,
        navigation: false,
        pagination: false,
        centeredSlides: false,
        pauseOnHover: false,
        slidesPerView: {
          widescreen: 3,
          desktop: 3,
          laptop: 3,
          tablet: 2,
          tablet_extra: 2,
          mobile: 1,
          mobile_extra: 1
        },
        slidesPerGroup: {
          widescreen: 3,
          desktop: 3,
          laptop: 3,
          tablet: 2,
          tablet_extra: 2,
          mobile: 1,
          mobile_extra: 1
        },
        spaceBetween: {
          widescreen: 10,
          desktop: 10,
          laptop: 10,
          tablet: 10,
          tablet_extra: 10,
          mobile: 10,
          mobile_extra: 10
        },
        swiperInstance: null
      };
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      var element = this.$element.get(0);
      var selectors = this.getSettings("selectors");
      return {
        carousel: element.querySelector(selectors.carousel),
        carouselNextBtn: element.querySelectorAll(selectors.carouselNextBtn),
        carouselPrevBtn: element.querySelectorAll(selectors.carouselPrevBtn),
        carouselPagination: element.querySelectorAll(selectors.carouselPagination)
      };
    }
  }, {
    key: "onInit",
    value: function onInit() {
      var _get2;

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      (_get2 = _get(_getPrototypeOf(OEW_Carousel.prototype), "onInit", this)).call.apply(_get2, [this].concat(args));

      this.widgetUniqueID = this.getID();

      if (this.getDefaultElements().carousel) {
        this.widgetSliderID = this.getDefaultElements().carousel.id;
      } // Only attempt to initialize if the carousel container exists


      if (!this.getDefaultElements().carousel) {
        return;
      }

      this.setUserSettings();
      this.initSwiper();
      this.setupEventListeners();
      this.updateCarouselStyles(this.getSettings());
    }
  }, {
    key: "setUserSettings",
    value: function setUserSettings() {
      var settings = this.getSettings();
      if (!this.elements.carousel) return; // Skip if no carousel container

      var userSettings = JSON.parse(this.elements.carousel.getAttribute("data-settings"));
      this.originalAutoplayEnabled = userSettings.autoplay && Number(userSettings.autoplay) > 0;
      var currentSettings = {
        effect: !!userSettings.effect ? userSettings.effect : settings.effect,
        loop: !!userSettings.loop ? Boolean(Number(userSettings.loop)) : settings.loop,
        autoplay: !!userSettings.autoplay ? Number(userSettings.autoplay) : settings.autoplay,
        speed: !!userSettings.speed ? Number(userSettings.speed) : settings.speed,
        navigation: !!userSettings.arrows ? Boolean(Number(userSettings.arrows)) : settings.navigation,
        pagination: !!userSettings.dots ? Boolean(Number(userSettings.dots)) : settings.pagination,
        pauseOnHover: !!userSettings["pause-on-hover"] ? JSON.parse(userSettings["pause-on-hover"]) : settings.pauseOnHover,
        slidesPerView: {
          widescreen: userSettings['items-widescreen'] !== undefined ? Number(userSettings['items-widescreen']) : settings.slidesPerView['widescreen'],
          desktop: userSettings['items'] !== undefined ? Number(userSettings['items']) : settings.slidesPerView['desktop'],
          laptop: userSettings['items-laptop'] !== undefined ? Number(userSettings['items-laptop']) : settings.slidesPerView['laptop'],
          tablet: userSettings['items-tablet'] !== undefined ? Number(userSettings['items-tablet']) : settings.slidesPerView['tablet'],
          tablet_extra: userSettings['items-tablet_extra'] !== undefined ? Number(userSettings['items-tablet_extra']) : settings.slidesPerView['tablet_extra'],
          mobile: userSettings['items-mobile'] !== undefined ? Number(userSettings['items-mobile']) : settings.slidesPerView['mobile'],
          mobile_extra: userSettings['items-mobile_extra'] !== undefined ? Number(userSettings['items-mobile_extra']) : settings.slidesPerView['mobile_extra']
        },
        slidesPerGroup: {
          widescreen: !!userSettings['slides-widescreen'] ? Number(userSettings['slides-widescreen']) : settings.slidesPerGroup.widescreen,
          desktop: !!userSettings['slides'] ? Number(userSettings['slides']) : settings.slidesPerGroup.desktop,
          laptop: !!userSettings['slides-laptop'] ? Number(userSettings['slides-laptop']) : settings.slidesPerGroup.laptop,
          tablet: !!userSettings["slides-tablet"] ? Number(userSettings["slides-tablet"]) : settings.slidesPerGroup.tablet,
          tablet_extra: !!userSettings["slides-tablet_extra"] ? Number(userSettings["slides-tablet_extra"]) : settings.slidesPerGroup.tablet_extra,
          mobile: !!userSettings["slides-mobile"] ? Number(userSettings["slides-mobile"]) : settings.slidesPerGroup.mobile,
          mobile_extra: !!userSettings["slides-mobile_extra"] ? Number(userSettings["slides-mobile_extra"]) : settings.slidesPerGroup.mobile_extra
        },
        spaceBetween: {
          widescreen: userSettings['margin-widescreen'] !== undefined ? Number(userSettings['margin-widescreen']) : settings.spaceBetween.widescreen,
          desktop: userSettings['margin'] !== undefined ? Number(userSettings['margin']) : settings.spaceBetween.desktop,
          laptop: userSettings['margin-laptop'] !== undefined ? Number(userSettings['margin-laptop']) : settings.spaceBetween.laptop,
          tablet: userSettings["margin-tablet"] !== undefined ? Number(userSettings["margin-tablet"]) : settings.spaceBetween.tablet,
          tablet_extra: userSettings["margin-tablet_extra"] !== undefined ? Number(userSettings["margin-tablet_extra"]) : settings.spaceBetween.tablet_extra,
          mobile: userSettings["margin-mobile"] !== undefined ? Number(userSettings["margin-mobile"]) : settings.spaceBetween.mobile,
          mobile_extra: userSettings["margin-mobile_extra"] !== undefined ? Number(userSettings["margin-mobile_extra"]) : settings.spaceBetween.mobile_extra
        }
      };
      currentSettings.centeredSlides = currentSettings.effect === "coverflow" ? true : settings.centeredSlides;
      this.setSettings(currentSettings);
    }
  }, {
    key: "updateCarouselStyles",
    value: function updateCarouselStyles(settings) {
      var spaceBetween = settings.spaceBetween;

      if (spaceBetween.desktop === 0) {
        this.elements.carousel.querySelectorAll('.oew-carousel-slide').forEach(function (slide) {
          slide.style.marginRight = "0px";
        });
      }

      if (spaceBetween.tablet === 0) {
        this.elements.carousel.querySelectorAll('.oew-carousel-slide').forEach(function (slide) {
          slide.style.marginRight = "0px";
        });
      }

      if (spaceBetween.mobile === 0) {
        this.elements.carousel.querySelectorAll('.oew-carousel-slide').forEach(function (slide) {
          slide.style.marginRight = "0px";
        });
      }
    }
  }, {
    key: "initSwiper",
    value: function initSwiper() {
      var swiper = new Swiper(this.elements.carousel, this.swiperOptions());
      this.setSettings({
        swiperInstance: swiper
      });
    }
  }, {
    key: "swiperOptions",
    value: function swiperOptions() {
      var settings = this.getSettings();
      var swiperOptions = {
        direction: "horizontal",
        effect: settings.effect,
        loop: settings.loop,
        speed: settings.speed,
        centeredSlides: settings.centeredSlides,
        autoHeight: true,
        autoplay: !settings.autoplay ? false : {
          delay: settings.autoplay
        },
        navigation: !settings.navigation ? false : {
          nextEl: settings.selectors.carouselNextBtn,
          prevEl: settings.selectors.carouselPrevBtn
        },
        pagination: !settings.pagination ? false : {
          el: settings.selectors.carouselPagination,
          clickable: true
        }
      }; // Fetch Elementor's responsive breakpoints

      var breakpoints = elementorFrontend.config.responsive.activeBreakpoints;
      var breakpointsBootstrap = elementorFrontend.config.breakpoints;

      if (settings.effect === "fade") {
        swiperOptions.items = 1;
      } else {
        swiperOptions.breakpoints = {};
        var devicesBreakPoints = [];

        for (var deviceName in breakpoints) {
          var max_width = breakpoints[deviceName]['default_value'];

          if (breakpoints[deviceName]['value'] !== undefined) {
            max_width = breakpoints[deviceName]['value'];
          }

          devicesBreakPoints.push({
            'label': deviceName,
            'max_width': max_width
          });
        }

        devicesBreakPoints.sort(function (a, b) {
          return a.max_width - b.max_width;
        });
        var tmpSlidesPerView = 0;
        var desktopWidth = breakpointsBootstrap.lg;

        for (var _i = 0, _devicesBreakPoints = devicesBreakPoints; _i < _devicesBreakPoints.length; _i++) {
          var devicesBreakPointItem = _devicesBreakPoints[_i];
          var responsivKeySetting = devicesBreakPointItem.label;

          if (settings.slidesPerView[responsivKeySetting] !== undefined) {
            swiperOptions.breakpoints[tmpSlidesPerView] = {
              slidesPerView: settings.slidesPerView[responsivKeySetting],
              slidesPerGroup: settings.slidesPerGroup[responsivKeySetting],
              spaceBetween: settings.spaceBetween[responsivKeySetting]
            };

            if (responsivKeySetting === 'widescreen') {
              desktopWidth = tmpSlidesPerView;
              tmpSlidesPerView = devicesBreakPointItem['max_width'];
              swiperOptions.breakpoints[tmpSlidesPerView] = {
                slidesPerView: settings.slidesPerView[responsivKeySetting],
                slidesPerGroup: settings.slidesPerGroup[responsivKeySetting],
                spaceBetween: settings.spaceBetween[responsivKeySetting]
              };
            } else {
              tmpSlidesPerView = parseInt(devicesBreakPointItem['max_width']) + 1;
              desktopWidth = tmpSlidesPerView;
            }
          }
        }

        swiperOptions.breakpoints[desktopWidth] = {
          slidesPerView: settings.slidesPerView['desktop'],
          slidesPerGroup: settings.slidesPerGroup['desktop'],
          spaceBetween: settings.spaceBetween['desktop']
        };
      }

      return swiperOptions;
    }
  }, {
    key: "setupEventListeners",
    value: function setupEventListeners() {
      var _this = this;

      // If autoplay pauseOnHover is enabled
      if (this.originalAutoplayEnabled && this.getSettings("pauseOnHover") && this.elements.carousel) {
        this.elements.carousel.addEventListener("mouseenter", this.pauseSwiper.bind(this));
        this.elements.carousel.addEventListener("mouseleave", this.resumeSwiper.bind(this));
      } // Use jQuery event binding on document.body


      jQuery(document.body).on('updated_wc_div', function () {
        setTimeout(function () {
          _this.onCartUpdated();
        }, 100);
      });
    }
  }, {
    key: "onCartUpdated",
    value: function onCartUpdated() {
      var swiperInstance = this.getSettings("swiperInstance");

      if (swiperInstance) {
        swiperInstance.destroy(true, true);
        this.setSettings({
          swiperInstance: null
        });
      }

      var $slider = jQuery('#' + this.widgetSliderID);

      if (!$slider || $slider.length === 0) {
        return;
      }

      var $widgetContainer = $slider.closest('.elementor-widget-oew-woo-slider');
      this.$element = $widgetContainer.length ? $widgetContainer : $slider;
      this.elements = this.getDefaultElements();

      if (!this.elements.carousel) {
        return;
      }

      this.setUserSettings();
      this.initSwiper();
      this.updateCarouselStyles(this.getSettings());
    }
  }, {
    key: "pauseSwiper",
    value: function pauseSwiper() {
      if (this.getSettings("swiperInstance").autoplay.running) {
        this.getSettings("swiperInstance").autoplay.stop();
      }
    }
  }, {
    key: "resumeSwiper",
    value: function resumeSwiper() {
      if (!this.getSettings("swiperInstance").autoplay.running) {
        this.getSettings("swiperInstance").autoplay.start();
      }
    }
  }]);

  return OEW_Carousel;
}(elementorModules.frontend.handlers.Base);

var _default = OEW_Carousel;
exports["default"] = _default;

},{}],3:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var _utils = require("../lib/utils");

var _carousel = _interopRequireDefault(require("./base/carousel"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var OEW_MemberCarousel = /*#__PURE__*/function (_OEW_Carousel) {
  _inherits(OEW_MemberCarousel, _OEW_Carousel);

  var _super = _createSuper(OEW_MemberCarousel);

  function OEW_MemberCarousel() {
    _classCallCheck(this, OEW_MemberCarousel);

    return _super.apply(this, arguments);
  }

  return OEW_MemberCarousel;
}(_carousel["default"]);

(0, _utils.registerWidget)(OEW_MemberCarousel, "oew-member-carousel");

},{"../lib/utils":1,"./base/carousel":2}]},{},[3])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJhc3NldHMvc3JjL2pzL2xpYi91dGlscy5qcyIsImFzc2V0cy9zcmMvanMvd2lkZ2V0cy9iYXNlL2Nhcm91c2VsLmpzIiwiYXNzZXRzL3NyYy9qcy93aWRnZXRzL21lbWJlci1jYXJvdXNlbC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7OztBQ0FPLElBQU0sU0FBUyxHQUFHLFNBQVosU0FBWSxDQUFDLE9BQUQsRUFBNkI7QUFBQSxNQUFuQixRQUFtQix1RUFBUixHQUFRO0FBQ2xELE1BQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxnQkFBUCxDQUF3QixPQUF4QixFQUFpQyxPQUEvQzs7QUFFQSxNQUFJLE9BQU8sS0FBSyxNQUFoQixFQUF3QjtBQUNwQixJQUFBLE9BQU8sR0FBRyxPQUFWO0FBQ0g7O0FBRUQsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLEdBQW1DLFFBQW5DO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLGFBQXNDLFFBQXRDO0FBRUEsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsQ0FBeEI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixPQUF4QjtBQUNBLE1BQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxZQUFyQjtBQUVBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxNQUFkLEdBQXVCLENBQXZCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsQ0FBeEI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsUUFBZCxHQUF5QixRQUF6QjtBQUVBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsTUFBZCxhQUEwQixNQUExQjtBQUNILEdBRlMsRUFFUCxDQUZPLENBQVY7QUFJQSxFQUFBLE1BQU0sQ0FBQyxVQUFQLENBQWtCLFlBQU07QUFDcEIsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsUUFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixVQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLHFCQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLHFCQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFNBQTdCO0FBQ0gsR0FORCxFQU1HLFFBQVEsR0FBRyxFQU5kO0FBT0gsQ0E3Qk07Ozs7QUErQkEsSUFBTSxPQUFPLEdBQUcsU0FBVixPQUFVLENBQUMsT0FBRCxFQUE2QjtBQUFBLE1BQW5CLFFBQW1CLHVFQUFSLEdBQVE7QUFDaEQsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFNBQWQsR0FBMEIsWUFBMUI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsa0JBQWQsR0FBbUMsZ0JBQW5DO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLGFBQXNDLFFBQXRDO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE1BQWQsYUFBMEIsT0FBTyxDQUFDLFlBQWxDO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFNBQWQsR0FBMEIsQ0FBMUI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsWUFBZCxHQUE2QixDQUE3QjtBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxRQUFkLEdBQXlCLFFBQXpCO0FBRUEsRUFBQSxVQUFVLENBQUMsWUFBTTtBQUNiLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxNQUFkLEdBQXVCLENBQXZCO0FBQ0gsR0FGUyxFQUVQLENBRk8sQ0FBVjtBQUlBLEVBQUEsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsWUFBTTtBQUNwQixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixNQUF4QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFFBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsWUFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixlQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFVBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIscUJBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIscUJBQTdCO0FBQ0gsR0FSRCxFQVFHLFFBQVEsR0FBRyxFQVJkO0FBU0gsQ0F0Qk07Ozs7QUF3QkEsSUFBTSxXQUFXLEdBQUcsU0FBZCxXQUFjLENBQUMsT0FBRCxFQUFVLFFBQVYsRUFBdUI7QUFDOUMsRUFBQSxNQUFNLENBQUMsZ0JBQVAsQ0FBd0IsT0FBeEIsRUFBaUMsT0FBakMsS0FBNkMsTUFBN0MsR0FBc0QsU0FBUyxDQUFDLE9BQUQsRUFBVSxRQUFWLENBQS9ELEdBQXFGLE9BQU8sQ0FBQyxPQUFELEVBQVUsUUFBVixDQUE1RjtBQUNILENBRk07Ozs7QUFJQSxJQUFNLE1BQU0sR0FBRyxTQUFULE1BQVMsQ0FBQyxPQUFELEVBQTRCO0FBQUEsTUFBbEIsUUFBa0IsdUVBQVAsRUFBTzs7QUFDOUMsTUFBTSxPQUFPLEdBQUc7QUFDWixJQUFBLFFBQVEsRUFBRSxHQURFO0FBRVosSUFBQSxPQUFPLEVBQUUsSUFGRztBQUdaLElBQUEsT0FBTyxFQUFFLENBSEc7QUFJWixJQUFBLFFBQVEsRUFBRTtBQUpFLEdBQWhCO0FBT0EsRUFBQSxNQUFNLENBQUMsTUFBUCxDQUFjLE9BQWQsRUFBdUIsUUFBdkI7QUFFQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixDQUF4QjtBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLE9BQU8sQ0FBQyxPQUFSLElBQW1CLE9BQTNDO0FBRUEsRUFBQSxVQUFVLENBQUMsWUFBTTtBQUNiLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxVQUFkLGFBQThCLE9BQU8sQ0FBQyxRQUF0QztBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLE9BQU8sQ0FBQyxPQUFoQztBQUNILEdBSFMsRUFHUCxDQUhPLENBQVY7QUFLQSxFQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsWUFBN0I7QUFDQSxLQUFDLENBQUMsT0FBTyxDQUFDLFFBQVYsSUFBc0IsT0FBTyxDQUFDLFFBQVIsRUFBdEI7QUFDSCxHQUhTLEVBR1AsT0FBTyxDQUFDLFFBQVIsR0FBbUIsRUFIWixDQUFWO0FBSUgsQ0F0Qk07Ozs7QUF3QkEsSUFBTSxPQUFPLEdBQUcsU0FBVixPQUFVLENBQUMsT0FBRCxFQUE0QjtBQUFBLE1BQWxCLFFBQWtCLHVFQUFQLEVBQU87O0FBQy9DLE1BQU0sT0FBTyxHQUFHO0FBQ1osSUFBQSxRQUFRLEVBQUUsR0FERTtBQUVaLElBQUEsT0FBTyxFQUFFLElBRkc7QUFHWixJQUFBLE9BQU8sRUFBRSxDQUhHO0FBSVosSUFBQSxRQUFRLEVBQUU7QUFKRSxHQUFoQjtBQU9BLEVBQUEsTUFBTSxDQUFDLE1BQVAsQ0FBYyxPQUFkLEVBQXVCLFFBQXZCO0FBRUEsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsQ0FBeEI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixPQUFPLENBQUMsT0FBUixJQUFtQixPQUEzQztBQUVBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsVUFBZCxhQUE4QixPQUFPLENBQUMsUUFBdEM7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixPQUFPLENBQUMsT0FBaEM7QUFDSCxHQUhTLEVBR1AsQ0FITyxDQUFWO0FBS0EsRUFBQSxVQUFVLENBQUMsWUFBTTtBQUNiLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLE1BQXhCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsWUFBN0I7QUFDQSxLQUFDLENBQUMsT0FBTyxDQUFDLFFBQVYsSUFBc0IsT0FBTyxDQUFDLFFBQVIsRUFBdEI7QUFDSCxHQUpTLEVBSVAsT0FBTyxDQUFDLFFBQVIsR0FBbUIsRUFKWixDQUFWO0FBS0gsQ0F2Qk07Ozs7QUF5QkEsSUFBTSxVQUFVLEdBQUcsU0FBYixVQUFhLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBc0I7QUFDNUMsRUFBQSxNQUFNLENBQUMsZ0JBQVAsQ0FBd0IsT0FBeEIsRUFBaUMsT0FBakMsS0FBNkMsTUFBN0MsR0FBc0QsTUFBTSxDQUFDLE9BQUQsRUFBVSxPQUFWLENBQTVELEdBQWlGLE9BQU8sQ0FBQyxPQUFELEVBQVUsT0FBVixDQUF4RjtBQUNILENBRk07Ozs7QUFJQSxJQUFNLE1BQU0sR0FBRyxTQUFULE1BQVMsQ0FBQyxPQUFELEVBQWE7QUFDL0IsTUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFSLEdBQXlCLE1BQTlCLEVBQXNDO0FBQ2xDLFdBQU87QUFBRSxNQUFBLEdBQUcsRUFBRSxDQUFQO0FBQVUsTUFBQSxJQUFJLEVBQUU7QUFBaEIsS0FBUDtBQUNILEdBSDhCLENBSy9COzs7QUFDQSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMscUJBQVIsRUFBYjtBQUNBLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFSLENBQXNCLFdBQWxDO0FBQ0EsU0FBTztBQUNILElBQUEsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFMLEdBQVcsR0FBRyxDQUFDLFdBRGpCO0FBRUgsSUFBQSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUwsR0FBWSxHQUFHLENBQUM7QUFGbkIsR0FBUDtBQUlILENBWk07Ozs7QUFjQSxJQUFNLE9BQU8sR0FBRyxTQUFWLE9BQVUsQ0FBQyxPQUFELEVBQWE7QUFDaEMsTUFBSSxDQUFDLE9BQUwsRUFBYztBQUNWLFdBQU8sS0FBUDtBQUNIOztBQUVELFNBQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxXQUFSLElBQXVCLE9BQU8sQ0FBQyxZQUEvQixJQUErQyxPQUFPLENBQUMsY0FBUixHQUF5QixNQUExRSxDQUFSO0FBQ0gsQ0FOTTs7OztBQVFBLElBQU0sV0FBVyxHQUFHLFNBQWQsV0FBYyxDQUFDLENBQUQsRUFBTztBQUM5QjtBQUNBLE1BQU0sUUFBUSxHQUFHLEVBQWpCLENBRjhCLENBSTlCOztBQUNBLE1BQUksQ0FBQyxDQUFDLENBQUMsVUFBUCxFQUFtQjtBQUNmLFdBQU8sUUFBUDtBQUNILEdBUDZCLENBUzlCOzs7QUFDQSxNQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsVUFBRixDQUFhLFVBQTNCLENBVjhCLENBWTlCOztBQUNBLFNBQU8sT0FBUCxFQUFnQjtBQUNaLFFBQUksT0FBTyxDQUFDLFFBQVIsS0FBcUIsQ0FBckIsSUFBMEIsT0FBTyxLQUFLLENBQTFDLEVBQTZDO0FBQ3pDLE1BQUEsUUFBUSxDQUFDLElBQVQsQ0FBYyxPQUFkO0FBQ0g7O0FBRUQsSUFBQSxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQWxCO0FBQ0g7O0FBRUQsU0FBTyxRQUFQO0FBQ0gsQ0F0Qk0sQyxDQXdCUDs7Ozs7QUFDTyxJQUFNLFNBQVMsR0FBRyxTQUFaLFNBQVksQ0FBQyxDQUFELEVBQU87QUFDNUIsU0FBTyxRQUFPLFdBQVAseUNBQU8sV0FBUCxPQUF1QixRQUF2QixHQUNELENBQUMsWUFBWSxXQURaLENBQ3dCO0FBRHhCLElBRUQsQ0FBQyxJQUFJLFFBQU8sQ0FBUCxNQUFhLFFBQWxCLElBQThCLENBQUMsS0FBSyxJQUFwQyxJQUE0QyxDQUFDLENBQUMsUUFBRixLQUFlLENBQTNELElBQWdFLE9BQU8sQ0FBQyxDQUFDLFFBQVQsS0FBc0IsUUFGNUY7QUFHSCxDQUpNOzs7O0FBTUEsSUFBTSxjQUFjLEdBQUcsU0FBakIsY0FBaUIsQ0FBQyxTQUFELEVBQVksVUFBWixFQUE2QztBQUFBLE1BQXJCLElBQXFCLHVFQUFkLFNBQWM7O0FBQ3ZFLE1BQUksRUFBRSxTQUFTLElBQUksVUFBZixDQUFKLEVBQWdDO0FBQzVCO0FBQ0g7QUFFRDtBQUNKO0FBQ0E7QUFDQTs7O0FBQ0ksRUFBQSxNQUFNLENBQUMsTUFBRCxDQUFOLENBQWUsRUFBZixDQUFrQix5QkFBbEIsRUFBNkMsWUFBTTtBQUMvQyxRQUFNLFVBQVUsR0FBRyxTQUFiLFVBQWEsQ0FBQyxRQUFELEVBQWM7QUFDN0IsTUFBQSxpQkFBaUIsQ0FBQyxlQUFsQixDQUFrQyxVQUFsQyxDQUE2QyxTQUE3QyxFQUF3RDtBQUNwRCxRQUFBLFFBQVEsRUFBUjtBQURvRCxPQUF4RDtBQUdILEtBSkQ7O0FBTUEsSUFBQSxpQkFBaUIsQ0FBQyxLQUFsQixDQUF3QixTQUF4QixrQ0FBNEQsVUFBNUQsY0FBMEUsSUFBMUUsR0FBa0YsVUFBbEY7QUFDSCxHQVJEO0FBU0gsQ0FsQk07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDcktELFk7Ozs7Ozs7Ozs7Ozs7V0FDRiw4QkFBcUI7QUFDakIsYUFBTztBQUNILFFBQUEsU0FBUyxFQUFFO0FBQ1AsVUFBQSxRQUFRLEVBQUUseUJBREg7QUFFUCxVQUFBLGVBQWUsZ0NBQXlCLEtBQUssS0FBTCxFQUF6QixDQUZSO0FBR1AsVUFBQSxlQUFlLGdDQUF5QixLQUFLLEtBQUwsRUFBekIsQ0FIUjtBQUlQLFVBQUEsa0JBQWtCLCtCQUF3QixLQUFLLEtBQUwsRUFBeEI7QUFKWCxTQURSO0FBT0gsUUFBQSxNQUFNLEVBQUUsT0FQTDtBQVFILFFBQUEsSUFBSSxFQUFFLEtBUkg7QUFTSCxRQUFBLFFBQVEsRUFBRSxDQVRQO0FBVUgsUUFBQSxLQUFLLEVBQUUsR0FWSjtBQVdILFFBQUEsVUFBVSxFQUFFLEtBWFQ7QUFZSCxRQUFBLFVBQVUsRUFBRSxLQVpUO0FBYUgsUUFBQSxjQUFjLEVBQUUsS0FiYjtBQWNILFFBQUEsWUFBWSxFQUFFLEtBZFg7QUFlSCxRQUFBLGFBQWEsRUFBRTtBQUNYLFVBQUEsVUFBVSxFQUFFLENBREQ7QUFFWCxVQUFBLE9BQU8sRUFBRSxDQUZFO0FBR1gsVUFBQSxNQUFNLEVBQUUsQ0FIRztBQUlYLFVBQUEsTUFBTSxFQUFFLENBSkc7QUFLWCxVQUFBLFlBQVksRUFBRSxDQUxIO0FBTVgsVUFBQSxNQUFNLEVBQUUsQ0FORztBQU9YLFVBQUEsWUFBWSxFQUFFO0FBUEgsU0FmWjtBQXdCSCxRQUFBLGNBQWMsRUFBRTtBQUNaLFVBQUEsVUFBVSxFQUFFLENBREE7QUFFWixVQUFBLE9BQU8sRUFBRSxDQUZHO0FBR1osVUFBQSxNQUFNLEVBQUUsQ0FISTtBQUlaLFVBQUEsTUFBTSxFQUFFLENBSkk7QUFLWixVQUFBLFlBQVksRUFBRSxDQUxGO0FBTVosVUFBQSxNQUFNLEVBQUUsQ0FOSTtBQU9aLFVBQUEsWUFBWSxFQUFFO0FBUEYsU0F4QmI7QUFpQ0gsUUFBQSxZQUFZLEVBQUU7QUFDVixVQUFBLFVBQVUsRUFBRSxFQURGO0FBRVYsVUFBQSxPQUFPLEVBQUUsRUFGQztBQUdWLFVBQUEsTUFBTSxFQUFFLEVBSEU7QUFJVixVQUFBLE1BQU0sRUFBRSxFQUpFO0FBS1YsVUFBQSxZQUFZLEVBQUUsRUFMSjtBQU1WLFVBQUEsTUFBTSxFQUFFLEVBTkU7QUFPVixVQUFBLFlBQVksRUFBRTtBQVBKLFNBakNYO0FBMENILFFBQUEsY0FBYyxFQUFFO0FBMUNiLE9BQVA7QUE0Q0g7OztXQUVELDhCQUFxQjtBQUNqQixVQUFNLE9BQU8sR0FBRyxLQUFLLFFBQUwsQ0FBYyxHQUFkLENBQWtCLENBQWxCLENBQWhCO0FBQ0EsVUFBTSxTQUFTLEdBQUcsS0FBSyxXQUFMLENBQWlCLFdBQWpCLENBQWxCO0FBRUEsYUFBTztBQUNILFFBQUEsUUFBUSxFQUFFLE9BQU8sQ0FBQyxhQUFSLENBQXNCLFNBQVMsQ0FBQyxRQUFoQyxDQURQO0FBRUgsUUFBQSxlQUFlLEVBQUUsT0FBTyxDQUFDLGdCQUFSLENBQXlCLFNBQVMsQ0FBQyxlQUFuQyxDQUZkO0FBR0gsUUFBQSxlQUFlLEVBQUUsT0FBTyxDQUFDLGdCQUFSLENBQXlCLFNBQVMsQ0FBQyxlQUFuQyxDQUhkO0FBSUgsUUFBQSxrQkFBa0IsRUFBRSxPQUFPLENBQUMsZ0JBQVIsQ0FBeUIsU0FBUyxDQUFDLGtCQUFuQztBQUpqQixPQUFQO0FBTUg7OztXQUVELGtCQUFnQjtBQUFBOztBQUFBLHdDQUFOLElBQU07QUFBTixRQUFBLElBQU07QUFBQTs7QUFDWiw4R0FBZ0IsSUFBaEI7O0FBRUEsV0FBSyxjQUFMLEdBQXNCLEtBQUssS0FBTCxFQUF0Qjs7QUFFQSxVQUFJLEtBQUssa0JBQUwsR0FBMEIsUUFBOUIsRUFBd0M7QUFDcEMsYUFBSyxjQUFMLEdBQXNCLEtBQUssa0JBQUwsR0FBMEIsUUFBMUIsQ0FBbUMsRUFBekQ7QUFDSCxPQVBXLENBU1o7OztBQUNBLFVBQUksQ0FBQyxLQUFLLGtCQUFMLEdBQTBCLFFBQS9CLEVBQXlDO0FBQ3ZDO0FBQ0Q7O0FBRUQsV0FBSyxlQUFMO0FBQ0EsV0FBSyxVQUFMO0FBQ0EsV0FBSyxtQkFBTDtBQUNBLFdBQUssb0JBQUwsQ0FBMEIsS0FBSyxXQUFMLEVBQTFCO0FBQ0g7OztXQUdELDJCQUFrQjtBQUNkLFVBQU0sUUFBUSxHQUFHLEtBQUssV0FBTCxFQUFqQjtBQUNBLFVBQUksQ0FBQyxLQUFLLFFBQUwsQ0FBYyxRQUFuQixFQUE2QixPQUZmLENBRXVCOztBQUNyQyxVQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBTCxDQUFXLEtBQUssUUFBTCxDQUFjLFFBQWQsQ0FBdUIsWUFBdkIsQ0FBb0MsZUFBcEMsQ0FBWCxDQUFyQjtBQUVBLFdBQUssdUJBQUwsR0FBK0IsWUFBWSxDQUFDLFFBQWIsSUFBeUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFkLENBQU4sR0FBZ0MsQ0FBeEY7QUFFQSxVQUFNLGVBQWUsR0FBRztBQUNwQixRQUFBLE1BQU0sRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQWYsR0FBd0IsWUFBWSxDQUFDLE1BQXJDLEdBQThDLFFBQVEsQ0FBQyxNQUQzQztBQUVwQixRQUFBLElBQUksRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLElBQWYsR0FBc0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBZCxDQUFQLENBQTdCLEdBQTJELFFBQVEsQ0FBQyxJQUZ0RDtBQUdwQixRQUFBLFFBQVEsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQWYsR0FBMEIsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFkLENBQWhDLEdBQTBELFFBQVEsQ0FBQyxRQUh6RDtBQUlwQixRQUFBLEtBQUssRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQWYsR0FBdUIsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFkLENBQTdCLEdBQW9ELFFBQVEsQ0FBQyxLQUpoRDtBQUtwQixRQUFBLFVBQVUsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQWYsR0FBd0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsTUFBZCxDQUFQLENBQS9CLEdBQStELFFBQVEsQ0FBQyxVQUxoRTtBQU1wQixRQUFBLFVBQVUsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLElBQWYsR0FBc0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBZCxDQUFQLENBQTdCLEdBQTJELFFBQVEsQ0FBQyxVQU41RDtBQU9wQixRQUFBLFlBQVksRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLGdCQUFELENBQWQsR0FDUixJQUFJLENBQUMsS0FBTCxDQUFXLFlBQVksQ0FBQyxnQkFBRCxDQUF2QixDQURRLEdBRVIsUUFBUSxDQUFDLFlBVEs7QUFVcEIsUUFBQSxhQUFhLEVBQUU7QUFDWCxVQUFBLFVBQVUsRUFBRSxZQUFZLENBQUMsa0JBQUQsQ0FBWixLQUFxQyxTQUFyQyxHQUFpRCxNQUFNLENBQUMsWUFBWSxDQUFDLGtCQUFELENBQWIsQ0FBdkQsR0FBNEYsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsWUFBdkIsQ0FEN0Y7QUFFWCxVQUFBLE9BQU8sRUFBRSxZQUFZLENBQUMsT0FBRCxDQUFaLEtBQTBCLFNBQTFCLEdBQXNDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBRCxDQUFiLENBQTVDLEdBQXNFLFFBQVEsQ0FBQyxhQUFULENBQXVCLFNBQXZCLENBRnBFO0FBR1gsVUFBQSxNQUFNLEVBQUUsWUFBWSxDQUFDLGNBQUQsQ0FBWixLQUFpQyxTQUFqQyxHQUE2QyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQUQsQ0FBYixDQUFuRCxHQUFvRixRQUFRLENBQUMsYUFBVCxDQUF1QixRQUF2QixDQUhqRjtBQUlYLFVBQUEsTUFBTSxFQUFFLFlBQVksQ0FBQyxjQUFELENBQVosS0FBaUMsU0FBakMsR0FBNkMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFELENBQWIsQ0FBbkQsR0FBb0YsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsUUFBdkIsQ0FKakY7QUFLWCxVQUFBLFlBQVksRUFBRSxZQUFZLENBQUMsb0JBQUQsQ0FBWixLQUF1QyxTQUF2QyxHQUFtRCxNQUFNLENBQUMsWUFBWSxDQUFDLG9CQUFELENBQWIsQ0FBekQsR0FBZ0csUUFBUSxDQUFDLGFBQVQsQ0FBdUIsY0FBdkIsQ0FMbkc7QUFNWCxVQUFBLE1BQU0sRUFBRSxZQUFZLENBQUMsY0FBRCxDQUFaLEtBQWlDLFNBQWpDLEdBQTZDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBRCxDQUFiLENBQW5ELEdBQW9GLFFBQVEsQ0FBQyxhQUFULENBQXVCLFFBQXZCLENBTmpGO0FBT1gsVUFBQSxZQUFZLEVBQUUsWUFBWSxDQUFDLG9CQUFELENBQVosS0FBdUMsU0FBdkMsR0FBbUQsTUFBTSxDQUFDLFlBQVksQ0FBQyxvQkFBRCxDQUFiLENBQXpELEdBQWdHLFFBQVEsQ0FBQyxhQUFULENBQXVCLGNBQXZCO0FBUG5HLFNBVks7QUFtQnBCLFFBQUEsY0FBYyxFQUFFO0FBQ1osVUFBQSxVQUFVLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxtQkFBRCxDQUFkLEdBQXNDLE1BQU0sQ0FBQyxZQUFZLENBQUMsbUJBQUQsQ0FBYixDQUE1QyxHQUFrRixRQUFRLENBQUMsY0FBVCxDQUF3QixVQUQxRztBQUVaLFVBQUEsT0FBTyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBRCxDQUFkLEdBQTJCLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBRCxDQUFiLENBQWpDLEdBQTRELFFBQVEsQ0FBQyxjQUFULENBQXdCLE9BRmpGO0FBR1osVUFBQSxNQUFNLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxlQUFELENBQWQsR0FBa0MsTUFBTSxDQUFDLFlBQVksQ0FBQyxlQUFELENBQWIsQ0FBeEMsR0FBMEUsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsTUFIOUY7QUFJWixVQUFBLE1BQU0sRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLGVBQUQsQ0FBZCxHQUNGLE1BQU0sQ0FBQyxZQUFZLENBQUMsZUFBRCxDQUFiLENBREosR0FFRixRQUFRLENBQUMsY0FBVCxDQUF3QixNQU5sQjtBQU9aLFVBQUEsWUFBWSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMscUJBQUQsQ0FBZCxHQUNSLE1BQU0sQ0FBQyxZQUFZLENBQUMscUJBQUQsQ0FBYixDQURFLEdBRVIsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsWUFUbEI7QUFVWixVQUFBLE1BQU0sRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLGVBQUQsQ0FBZCxHQUNGLE1BQU0sQ0FBQyxZQUFZLENBQUMsZUFBRCxDQUFiLENBREosR0FFRixRQUFRLENBQUMsY0FBVCxDQUF3QixNQVpsQjtBQWFaLFVBQUEsWUFBWSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMscUJBQUQsQ0FBZCxHQUNSLE1BQU0sQ0FBQyxZQUFZLENBQUMscUJBQUQsQ0FBYixDQURFLEdBRVIsUUFBUSxDQUFDLGNBQVQsQ0FBd0I7QUFmbEIsU0FuQkk7QUFvQ3BCLFFBQUEsWUFBWSxFQUFFO0FBQ1YsVUFBQSxVQUFVLEVBQUUsWUFBWSxDQUFDLG1CQUFELENBQVosS0FBc0MsU0FBdEMsR0FBa0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxtQkFBRCxDQUFiLENBQXhELEdBQThGLFFBQVEsQ0FBQyxZQUFULENBQXNCLFVBRHRIO0FBRVYsVUFBQSxPQUFPLEVBQUUsWUFBWSxDQUFDLFFBQUQsQ0FBWixLQUEyQixTQUEzQixHQUF1QyxNQUFNLENBQUMsWUFBWSxDQUFDLFFBQUQsQ0FBYixDQUE3QyxHQUF3RSxRQUFRLENBQUMsWUFBVCxDQUFzQixPQUY3RjtBQUdWLFVBQUEsTUFBTSxFQUFFLFlBQVksQ0FBQyxlQUFELENBQVosS0FBa0MsU0FBbEMsR0FBOEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxlQUFELENBQWIsQ0FBcEQsR0FBc0YsUUFBUSxDQUFDLFlBQVQsQ0FBc0IsTUFIMUc7QUFJVixVQUFBLE1BQU0sRUFBRSxZQUFZLENBQUMsZUFBRCxDQUFaLEtBQWtDLFNBQWxDLEdBQThDLE1BQU0sQ0FBQyxZQUFZLENBQUMsZUFBRCxDQUFiLENBQXBELEdBQXNGLFFBQVEsQ0FBQyxZQUFULENBQXNCLE1BSjFHO0FBS1YsVUFBQSxZQUFZLEVBQUUsWUFBWSxDQUFDLHFCQUFELENBQVosS0FBd0MsU0FBeEMsR0FBb0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxxQkFBRCxDQUFiLENBQTFELEdBQWtHLFFBQVEsQ0FBQyxZQUFULENBQXNCLFlBTDVIO0FBTVYsVUFBQSxNQUFNLEVBQUUsWUFBWSxDQUFDLGVBQUQsQ0FBWixLQUFrQyxTQUFsQyxHQUE4QyxNQUFNLENBQUMsWUFBWSxDQUFDLGVBQUQsQ0FBYixDQUFwRCxHQUFzRixRQUFRLENBQUMsWUFBVCxDQUFzQixNQU4xRztBQU9WLFVBQUEsWUFBWSxFQUFFLFlBQVksQ0FBQyxxQkFBRCxDQUFaLEtBQXdDLFNBQXhDLEdBQW9ELE1BQU0sQ0FBQyxZQUFZLENBQUMscUJBQUQsQ0FBYixDQUExRCxHQUFrRyxRQUFRLENBQUMsWUFBVCxDQUFzQjtBQVA1SDtBQXBDTSxPQUF4QjtBQWdEQSxNQUFBLGVBQWUsQ0FBQyxjQUFoQixHQUFpQyxlQUFlLENBQUMsTUFBaEIsS0FBMkIsV0FBM0IsR0FBeUMsSUFBekMsR0FBZ0QsUUFBUSxDQUFDLGNBQTFGO0FBRUEsV0FBSyxXQUFMLENBQWlCLGVBQWpCO0FBRUg7OztXQUVELDhCQUFxQixRQUFyQixFQUErQjtBQUM3QixVQUFRLFlBQVIsR0FBeUIsUUFBekIsQ0FBUSxZQUFSOztBQUdBLFVBQUksWUFBWSxDQUFDLE9BQWIsS0FBeUIsQ0FBN0IsRUFBZ0M7QUFDNUIsYUFBSyxRQUFMLENBQWMsUUFBZCxDQUF1QixnQkFBdkIsQ0FBd0MscUJBQXhDLEVBQStELE9BQS9ELENBQXVFLFVBQUEsS0FBSyxFQUFJO0FBQzVFLFVBQUEsS0FBSyxDQUFDLEtBQU4sQ0FBWSxXQUFaLEdBQTBCLEtBQTFCO0FBQ0gsU0FGRDtBQUdIOztBQUNELFVBQUksWUFBWSxDQUFDLE1BQWIsS0FBd0IsQ0FBNUIsRUFBK0I7QUFDM0IsYUFBSyxRQUFMLENBQWMsUUFBZCxDQUF1QixnQkFBdkIsQ0FBd0MscUJBQXhDLEVBQStELE9BQS9ELENBQXVFLFVBQUEsS0FBSyxFQUFJO0FBQzVFLFVBQUEsS0FBSyxDQUFDLEtBQU4sQ0FBWSxXQUFaLEdBQTBCLEtBQTFCO0FBQ0gsU0FGRDtBQUdIOztBQUNELFVBQUksWUFBWSxDQUFDLE1BQWIsS0FBd0IsQ0FBNUIsRUFBK0I7QUFDM0IsYUFBSyxRQUFMLENBQWMsUUFBZCxDQUF1QixnQkFBdkIsQ0FBd0MscUJBQXhDLEVBQStELE9BQS9ELENBQXVFLFVBQUEsS0FBSyxFQUFJO0FBQzVFLFVBQUEsS0FBSyxDQUFDLEtBQU4sQ0FBWSxXQUFaLEdBQTBCLEtBQTFCO0FBQ0gsU0FGRDtBQUdIO0FBQ0o7OztXQUdDLHNCQUFhO0FBQ1QsVUFBTSxNQUFNLEdBQUcsSUFBSSxNQUFKLENBQVcsS0FBSyxRQUFMLENBQWMsUUFBekIsRUFBbUMsS0FBSyxhQUFMLEVBQW5DLENBQWY7QUFFQSxXQUFLLFdBQUwsQ0FBaUI7QUFDYixRQUFBLGNBQWMsRUFBRTtBQURILE9BQWpCO0FBR0g7OztXQUVELHlCQUFnQjtBQUNaLFVBQU0sUUFBUSxHQUFHLEtBQUssV0FBTCxFQUFqQjtBQUVBLFVBQU0sYUFBYSxHQUFHO0FBQ2xCLFFBQUEsU0FBUyxFQUFFLFlBRE87QUFFbEIsUUFBQSxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BRkM7QUFHbEIsUUFBQSxJQUFJLEVBQUUsUUFBUSxDQUFDLElBSEc7QUFJbEIsUUFBQSxLQUFLLEVBQUUsUUFBUSxDQUFDLEtBSkU7QUFLbEIsUUFBQSxjQUFjLEVBQUUsUUFBUSxDQUFDLGNBTFA7QUFNbEIsUUFBQSxVQUFVLEVBQUUsSUFOTTtBQU9sQixRQUFBLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFWLEdBQ0osS0FESSxHQUVKO0FBQ0ksVUFBQSxLQUFLLEVBQUUsUUFBUSxDQUFDO0FBRHBCLFNBVFk7QUFZbEIsUUFBQSxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVixHQUNOLEtBRE0sR0FFTjtBQUNJLFVBQUEsTUFBTSxFQUFFLFFBQVEsQ0FBQyxTQUFULENBQW1CLGVBRC9CO0FBRUksVUFBQSxNQUFNLEVBQUUsUUFBUSxDQUFDLFNBQVQsQ0FBbUI7QUFGL0IsU0FkWTtBQWtCbEIsUUFBQSxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVixHQUNOLEtBRE0sR0FFTjtBQUNJLFVBQUEsRUFBRSxFQUFFLFFBQVEsQ0FBQyxTQUFULENBQW1CLGtCQUQzQjtBQUVJLFVBQUEsU0FBUyxFQUFFO0FBRmY7QUFwQlksT0FBdEIsQ0FIWSxDQTZCWjs7QUFDQSxVQUFJLFdBQVcsR0FBRyxpQkFBaUIsQ0FBQyxNQUFsQixDQUF5QixVQUF6QixDQUFvQyxpQkFBdEQ7QUFDQSxVQUFJLG9CQUFvQixHQUFHLGlCQUFpQixDQUFDLE1BQWxCLENBQXlCLFdBQXBEOztBQUVBLFVBQUksUUFBUSxDQUFDLE1BQVQsS0FBb0IsTUFBeEIsRUFBZ0M7QUFDNUIsUUFBQSxhQUFhLENBQUMsS0FBZCxHQUFzQixDQUF0QjtBQUNILE9BRkQsTUFFTztBQUNMLFFBQUEsYUFBYSxDQUFDLFdBQWQsR0FBNEIsRUFBNUI7QUFFRSxZQUFJLGtCQUFrQixHQUFHLEVBQXpCOztBQUNBLGFBQUssSUFBSSxVQUFULElBQXVCLFdBQXZCLEVBQW9DO0FBQ2xDLGNBQUksU0FBUyxHQUFHLFdBQVcsQ0FBQyxVQUFELENBQVgsQ0FBd0IsZUFBeEIsQ0FBaEI7O0FBQ0EsY0FBSSxXQUFXLENBQUMsVUFBRCxDQUFYLENBQXdCLE9BQXhCLE1BQXFDLFNBQXpDLEVBQXFEO0FBQ25ELFlBQUEsU0FBUyxHQUFHLFdBQVcsQ0FBQyxVQUFELENBQVgsQ0FBd0IsT0FBeEIsQ0FBWjtBQUNEOztBQUNELFVBQUEsa0JBQWtCLENBQUMsSUFBbkIsQ0FBd0I7QUFDdEIscUJBQVUsVUFEWTtBQUV0Qix5QkFBYztBQUZRLFdBQXhCO0FBSUQ7O0FBQ0QsUUFBQSxrQkFBa0IsQ0FBQyxJQUFuQixDQUF3QixVQUFDLENBQUQsRUFBSSxDQUFKLEVBQVU7QUFDaEMsaUJBQU8sQ0FBQyxDQUFDLFNBQUYsR0FBYyxDQUFDLENBQUMsU0FBdkI7QUFDRCxTQUZEO0FBSUEsWUFBSSxnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBLFlBQUksWUFBWSxHQUFHLG9CQUFvQixDQUFDLEVBQXhDOztBQUNBLCtDQUFrQyxrQkFBbEMseUNBQXNEO0FBQWpELGNBQUkscUJBQXFCLDBCQUF6QjtBQUVILGNBQUksbUJBQW1CLEdBQUcscUJBQXFCLENBQUMsS0FBaEQ7O0FBRUEsY0FBSSxRQUFRLENBQUMsYUFBVCxDQUF1QixtQkFBdkIsTUFBZ0QsU0FBcEQsRUFBK0Q7QUFDN0QsWUFBQSxhQUFhLENBQUMsV0FBZCxDQUEwQixnQkFBMUIsSUFBOEM7QUFDNUMsY0FBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsbUJBQXZCLENBRDZCO0FBRTVDLGNBQUEsY0FBYyxFQUFFLFFBQVEsQ0FBQyxjQUFULENBQXdCLG1CQUF4QixDQUY0QjtBQUc1QyxjQUFBLFlBQVksRUFBRSxRQUFRLENBQUMsWUFBVCxDQUFzQixtQkFBdEI7QUFIOEIsYUFBOUM7O0FBTUEsZ0JBQUksbUJBQW1CLEtBQUssWUFBNUIsRUFBMkM7QUFDekMsY0FBQSxZQUFZLEdBQUcsZ0JBQWY7QUFDQSxjQUFBLGdCQUFnQixHQUFHLHFCQUFxQixDQUFDLFdBQUQsQ0FBeEM7QUFDQSxjQUFBLGFBQWEsQ0FBQyxXQUFkLENBQTBCLGdCQUExQixJQUE4QztBQUM1QyxnQkFBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsbUJBQXZCLENBRDZCO0FBRTVDLGdCQUFBLGNBQWMsRUFBRSxRQUFRLENBQUMsY0FBVCxDQUF3QixtQkFBeEIsQ0FGNEI7QUFHNUMsZ0JBQUEsWUFBWSxFQUFFLFFBQVEsQ0FBQyxZQUFULENBQXNCLG1CQUF0QjtBQUg4QixlQUE5QztBQUtELGFBUkQsTUFRTztBQUNMLGNBQUEsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFdBQUQsQ0FBdEIsQ0FBUixHQUErQyxDQUFsRTtBQUNBLGNBQUEsWUFBWSxHQUFHLGdCQUFmO0FBQ0Q7QUFDRjtBQUNGOztBQUVELFFBQUEsYUFBYSxDQUFDLFdBQWQsQ0FBMEIsWUFBMUIsSUFBMEM7QUFDeEMsVUFBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGFBQVQsQ0FBdUIsU0FBdkIsQ0FEeUI7QUFFeEMsVUFBQSxjQUFjLEVBQUUsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsU0FBeEIsQ0FGd0I7QUFHeEMsVUFBQSxZQUFZLEVBQUUsUUFBUSxDQUFDLFlBQVQsQ0FBc0IsU0FBdEI7QUFIMEIsU0FBMUM7QUFNSDs7QUFFRCxhQUFPLGFBQVA7QUFDSDs7O1dBRUQsK0JBQXNCO0FBQUE7O0FBQ3BCO0FBQ0EsVUFBSSxLQUFLLHVCQUFMLElBQWdDLEtBQUssV0FBTCxDQUFpQixjQUFqQixDQUFoQyxJQUFvRSxLQUFLLFFBQUwsQ0FBYyxRQUF0RixFQUFnRztBQUM1RixhQUFLLFFBQUwsQ0FBYyxRQUFkLENBQXVCLGdCQUF2QixDQUF3QyxZQUF4QyxFQUFzRCxLQUFLLFdBQUwsQ0FBaUIsSUFBakIsQ0FBc0IsSUFBdEIsQ0FBdEQ7QUFDQSxhQUFLLFFBQUwsQ0FBYyxRQUFkLENBQXVCLGdCQUF2QixDQUF3QyxZQUF4QyxFQUFzRCxLQUFLLFlBQUwsQ0FBa0IsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBdEQ7QUFDSCxPQUxtQixDQU9wQjs7O0FBQ0EsTUFBQSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQVYsQ0FBTixDQUFzQixFQUF0QixDQUF5QixnQkFBekIsRUFBMkMsWUFBTTtBQUU3QyxRQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsVUFBQSxLQUFJLENBQUMsYUFBTDtBQUNILFNBRlMsRUFFUCxHQUZPLENBQVY7QUFHSCxPQUxEO0FBTUQ7OztXQUVELHlCQUFnQjtBQUNkLFVBQU0sY0FBYyxHQUFHLEtBQUssV0FBTCxDQUFpQixnQkFBakIsQ0FBdkI7O0FBRUEsVUFBSSxjQUFKLEVBQW9CO0FBQ2hCLFFBQUEsY0FBYyxDQUFDLE9BQWYsQ0FBdUIsSUFBdkIsRUFBNkIsSUFBN0I7QUFDQSxhQUFLLFdBQUwsQ0FBaUI7QUFBRSxVQUFBLGNBQWMsRUFBRTtBQUFsQixTQUFqQjtBQUNIOztBQUVELFVBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEtBQUssY0FBWixDQUFwQjs7QUFDQSxVQUFJLENBQUMsT0FBRCxJQUFZLE9BQU8sQ0FBQyxNQUFSLEtBQW1CLENBQW5DLEVBQXNDO0FBQ2xDO0FBQ0g7O0FBRUQsVUFBSSxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsT0FBUixDQUFnQixrQ0FBaEIsQ0FBdkI7QUFFQSxXQUFLLFFBQUwsR0FBZ0IsZ0JBQWdCLENBQUMsTUFBakIsR0FBMEIsZ0JBQTFCLEdBQTZDLE9BQTdEO0FBRUEsV0FBSyxRQUFMLEdBQWdCLEtBQUssa0JBQUwsRUFBaEI7O0FBRUEsVUFBSSxDQUFDLEtBQUssUUFBTCxDQUFjLFFBQW5CLEVBQTZCO0FBQ3pCO0FBQ0g7O0FBRUQsV0FBSyxlQUFMO0FBQ0EsV0FBSyxVQUFMO0FBQ0EsV0FBSyxvQkFBTCxDQUEwQixLQUFLLFdBQUwsRUFBMUI7QUFDRDs7O1dBRUQsdUJBQWM7QUFDWixVQUFJLEtBQUssV0FBTCxDQUFpQixnQkFBakIsRUFBbUMsUUFBbkMsQ0FBNEMsT0FBaEQsRUFBeUQ7QUFDckQsYUFBSyxXQUFMLENBQWlCLGdCQUFqQixFQUFtQyxRQUFuQyxDQUE0QyxJQUE1QztBQUNIO0FBQ0Y7OztXQUVILHdCQUFlO0FBQ1gsVUFBSSxDQUFDLEtBQUssV0FBTCxDQUFpQixnQkFBakIsRUFBbUMsUUFBbkMsQ0FBNEMsT0FBakQsRUFBMEQ7QUFDdEQsYUFBSyxXQUFMLENBQWlCLGdCQUFqQixFQUFtQyxRQUFuQyxDQUE0QyxLQUE1QztBQUNIO0FBQ0o7Ozs7RUEvVHdCLGdCQUFnQixDQUFDLFFBQWpCLENBQTBCLFFBQTFCLENBQW1DLEk7O2VBa1UvQyxZOzs7Ozs7OztBQ2xVZjs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFFTSxrQjs7Ozs7Ozs7Ozs7O0VBQTJCLG9COztBQUVqQywyQkFBZSxrQkFBZixFQUFtQyxxQkFBbkMiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbigpe2Z1bmN0aW9uIHIoZSxuLHQpe2Z1bmN0aW9uIG8oaSxmKXtpZighbltpXSl7aWYoIWVbaV0pe3ZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWYmJmMpcmV0dXJuIGMoaSwhMCk7aWYodSlyZXR1cm4gdShpLCEwKTt2YXIgYT1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK2krXCInXCIpO3Rocm93IGEuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixhfXZhciBwPW5baV09e2V4cG9ydHM6e319O2VbaV1bMF0uY2FsbChwLmV4cG9ydHMsZnVuY3Rpb24ocil7dmFyIG49ZVtpXVsxXVtyXTtyZXR1cm4gbyhufHxyKX0scCxwLmV4cG9ydHMscixlLG4sdCl9cmV0dXJuIG5baV0uZXhwb3J0c31mb3IodmFyIHU9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZSxpPTA7aTx0Lmxlbmd0aDtpKyspbyh0W2ldKTtyZXR1cm4gb31yZXR1cm4gcn0pKCkiLCJleHBvcnQgY29uc3Qgc2xpZGVEb3duID0gKGVsZW1lbnQsIGR1cmF0aW9uID0gMzAwKSA9PiB7XG4gICAgbGV0IGRpc3BsYXkgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KS5kaXNwbGF5O1xuXG4gICAgaWYgKGRpc3BsYXkgPT09IFwibm9uZVwiKSB7XG4gICAgICAgIGRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgfVxuXG4gICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uUHJvcGVydHkgPSBcImhlaWdodFwiO1xuICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvbkR1cmF0aW9uID0gYCR7ZHVyYXRpb259bXNgO1xuXG4gICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gMDtcbiAgICBlbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBkaXNwbGF5O1xuICAgIGxldCBoZWlnaHQgPSBlbGVtZW50Lm9mZnNldEhlaWdodDtcblxuICAgIGVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gMDtcbiAgICBlbGVtZW50LnN0eWxlLm9wYWNpdHkgPSAxO1xuICAgIGVsZW1lbnQuc3R5bGUub3ZlcmZsb3cgPSBcImhpZGRlblwiO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gYCR7aGVpZ2h0fXB4YDtcbiAgICB9LCA1KTtcblxuICAgIHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcImhlaWdodFwiKTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm92ZXJmbG93XCIpO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwidHJhbnNpdGlvbi1kdXJhdGlvblwiKTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcInRyYW5zaXRpb24tcHJvcGVydHlcIik7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJvcGFjaXR5XCIpO1xuICAgIH0sIGR1cmF0aW9uICsgNTApO1xufTtcblxuZXhwb3J0IGNvbnN0IHNsaWRlVXAgPSAoZWxlbWVudCwgZHVyYXRpb24gPSAzMDApID0+IHtcbiAgICBlbGVtZW50LnN0eWxlLmJveFNpemluZyA9IFwiYm9yZGVyLWJveFwiO1xuICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvblByb3BlcnR5ID0gXCJoZWlnaHQsIG1hcmdpblwiO1xuICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvbkR1cmF0aW9uID0gYCR7ZHVyYXRpb259bXNgO1xuICAgIGVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gYCR7ZWxlbWVudC5vZmZzZXRIZWlnaHR9cHhgO1xuICAgIGVsZW1lbnQuc3R5bGUubWFyZ2luVG9wID0gMDtcbiAgICBlbGVtZW50LnN0eWxlLm1hcmdpbkJvdHRvbSA9IDA7XG4gICAgZWxlbWVudC5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSAwO1xuICAgIH0sIDUpO1xuXG4gICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBlbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcImhlaWdodFwiKTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm1hcmdpbi10b3BcIik7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJtYXJnaW4tYm90dG9tXCIpO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwib3ZlcmZsb3dcIik7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uLWR1cmF0aW9uXCIpO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwidHJhbnNpdGlvbi1wcm9wZXJ0eVwiKTtcbiAgICB9LCBkdXJhdGlvbiArIDUwKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzbGlkZVRvZ2dsZSA9IChlbGVtZW50LCBkdXJhdGlvbikgPT4ge1xuICAgIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpLmRpc3BsYXkgPT09IFwibm9uZVwiID8gc2xpZGVEb3duKGVsZW1lbnQsIGR1cmF0aW9uKSA6IHNsaWRlVXAoZWxlbWVudCwgZHVyYXRpb24pO1xufTtcblxuZXhwb3J0IGNvbnN0IGZhZGVJbiA9IChlbGVtZW50LCBfb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgZHVyYXRpb246IDMwMCxcbiAgICAgICAgZGlzcGxheTogbnVsbCxcbiAgICAgICAgb3BhY2l0eTogMSxcbiAgICAgICAgY2FsbGJhY2s6IG51bGwsXG4gICAgfTtcblxuICAgIE9iamVjdC5hc3NpZ24ob3B0aW9ucywgX29wdGlvbnMpO1xuXG4gICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gMDtcbiAgICBlbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBvcHRpb25zLmRpc3BsYXkgfHwgXCJibG9ja1wiO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvbiA9IGAke29wdGlvbnMuZHVyYXRpb259bXMgb3BhY2l0eSBlYXNlYDtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gb3B0aW9ucy5vcGFjaXR5O1xuICAgIH0sIDUpO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uXCIpO1xuICAgICAgICAhIW9wdGlvbnMuY2FsbGJhY2sgJiYgb3B0aW9ucy5jYWxsYmFjaygpO1xuICAgIH0sIG9wdGlvbnMuZHVyYXRpb24gKyA1MCk7XG59O1xuXG5leHBvcnQgY29uc3QgZmFkZU91dCA9IChlbGVtZW50LCBfb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgZHVyYXRpb246IDMwMCxcbiAgICAgICAgZGlzcGxheTogbnVsbCxcbiAgICAgICAgb3BhY2l0eTogMCxcbiAgICAgICAgY2FsbGJhY2s6IG51bGwsXG4gICAgfTtcblxuICAgIE9iamVjdC5hc3NpZ24ob3B0aW9ucywgX29wdGlvbnMpO1xuXG4gICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gMTtcbiAgICBlbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBvcHRpb25zLmRpc3BsYXkgfHwgXCJibG9ja1wiO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUudHJhbnNpdGlvbiA9IGAke29wdGlvbnMuZHVyYXRpb259bXMgb3BhY2l0eSBlYXNlYDtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gb3B0aW9ucy5vcGFjaXR5O1xuICAgIH0sIDUpO1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwidHJhbnNpdGlvblwiKTtcbiAgICAgICAgISFvcHRpb25zLmNhbGxiYWNrICYmIG9wdGlvbnMuY2FsbGJhY2soKTtcbiAgICB9LCBvcHRpb25zLmR1cmF0aW9uICsgNTApO1xufTtcblxuZXhwb3J0IGNvbnN0IGZhZGVUb2dnbGUgPSAoZWxlbWVudCwgb3B0aW9ucykgPT4ge1xuICAgIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpLmRpc3BsYXkgPT09IFwibm9uZVwiID8gZmFkZUluKGVsZW1lbnQsIG9wdGlvbnMpIDogZmFkZU91dChlbGVtZW50LCBvcHRpb25zKTtcbn07XG5cbmV4cG9ydCBjb25zdCBvZmZzZXQgPSAoZWxlbWVudCkgPT4ge1xuICAgIGlmICghZWxlbWVudC5nZXRDbGllbnRSZWN0cygpLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4geyB0b3A6IDAsIGxlZnQ6IDAgfTtcbiAgICB9XG5cbiAgICAvLyBHZXQgZG9jdW1lbnQtcmVsYXRpdmUgcG9zaXRpb24gYnkgYWRkaW5nIHZpZXdwb3J0IHNjcm9sbCB0byB2aWV3cG9ydC1yZWxhdGl2ZSBnQkNSXG4gICAgY29uc3QgcmVjdCA9IGVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3Qgd2luID0gZWxlbWVudC5vd25lckRvY3VtZW50LmRlZmF1bHRWaWV3O1xuICAgIHJldHVybiB7XG4gICAgICAgIHRvcDogcmVjdC50b3AgKyB3aW4ucGFnZVlPZmZzZXQsXG4gICAgICAgIGxlZnQ6IHJlY3QubGVmdCArIHdpbi5wYWdlWE9mZnNldCxcbiAgICB9O1xufTtcblxuZXhwb3J0IGNvbnN0IHZpc2libGUgPSAoZWxlbWVudCkgPT4ge1xuICAgIGlmICghZWxlbWVudCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuICEhKGVsZW1lbnQub2Zmc2V0V2lkdGggfHwgZWxlbWVudC5vZmZzZXRIZWlnaHQgfHwgZWxlbWVudC5nZXRDbGllbnRSZWN0cygpLmxlbmd0aCk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0U2libGluZ3MgPSAoZSkgPT4ge1xuICAgIC8vIGZvciBjb2xsZWN0aW5nIHNpYmxpbmdzXG4gICAgY29uc3Qgc2libGluZ3MgPSBbXTtcblxuICAgIC8vIGlmIG5vIHBhcmVudCwgcmV0dXJuIG5vIHNpYmxpbmdcbiAgICBpZiAoIWUucGFyZW50Tm9kZSkge1xuICAgICAgICByZXR1cm4gc2libGluZ3M7XG4gICAgfVxuXG4gICAgLy8gZmlyc3QgY2hpbGQgb2YgdGhlIHBhcmVudCBub2RlXG4gICAgbGV0IHNpYmxpbmcgPSBlLnBhcmVudE5vZGUuZmlyc3RDaGlsZDtcblxuICAgIC8vIGNvbGxlY3Rpbmcgc2libGluZ3NcbiAgICB3aGlsZSAoc2libGluZykge1xuICAgICAgICBpZiAoc2libGluZy5ub2RlVHlwZSA9PT0gMSAmJiBzaWJsaW5nICE9PSBlKSB7XG4gICAgICAgICAgICBzaWJsaW5ncy5wdXNoKHNpYmxpbmcpO1xuICAgICAgICB9XG5cbiAgICAgICAgc2libGluZyA9IHNpYmxpbmcubmV4dFNpYmxpbmc7XG4gICAgfVxuXG4gICAgcmV0dXJuIHNpYmxpbmdzO1xufTtcblxuLy8gUmV0dXJucyB0cnVlIGlmIGl0IGlzIGEgRE9NIGVsZW1lbnRcbmV4cG9ydCBjb25zdCBpc0VsZW1lbnQgPSAobykgPT4ge1xuICAgIHJldHVybiB0eXBlb2YgSFRNTEVsZW1lbnQgPT09IFwib2JqZWN0XCJcbiAgICAgICAgPyBvIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgLy8gRE9NMlxuICAgICAgICA6IG8gJiYgdHlwZW9mIG8gPT09IFwib2JqZWN0XCIgJiYgbyAhPT0gbnVsbCAmJiBvLm5vZGVUeXBlID09PSAxICYmIHR5cGVvZiBvLm5vZGVOYW1lID09PSBcInN0cmluZ1wiO1xufTtcblxuZXhwb3J0IGNvbnN0IHJlZ2lzdGVyV2lkZ2V0ID0gKGNsYXNzTmFtZSwgd2lkZ2V0TmFtZSwgc2tpbiA9IFwiZGVmYXVsdFwiKSA9PiB7XG4gICAgaWYgKCEoY2xhc3NOYW1lIHx8IHdpZGdldE5hbWUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBCZWNhdXNlIEVsZW1lbnRvciBwbHVnaW4gdXNlcyBqUXVlcnkgY3VzdG9tIGV2ZW50LFxuICAgICAqIFdlIGFsc28gaGF2ZSB0byB1c2UgalF1ZXJ5IHRvIHVzZSB0aGlzIGV2ZW50XG4gICAgICovXG4gICAgalF1ZXJ5KHdpbmRvdykub24oXCJlbGVtZW50b3IvZnJvbnRlbmQvaW5pdFwiLCAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGFkZEhhbmRsZXIgPSAoJGVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgIGVsZW1lbnRvckZyb250ZW5kLmVsZW1lbnRzSGFuZGxlci5hZGRIYW5kbGVyKGNsYXNzTmFtZSwge1xuICAgICAgICAgICAgICAgICRlbGVtZW50LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgZWxlbWVudG9yRnJvbnRlbmQuaG9va3MuYWRkQWN0aW9uKGBmcm9udGVuZC9lbGVtZW50X3JlYWR5LyR7d2lkZ2V0TmFtZX0uJHtza2lufWAsIGFkZEhhbmRsZXIpO1xuICAgIH0pO1xufTtcbiIsImNsYXNzIE9FV19DYXJvdXNlbCBleHRlbmRzIGVsZW1lbnRvck1vZHVsZXMuZnJvbnRlbmQuaGFuZGxlcnMuQmFzZSB7XG4gICAgZ2V0RGVmYXVsdFNldHRpbmdzKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2VsZWN0b3JzOiB7XG4gICAgICAgICAgICAgICAgY2Fyb3VzZWw6IFwiLm9ldy1jYXJvdXNlbC1jb250YWluZXJcIixcbiAgICAgICAgICAgICAgICBjYXJvdXNlbE5leHRCdG46IGAuc3dpcGVyLWJ1dHRvbi1uZXh0LSR7dGhpcy5nZXRJRCgpfWAsXG4gICAgICAgICAgICAgICAgY2Fyb3VzZWxQcmV2QnRuOiBgLnN3aXBlci1idXR0b24tcHJldi0ke3RoaXMuZ2V0SUQoKX1gLFxuICAgICAgICAgICAgICAgIGNhcm91c2VsUGFnaW5hdGlvbjogYC5zd2lwZXItcGFnaW5hdGlvbi0ke3RoaXMuZ2V0SUQoKX1gLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVmZmVjdDogXCJzbGlkZVwiLFxuICAgICAgICAgICAgbG9vcDogZmFsc2UsXG4gICAgICAgICAgICBhdXRvcGxheTogMCxcbiAgICAgICAgICAgIHNwZWVkOiA0MDAsXG4gICAgICAgICAgICBuYXZpZ2F0aW9uOiBmYWxzZSxcbiAgICAgICAgICAgIHBhZ2luYXRpb246IGZhbHNlLFxuICAgICAgICAgICAgY2VudGVyZWRTbGlkZXM6IGZhbHNlLFxuICAgICAgICAgICAgcGF1c2VPbkhvdmVyOiBmYWxzZSxcbiAgICAgICAgICAgIHNsaWRlc1BlclZpZXc6IHtcbiAgICAgICAgICAgICAgICB3aWRlc2NyZWVuOiAzLFxuICAgICAgICAgICAgICAgIGRlc2t0b3A6IDMsXG4gICAgICAgICAgICAgICAgbGFwdG9wOiAzLFxuICAgICAgICAgICAgICAgIHRhYmxldDogMixcbiAgICAgICAgICAgICAgICB0YWJsZXRfZXh0cmE6IDIsXG4gICAgICAgICAgICAgICAgbW9iaWxlOiAxLFxuICAgICAgICAgICAgICAgIG1vYmlsZV9leHRyYTogMSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzbGlkZXNQZXJHcm91cDoge1xuICAgICAgICAgICAgICAgIHdpZGVzY3JlZW46IDMsXG4gICAgICAgICAgICAgICAgZGVza3RvcDogMyxcbiAgICAgICAgICAgICAgICBsYXB0b3A6IDMsXG4gICAgICAgICAgICAgICAgdGFibGV0OiAyLFxuICAgICAgICAgICAgICAgIHRhYmxldF9leHRyYTogMixcbiAgICAgICAgICAgICAgICBtb2JpbGU6IDEsXG4gICAgICAgICAgICAgICAgbW9iaWxlX2V4dHJhOiAxLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNwYWNlQmV0d2Vlbjoge1xuICAgICAgICAgICAgICAgIHdpZGVzY3JlZW46IDEwLFxuICAgICAgICAgICAgICAgIGRlc2t0b3A6IDEwLFxuICAgICAgICAgICAgICAgIGxhcHRvcDogMTAsXG4gICAgICAgICAgICAgICAgdGFibGV0OiAxMCxcbiAgICAgICAgICAgICAgICB0YWJsZXRfZXh0cmE6IDEwLFxuICAgICAgICAgICAgICAgIG1vYmlsZTogMTAsXG4gICAgICAgICAgICAgICAgbW9iaWxlX2V4dHJhOiAxMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzd2lwZXJJbnN0YW5jZTogbnVsbCxcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBnZXREZWZhdWx0RWxlbWVudHMoKSB7XG4gICAgICAgIGNvbnN0IGVsZW1lbnQgPSB0aGlzLiRlbGVtZW50LmdldCgwKTtcbiAgICAgICAgY29uc3Qgc2VsZWN0b3JzID0gdGhpcy5nZXRTZXR0aW5ncyhcInNlbGVjdG9yc1wiKTtcblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgY2Fyb3VzZWw6IGVsZW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3RvcnMuY2Fyb3VzZWwpLFxuICAgICAgICAgICAgY2Fyb3VzZWxOZXh0QnRuOiBlbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3JzLmNhcm91c2VsTmV4dEJ0biksXG4gICAgICAgICAgICBjYXJvdXNlbFByZXZCdG46IGVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcnMuY2Fyb3VzZWxQcmV2QnRuKSxcbiAgICAgICAgICAgIGNhcm91c2VsUGFnaW5hdGlvbjogZWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9ycy5jYXJvdXNlbFBhZ2luYXRpb24pLFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIG9uSW5pdCguLi5hcmdzKSB7XG4gICAgICAgIHN1cGVyLm9uSW5pdCguLi5hcmdzKTtcblxuICAgICAgICB0aGlzLndpZGdldFVuaXF1ZUlEID0gdGhpcy5nZXRJRCgpO1xuXG4gICAgICAgIGlmICh0aGlzLmdldERlZmF1bHRFbGVtZW50cygpLmNhcm91c2VsKSB7XG4gICAgICAgICAgICB0aGlzLndpZGdldFNsaWRlcklEID0gdGhpcy5nZXREZWZhdWx0RWxlbWVudHMoKS5jYXJvdXNlbC5pZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIE9ubHkgYXR0ZW1wdCB0byBpbml0aWFsaXplIGlmIHRoZSBjYXJvdXNlbCBjb250YWluZXIgZXhpc3RzXG4gICAgICAgIGlmICghdGhpcy5nZXREZWZhdWx0RWxlbWVudHMoKS5jYXJvdXNlbCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2V0VXNlclNldHRpbmdzKCk7XG4gICAgICAgIHRoaXMuaW5pdFN3aXBlcigpO1xuICAgICAgICB0aGlzLnNldHVwRXZlbnRMaXN0ZW5lcnMoKTtcbiAgICAgICAgdGhpcy51cGRhdGVDYXJvdXNlbFN0eWxlcyh0aGlzLmdldFNldHRpbmdzKCkpO1xuICAgIH1cblxuXG4gICAgc2V0VXNlclNldHRpbmdzKCkge1xuICAgICAgICBjb25zdCBzZXR0aW5ncyA9IHRoaXMuZ2V0U2V0dGluZ3MoKTtcbiAgICAgICAgaWYgKCF0aGlzLmVsZW1lbnRzLmNhcm91c2VsKSByZXR1cm47IC8vIFNraXAgaWYgbm8gY2Fyb3VzZWwgY29udGFpbmVyXG4gICAgICAgIGNvbnN0IHVzZXJTZXR0aW5ncyA9IEpTT04ucGFyc2UodGhpcy5lbGVtZW50cy5jYXJvdXNlbC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXNldHRpbmdzXCIpKTtcblxuICAgICAgICB0aGlzLm9yaWdpbmFsQXV0b3BsYXlFbmFibGVkID0gdXNlclNldHRpbmdzLmF1dG9wbGF5ICYmIE51bWJlcih1c2VyU2V0dGluZ3MuYXV0b3BsYXkpID4gMDtcblxuICAgICAgICBjb25zdCBjdXJyZW50U2V0dGluZ3MgPSB7XG4gICAgICAgICAgICBlZmZlY3Q6ICEhdXNlclNldHRpbmdzLmVmZmVjdCA/IHVzZXJTZXR0aW5ncy5lZmZlY3QgOiBzZXR0aW5ncy5lZmZlY3QsXG4gICAgICAgICAgICBsb29wOiAhIXVzZXJTZXR0aW5ncy5sb29wID8gQm9vbGVhbihOdW1iZXIodXNlclNldHRpbmdzLmxvb3ApKSA6IHNldHRpbmdzLmxvb3AsXG4gICAgICAgICAgICBhdXRvcGxheTogISF1c2VyU2V0dGluZ3MuYXV0b3BsYXkgPyBOdW1iZXIodXNlclNldHRpbmdzLmF1dG9wbGF5KSA6IHNldHRpbmdzLmF1dG9wbGF5LFxuICAgICAgICAgICAgc3BlZWQ6ICEhdXNlclNldHRpbmdzLnNwZWVkID8gTnVtYmVyKHVzZXJTZXR0aW5ncy5zcGVlZCkgOiBzZXR0aW5ncy5zcGVlZCxcbiAgICAgICAgICAgIG5hdmlnYXRpb246ICEhdXNlclNldHRpbmdzLmFycm93cyA/IEJvb2xlYW4oTnVtYmVyKHVzZXJTZXR0aW5ncy5hcnJvd3MpKSA6IHNldHRpbmdzLm5hdmlnYXRpb24sXG4gICAgICAgICAgICBwYWdpbmF0aW9uOiAhIXVzZXJTZXR0aW5ncy5kb3RzID8gQm9vbGVhbihOdW1iZXIodXNlclNldHRpbmdzLmRvdHMpKSA6IHNldHRpbmdzLnBhZ2luYXRpb24sXG4gICAgICAgICAgICBwYXVzZU9uSG92ZXI6ICEhdXNlclNldHRpbmdzW1wicGF1c2Utb24taG92ZXJcIl1cbiAgICAgICAgICAgICAgICA/IEpTT04ucGFyc2UodXNlclNldHRpbmdzW1wicGF1c2Utb24taG92ZXJcIl0pXG4gICAgICAgICAgICAgICAgOiBzZXR0aW5ncy5wYXVzZU9uSG92ZXIsXG4gICAgICAgICAgICBzbGlkZXNQZXJWaWV3OiB7XG4gICAgICAgICAgICAgICAgd2lkZXNjcmVlbjogdXNlclNldHRpbmdzWydpdGVtcy13aWRlc2NyZWVuJ10gIT09IHVuZGVmaW5lZCA/IE51bWJlcih1c2VyU2V0dGluZ3NbJ2l0ZW1zLXdpZGVzY3JlZW4nXSkgOiBzZXR0aW5ncy5zbGlkZXNQZXJWaWV3Wyd3aWRlc2NyZWVuJ10sXG4gICAgICAgICAgICAgICAgZGVza3RvcDogdXNlclNldHRpbmdzWydpdGVtcyddICE9PSB1bmRlZmluZWQgPyBOdW1iZXIodXNlclNldHRpbmdzWydpdGVtcyddKSA6IHNldHRpbmdzLnNsaWRlc1BlclZpZXdbJ2Rlc2t0b3AnXSxcbiAgICAgICAgICAgICAgICBsYXB0b3A6IHVzZXJTZXR0aW5nc1snaXRlbXMtbGFwdG9wJ10gIT09IHVuZGVmaW5lZCA/IE51bWJlcih1c2VyU2V0dGluZ3NbJ2l0ZW1zLWxhcHRvcCddKSA6IHNldHRpbmdzLnNsaWRlc1BlclZpZXdbJ2xhcHRvcCddLFxuICAgICAgICAgICAgICAgIHRhYmxldDogdXNlclNldHRpbmdzWydpdGVtcy10YWJsZXQnXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKHVzZXJTZXR0aW5nc1snaXRlbXMtdGFibGV0J10pIDogc2V0dGluZ3Muc2xpZGVzUGVyVmlld1sndGFibGV0J10sXG4gICAgICAgICAgICAgICAgdGFibGV0X2V4dHJhOiB1c2VyU2V0dGluZ3NbJ2l0ZW1zLXRhYmxldF9leHRyYSddICE9PSB1bmRlZmluZWQgPyBOdW1iZXIodXNlclNldHRpbmdzWydpdGVtcy10YWJsZXRfZXh0cmEnXSkgOiBzZXR0aW5ncy5zbGlkZXNQZXJWaWV3Wyd0YWJsZXRfZXh0cmEnXSxcbiAgICAgICAgICAgICAgICBtb2JpbGU6IHVzZXJTZXR0aW5nc1snaXRlbXMtbW9iaWxlJ10gIT09IHVuZGVmaW5lZCA/IE51bWJlcih1c2VyU2V0dGluZ3NbJ2l0ZW1zLW1vYmlsZSddKSA6IHNldHRpbmdzLnNsaWRlc1BlclZpZXdbJ21vYmlsZSddLFxuICAgICAgICAgICAgICAgIG1vYmlsZV9leHRyYTogdXNlclNldHRpbmdzWydpdGVtcy1tb2JpbGVfZXh0cmEnXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKHVzZXJTZXR0aW5nc1snaXRlbXMtbW9iaWxlX2V4dHJhJ10pIDogc2V0dGluZ3Muc2xpZGVzUGVyVmlld1snbW9iaWxlX2V4dHJhJ11cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzbGlkZXNQZXJHcm91cDoge1xuICAgICAgICAgICAgICAgIHdpZGVzY3JlZW46ICEhdXNlclNldHRpbmdzWydzbGlkZXMtd2lkZXNjcmVlbiddID8gTnVtYmVyKHVzZXJTZXR0aW5nc1snc2xpZGVzLXdpZGVzY3JlZW4nXSkgOiBzZXR0aW5ncy5zbGlkZXNQZXJHcm91cC53aWRlc2NyZWVuLFxuICAgICAgICAgICAgICAgIGRlc2t0b3A6ICEhdXNlclNldHRpbmdzWydzbGlkZXMnXSA/IE51bWJlcih1c2VyU2V0dGluZ3NbJ3NsaWRlcyddKSA6IHNldHRpbmdzLnNsaWRlc1Blckdyb3VwLmRlc2t0b3AsXG4gICAgICAgICAgICAgICAgbGFwdG9wOiAhIXVzZXJTZXR0aW5nc1snc2xpZGVzLWxhcHRvcCddID8gTnVtYmVyKHVzZXJTZXR0aW5nc1snc2xpZGVzLWxhcHRvcCddKSA6IHNldHRpbmdzLnNsaWRlc1Blckdyb3VwLmxhcHRvcCxcbiAgICAgICAgICAgICAgICB0YWJsZXQ6ICEhdXNlclNldHRpbmdzW1wic2xpZGVzLXRhYmxldFwiXVxuICAgICAgICAgICAgICAgICAgICA/IE51bWJlcih1c2VyU2V0dGluZ3NbXCJzbGlkZXMtdGFibGV0XCJdKVxuICAgICAgICAgICAgICAgICAgICA6IHNldHRpbmdzLnNsaWRlc1Blckdyb3VwLnRhYmxldCxcbiAgICAgICAgICAgICAgICB0YWJsZXRfZXh0cmE6ICEhdXNlclNldHRpbmdzW1wic2xpZGVzLXRhYmxldF9leHRyYVwiXVxuICAgICAgICAgICAgICAgICAgICA/IE51bWJlcih1c2VyU2V0dGluZ3NbXCJzbGlkZXMtdGFibGV0X2V4dHJhXCJdKVxuICAgICAgICAgICAgICAgICAgICA6IHNldHRpbmdzLnNsaWRlc1Blckdyb3VwLnRhYmxldF9leHRyYSxcbiAgICAgICAgICAgICAgICBtb2JpbGU6ICEhdXNlclNldHRpbmdzW1wic2xpZGVzLW1vYmlsZVwiXVxuICAgICAgICAgICAgICAgICAgICA/IE51bWJlcih1c2VyU2V0dGluZ3NbXCJzbGlkZXMtbW9iaWxlXCJdKVxuICAgICAgICAgICAgICAgICAgICA6IHNldHRpbmdzLnNsaWRlc1Blckdyb3VwLm1vYmlsZSxcbiAgICAgICAgICAgICAgICBtb2JpbGVfZXh0cmE6ICEhdXNlclNldHRpbmdzW1wic2xpZGVzLW1vYmlsZV9leHRyYVwiXVxuICAgICAgICAgICAgICAgICAgICA/IE51bWJlcih1c2VyU2V0dGluZ3NbXCJzbGlkZXMtbW9iaWxlX2V4dHJhXCJdKVxuICAgICAgICAgICAgICAgICAgICA6IHNldHRpbmdzLnNsaWRlc1Blckdyb3VwLm1vYmlsZV9leHRyYSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzcGFjZUJldHdlZW46IHtcbiAgICAgICAgICAgICAgICB3aWRlc2NyZWVuOiB1c2VyU2V0dGluZ3NbJ21hcmdpbi13aWRlc2NyZWVuJ10gIT09IHVuZGVmaW5lZCA/IE51bWJlcih1c2VyU2V0dGluZ3NbJ21hcmdpbi13aWRlc2NyZWVuJ10pIDogc2V0dGluZ3Muc3BhY2VCZXR3ZWVuLndpZGVzY3JlZW4sXG4gICAgICAgICAgICAgICAgZGVza3RvcDogdXNlclNldHRpbmdzWydtYXJnaW4nXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKHVzZXJTZXR0aW5nc1snbWFyZ2luJ10pIDogc2V0dGluZ3Muc3BhY2VCZXR3ZWVuLmRlc2t0b3AsXG4gICAgICAgICAgICAgICAgbGFwdG9wOiB1c2VyU2V0dGluZ3NbJ21hcmdpbi1sYXB0b3AnXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKHVzZXJTZXR0aW5nc1snbWFyZ2luLWxhcHRvcCddKSA6IHNldHRpbmdzLnNwYWNlQmV0d2Vlbi5sYXB0b3AsXG4gICAgICAgICAgICAgICAgdGFibGV0OiB1c2VyU2V0dGluZ3NbXCJtYXJnaW4tdGFibGV0XCJdICE9PSB1bmRlZmluZWQgPyBOdW1iZXIodXNlclNldHRpbmdzW1wibWFyZ2luLXRhYmxldFwiXSkgOiBzZXR0aW5ncy5zcGFjZUJldHdlZW4udGFibGV0LFxuICAgICAgICAgICAgICAgIHRhYmxldF9leHRyYTogdXNlclNldHRpbmdzW1wibWFyZ2luLXRhYmxldF9leHRyYVwiXSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKHVzZXJTZXR0aW5nc1tcIm1hcmdpbi10YWJsZXRfZXh0cmFcIl0pIDogc2V0dGluZ3Muc3BhY2VCZXR3ZWVuLnRhYmxldF9leHRyYSxcbiAgICAgICAgICAgICAgICBtb2JpbGU6IHVzZXJTZXR0aW5nc1tcIm1hcmdpbi1tb2JpbGVcIl0gIT09IHVuZGVmaW5lZCA/IE51bWJlcih1c2VyU2V0dGluZ3NbXCJtYXJnaW4tbW9iaWxlXCJdKSA6IHNldHRpbmdzLnNwYWNlQmV0d2Vlbi5tb2JpbGUsXG4gICAgICAgICAgICAgICAgbW9iaWxlX2V4dHJhOiB1c2VyU2V0dGluZ3NbXCJtYXJnaW4tbW9iaWxlX2V4dHJhXCJdICE9PSB1bmRlZmluZWQgPyBOdW1iZXIodXNlclNldHRpbmdzW1wibWFyZ2luLW1vYmlsZV9leHRyYVwiXSkgOiBzZXR0aW5ncy5zcGFjZUJldHdlZW4ubW9iaWxlX2V4dHJhLFxuXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcblxuICAgICAgICBjdXJyZW50U2V0dGluZ3MuY2VudGVyZWRTbGlkZXMgPSBjdXJyZW50U2V0dGluZ3MuZWZmZWN0ID09PSBcImNvdmVyZmxvd1wiID8gdHJ1ZSA6IHNldHRpbmdzLmNlbnRlcmVkU2xpZGVzO1xuXG4gICAgICAgIHRoaXMuc2V0U2V0dGluZ3MoY3VycmVudFNldHRpbmdzKTtcblxuICAgIH1cblxuICAgIHVwZGF0ZUNhcm91c2VsU3R5bGVzKHNldHRpbmdzKSB7XG4gICAgICBjb25zdCB7IHNwYWNlQmV0d2VlbiB9ID0gc2V0dGluZ3M7XG5cblxuICAgICAgaWYgKHNwYWNlQmV0d2Vlbi5kZXNrdG9wID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5lbGVtZW50cy5jYXJvdXNlbC5xdWVyeVNlbGVjdG9yQWxsKCcub2V3LWNhcm91c2VsLXNsaWRlJykuZm9yRWFjaChzbGlkZSA9PiB7XG4gICAgICAgICAgICAgIHNsaWRlLnN0eWxlLm1hcmdpblJpZ2h0ID0gXCIwcHhcIjtcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGlmIChzcGFjZUJldHdlZW4udGFibGV0ID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5lbGVtZW50cy5jYXJvdXNlbC5xdWVyeVNlbGVjdG9yQWxsKCcub2V3LWNhcm91c2VsLXNsaWRlJykuZm9yRWFjaChzbGlkZSA9PiB7XG4gICAgICAgICAgICAgIHNsaWRlLnN0eWxlLm1hcmdpblJpZ2h0ID0gXCIwcHhcIjtcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGlmIChzcGFjZUJldHdlZW4ubW9iaWxlID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5lbGVtZW50cy5jYXJvdXNlbC5xdWVyeVNlbGVjdG9yQWxsKCcub2V3LWNhcm91c2VsLXNsaWRlJykuZm9yRWFjaChzbGlkZSA9PiB7XG4gICAgICAgICAgICAgIHNsaWRlLnN0eWxlLm1hcmdpblJpZ2h0ID0gXCIwcHhcIjtcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgfVxuXG5cbiAgICBpbml0U3dpcGVyKCkge1xuICAgICAgICBjb25zdCBzd2lwZXIgPSBuZXcgU3dpcGVyKHRoaXMuZWxlbWVudHMuY2Fyb3VzZWwsIHRoaXMuc3dpcGVyT3B0aW9ucygpKTtcblxuICAgICAgICB0aGlzLnNldFNldHRpbmdzKHtcbiAgICAgICAgICAgIHN3aXBlckluc3RhbmNlOiBzd2lwZXIsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHN3aXBlck9wdGlvbnMoKSB7XG4gICAgICAgIGNvbnN0IHNldHRpbmdzID0gdGhpcy5nZXRTZXR0aW5ncygpO1xuXG4gICAgICAgIGNvbnN0IHN3aXBlck9wdGlvbnMgPSB7XG4gICAgICAgICAgICBkaXJlY3Rpb246IFwiaG9yaXpvbnRhbFwiLFxuICAgICAgICAgICAgZWZmZWN0OiBzZXR0aW5ncy5lZmZlY3QsXG4gICAgICAgICAgICBsb29wOiBzZXR0aW5ncy5sb29wLFxuICAgICAgICAgICAgc3BlZWQ6IHNldHRpbmdzLnNwZWVkLFxuICAgICAgICAgICAgY2VudGVyZWRTbGlkZXM6IHNldHRpbmdzLmNlbnRlcmVkU2xpZGVzLFxuICAgICAgICAgICAgYXV0b0hlaWdodDogdHJ1ZSxcbiAgICAgICAgICAgIGF1dG9wbGF5OiAhc2V0dGluZ3MuYXV0b3BsYXlcbiAgICAgICAgICAgICAgICA/IGZhbHNlXG4gICAgICAgICAgICAgICAgOiB7XG4gICAgICAgICAgICAgICAgICAgICAgZGVsYXk6IHNldHRpbmdzLmF1dG9wbGF5LFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG5hdmlnYXRpb246ICFzZXR0aW5ncy5uYXZpZ2F0aW9uXG4gICAgICAgICAgICAgICAgPyBmYWxzZVxuICAgICAgICAgICAgICAgIDoge1xuICAgICAgICAgICAgICAgICAgICAgIG5leHRFbDogc2V0dGluZ3Muc2VsZWN0b3JzLmNhcm91c2VsTmV4dEJ0bixcbiAgICAgICAgICAgICAgICAgICAgICBwcmV2RWw6IHNldHRpbmdzLnNlbGVjdG9ycy5jYXJvdXNlbFByZXZCdG4sXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgcGFnaW5hdGlvbjogIXNldHRpbmdzLnBhZ2luYXRpb25cbiAgICAgICAgICAgICAgICA/IGZhbHNlXG4gICAgICAgICAgICAgICAgOiB7XG4gICAgICAgICAgICAgICAgICAgICAgZWw6IHNldHRpbmdzLnNlbGVjdG9ycy5jYXJvdXNlbFBhZ2luYXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgY2xpY2thYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBGZXRjaCBFbGVtZW50b3IncyByZXNwb25zaXZlIGJyZWFrcG9pbnRzXG4gICAgICAgIHZhciBicmVha3BvaW50cyA9IGVsZW1lbnRvckZyb250ZW5kLmNvbmZpZy5yZXNwb25zaXZlLmFjdGl2ZUJyZWFrcG9pbnRzO1xuICAgICAgICB2YXIgYnJlYWtwb2ludHNCb290c3RyYXAgPSBlbGVtZW50b3JGcm9udGVuZC5jb25maWcuYnJlYWtwb2ludHM7XG5cbiAgICAgICAgaWYgKHNldHRpbmdzLmVmZmVjdCA9PT0gXCJmYWRlXCIpIHtcbiAgICAgICAgICAgIHN3aXBlck9wdGlvbnMuaXRlbXMgPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN3aXBlck9wdGlvbnMuYnJlYWtwb2ludHMgPSB7fTtcblxuICAgICAgICAgICAgbGV0IGRldmljZXNCcmVha1BvaW50cyA9IFtdO1xuICAgICAgICAgICAgZm9yIChsZXQgZGV2aWNlTmFtZSBpbiBicmVha3BvaW50cykge1xuICAgICAgICAgICAgICBsZXQgbWF4X3dpZHRoID0gYnJlYWtwb2ludHNbZGV2aWNlTmFtZV1bJ2RlZmF1bHRfdmFsdWUnXTtcbiAgICAgICAgICAgICAgaWYoIGJyZWFrcG9pbnRzW2RldmljZU5hbWVdWyd2YWx1ZSddICE9PSB1bmRlZmluZWQgKSB7XG4gICAgICAgICAgICAgICAgbWF4X3dpZHRoID0gYnJlYWtwb2ludHNbZGV2aWNlTmFtZV1bJ3ZhbHVlJ107XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZGV2aWNlc0JyZWFrUG9pbnRzLnB1c2goe1xuICAgICAgICAgICAgICAgICdsYWJlbCcgOiBkZXZpY2VOYW1lLFxuICAgICAgICAgICAgICAgICdtYXhfd2lkdGgnIDogbWF4X3dpZHRoXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGV2aWNlc0JyZWFrUG9pbnRzLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIGEubWF4X3dpZHRoIC0gYi5tYXhfd2lkdGhcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBsZXQgdG1wU2xpZGVzUGVyVmlldyA9IDA7XG5cbiAgICAgICAgICAgIGxldCBkZXNrdG9wV2lkdGggPSBicmVha3BvaW50c0Jvb3RzdHJhcC5sZztcbiAgICAgICAgICAgIGZvciAobGV0IGRldmljZXNCcmVha1BvaW50SXRlbSBvZiBkZXZpY2VzQnJlYWtQb2ludHMpIHtcblxuICAgICAgICAgICAgICBsZXQgcmVzcG9uc2l2S2V5U2V0dGluZyA9IGRldmljZXNCcmVha1BvaW50SXRlbS5sYWJlbDtcblxuICAgICAgICAgICAgICBpZiggc2V0dGluZ3Muc2xpZGVzUGVyVmlld1tyZXNwb25zaXZLZXlTZXR0aW5nXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgc3dpcGVyT3B0aW9ucy5icmVha3BvaW50c1t0bXBTbGlkZXNQZXJWaWV3XSA9IHtcbiAgICAgICAgICAgICAgICAgIHNsaWRlc1BlclZpZXc6IHNldHRpbmdzLnNsaWRlc1BlclZpZXdbcmVzcG9uc2l2S2V5U2V0dGluZ10sXG4gICAgICAgICAgICAgICAgICBzbGlkZXNQZXJHcm91cDogc2V0dGluZ3Muc2xpZGVzUGVyR3JvdXBbcmVzcG9uc2l2S2V5U2V0dGluZ10sXG4gICAgICAgICAgICAgICAgICBzcGFjZUJldHdlZW46IHNldHRpbmdzLnNwYWNlQmV0d2VlbltyZXNwb25zaXZLZXlTZXR0aW5nXSxcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgaWYoIHJlc3BvbnNpdktleVNldHRpbmcgPT09ICd3aWRlc2NyZWVuJyApIHtcbiAgICAgICAgICAgICAgICAgIGRlc2t0b3BXaWR0aCA9IHRtcFNsaWRlc1BlclZpZXc7XG4gICAgICAgICAgICAgICAgICB0bXBTbGlkZXNQZXJWaWV3ID0gZGV2aWNlc0JyZWFrUG9pbnRJdGVtWydtYXhfd2lkdGgnXTtcbiAgICAgICAgICAgICAgICAgIHN3aXBlck9wdGlvbnMuYnJlYWtwb2ludHNbdG1wU2xpZGVzUGVyVmlld10gPSB7XG4gICAgICAgICAgICAgICAgICAgIHNsaWRlc1BlclZpZXc6IHNldHRpbmdzLnNsaWRlc1BlclZpZXdbcmVzcG9uc2l2S2V5U2V0dGluZ10sXG4gICAgICAgICAgICAgICAgICAgIHNsaWRlc1Blckdyb3VwOiBzZXR0aW5ncy5zbGlkZXNQZXJHcm91cFtyZXNwb25zaXZLZXlTZXR0aW5nXSxcbiAgICAgICAgICAgICAgICAgICAgc3BhY2VCZXR3ZWVuOiBzZXR0aW5ncy5zcGFjZUJldHdlZW5bcmVzcG9uc2l2S2V5U2V0dGluZ10sXG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB0bXBTbGlkZXNQZXJWaWV3ID0gcGFyc2VJbnQoZGV2aWNlc0JyZWFrUG9pbnRJdGVtWydtYXhfd2lkdGgnXSkgKyAxO1xuICAgICAgICAgICAgICAgICAgZGVza3RvcFdpZHRoID0gdG1wU2xpZGVzUGVyVmlldztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc3dpcGVyT3B0aW9ucy5icmVha3BvaW50c1tkZXNrdG9wV2lkdGhdID0ge1xuICAgICAgICAgICAgICBzbGlkZXNQZXJWaWV3OiBzZXR0aW5ncy5zbGlkZXNQZXJWaWV3WydkZXNrdG9wJ10sXG4gICAgICAgICAgICAgIHNsaWRlc1Blckdyb3VwOiBzZXR0aW5ncy5zbGlkZXNQZXJHcm91cFsnZGVza3RvcCddLFxuICAgICAgICAgICAgICBzcGFjZUJldHdlZW46IHNldHRpbmdzLnNwYWNlQmV0d2VlblsnZGVza3RvcCddLFxuICAgICAgICAgICAgfTtcblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHN3aXBlck9wdGlvbnM7XG4gICAgfVxuXG4gICAgc2V0dXBFdmVudExpc3RlbmVycygpIHtcbiAgICAgIC8vIElmIGF1dG9wbGF5IHBhdXNlT25Ib3ZlciBpcyBlbmFibGVkXG4gICAgICBpZiAodGhpcy5vcmlnaW5hbEF1dG9wbGF5RW5hYmxlZCAmJiB0aGlzLmdldFNldHRpbmdzKFwicGF1c2VPbkhvdmVyXCIpICYmIHRoaXMuZWxlbWVudHMuY2Fyb3VzZWwpIHtcbiAgICAgICAgICB0aGlzLmVsZW1lbnRzLmNhcm91c2VsLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWVudGVyXCIsIHRoaXMucGF1c2VTd2lwZXIuYmluZCh0aGlzKSk7XG4gICAgICAgICAgdGhpcy5lbGVtZW50cy5jYXJvdXNlbC5hZGRFdmVudExpc3RlbmVyKFwibW91c2VsZWF2ZVwiLCB0aGlzLnJlc3VtZVN3aXBlci5iaW5kKHRoaXMpKTtcbiAgICAgIH1cblxuICAgICAgLy8gVXNlIGpRdWVyeSBldmVudCBiaW5kaW5nIG9uIGRvY3VtZW50LmJvZHlcbiAgICAgIGpRdWVyeShkb2N1bWVudC5ib2R5KS5vbigndXBkYXRlZF93Y19kaXYnLCAoKSA9PiB7XG5cbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5vbkNhcnRVcGRhdGVkKCk7XG4gICAgICAgICAgfSwgMTAwKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIG9uQ2FydFVwZGF0ZWQoKSB7XG4gICAgICBjb25zdCBzd2lwZXJJbnN0YW5jZSA9IHRoaXMuZ2V0U2V0dGluZ3MoXCJzd2lwZXJJbnN0YW5jZVwiKTtcblxuICAgICAgaWYgKHN3aXBlckluc3RhbmNlKSB7XG4gICAgICAgICAgc3dpcGVySW5zdGFuY2UuZGVzdHJveSh0cnVlLCB0cnVlKTtcbiAgICAgICAgICB0aGlzLnNldFNldHRpbmdzKHsgc3dpcGVySW5zdGFuY2U6IG51bGwgfSk7XG4gICAgICB9XG5cbiAgICAgIGxldCAkc2xpZGVyID0galF1ZXJ5KCcjJyArIHRoaXMud2lkZ2V0U2xpZGVySUQpO1xuICAgICAgaWYgKCEkc2xpZGVyIHx8ICRzbGlkZXIubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBsZXQgJHdpZGdldENvbnRhaW5lciA9ICRzbGlkZXIuY2xvc2VzdCgnLmVsZW1lbnRvci13aWRnZXQtb2V3LXdvby1zbGlkZXInKTtcblxuICAgICAgdGhpcy4kZWxlbWVudCA9ICR3aWRnZXRDb250YWluZXIubGVuZ3RoID8gJHdpZGdldENvbnRhaW5lciA6ICRzbGlkZXI7XG5cbiAgICAgIHRoaXMuZWxlbWVudHMgPSB0aGlzLmdldERlZmF1bHRFbGVtZW50cygpO1xuXG4gICAgICBpZiAoIXRoaXMuZWxlbWVudHMuY2Fyb3VzZWwpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHRoaXMuc2V0VXNlclNldHRpbmdzKCk7XG4gICAgICB0aGlzLmluaXRTd2lwZXIoKTtcbiAgICAgIHRoaXMudXBkYXRlQ2Fyb3VzZWxTdHlsZXModGhpcy5nZXRTZXR0aW5ncygpKTtcbiAgICB9XG5cbiAgICBwYXVzZVN3aXBlcigpIHtcbiAgICAgIGlmICh0aGlzLmdldFNldHRpbmdzKFwic3dpcGVySW5zdGFuY2VcIikuYXV0b3BsYXkucnVubmluZykge1xuICAgICAgICAgIHRoaXMuZ2V0U2V0dGluZ3MoXCJzd2lwZXJJbnN0YW5jZVwiKS5hdXRvcGxheS5zdG9wKCk7XG4gICAgICB9XG4gICAgfVxuXG4gIHJlc3VtZVN3aXBlcigpIHtcbiAgICAgIGlmICghdGhpcy5nZXRTZXR0aW5ncyhcInN3aXBlckluc3RhbmNlXCIpLmF1dG9wbGF5LnJ1bm5pbmcpIHtcbiAgICAgICAgICB0aGlzLmdldFNldHRpbmdzKFwic3dpcGVySW5zdGFuY2VcIikuYXV0b3BsYXkuc3RhcnQoKTtcbiAgICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBPRVdfQ2Fyb3VzZWw7XG4iLCJpbXBvcnQgeyByZWdpc3RlcldpZGdldCB9IGZyb20gXCIuLi9saWIvdXRpbHNcIjtcbmltcG9ydCBPRVdfQ2Fyb3VzZWwgZnJvbSBcIi4vYmFzZS9jYXJvdXNlbFwiO1xuXG5jbGFzcyBPRVdfTWVtYmVyQ2Fyb3VzZWwgZXh0ZW5kcyBPRVdfQ2Fyb3VzZWwge31cblxucmVnaXN0ZXJXaWRnZXQoT0VXX01lbWJlckNhcm91c2VsLCBcIm9ldy1tZW1iZXItY2Fyb3VzZWxcIik7XG4iXX0=
