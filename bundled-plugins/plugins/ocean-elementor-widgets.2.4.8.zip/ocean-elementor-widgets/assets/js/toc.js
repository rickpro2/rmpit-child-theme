(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerWidget = exports.isElement = exports.getSiblings = exports.visible = exports.offset = exports.fadeToggle = exports.fadeOut = exports.fadeIn = exports.slideToggle = exports.slideUp = exports.slideDown = void 0;

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var slideDown = function slideDown(element) {
  var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  var display = window.getComputedStyle(element).display;

  if (display === "none") {
    display = "block";
  }

  element.style.transitionProperty = "height";
  element.style.transitionDuration = "".concat(duration, "ms");
  element.style.opacity = 0;
  element.style.display = display;
  var height = element.offsetHeight;
  element.style.height = 0;
  element.style.opacity = 1;
  element.style.overflow = "hidden";
  setTimeout(function () {
    element.style.height = "".concat(height, "px");
  }, 5);
  window.setTimeout(function () {
    element.style.removeProperty("height");
    element.style.removeProperty("overflow");
    element.style.removeProperty("transition-duration");
    element.style.removeProperty("transition-property");
    element.style.removeProperty("opacity");
  }, duration + 50);
};

exports.slideDown = slideDown;

var slideUp = function slideUp(element) {
  var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 300;
  element.style.boxSizing = "border-box";
  element.style.transitionProperty = "height, margin";
  element.style.transitionDuration = "".concat(duration, "ms");
  element.style.height = "".concat(element.offsetHeight, "px");
  element.style.marginTop = 0;
  element.style.marginBottom = 0;
  element.style.overflow = "hidden";
  setTimeout(function () {
    element.style.height = 0;
  }, 5);
  window.setTimeout(function () {
    element.style.display = "none";
    element.style.removeProperty("height");
    element.style.removeProperty("margin-top");
    element.style.removeProperty("margin-bottom");
    element.style.removeProperty("overflow");
    element.style.removeProperty("transition-duration");
    element.style.removeProperty("transition-property");
  }, duration + 50);
};

exports.slideUp = slideUp;

var slideToggle = function slideToggle(element, duration) {
  window.getComputedStyle(element).display === "none" ? slideDown(element, duration) : slideUp(element, duration);
};

exports.slideToggle = slideToggle;

var fadeIn = function fadeIn(element) {
  var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = {
    duration: 300,
    display: null,
    opacity: 1,
    callback: null
  };
  Object.assign(options, _options);
  element.style.opacity = 0;
  element.style.display = options.display || "block";
  setTimeout(function () {
    element.style.transition = "".concat(options.duration, "ms opacity ease");
    element.style.opacity = options.opacity;
  }, 5);
  setTimeout(function () {
    element.style.removeProperty("transition");
    !!options.callback && options.callback();
  }, options.duration + 50);
};

exports.fadeIn = fadeIn;

var fadeOut = function fadeOut(element) {
  var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var options = {
    duration: 300,
    display: null,
    opacity: 0,
    callback: null
  };
  Object.assign(options, _options);
  element.style.opacity = 1;
  element.style.display = options.display || "block";
  setTimeout(function () {
    element.style.transition = "".concat(options.duration, "ms opacity ease");
    element.style.opacity = options.opacity;
  }, 5);
  setTimeout(function () {
    element.style.display = "none";
    element.style.removeProperty("transition");
    !!options.callback && options.callback();
  }, options.duration + 50);
};

exports.fadeOut = fadeOut;

var fadeToggle = function fadeToggle(element, options) {
  window.getComputedStyle(element).display === "none" ? fadeIn(element, options) : fadeOut(element, options);
};

exports.fadeToggle = fadeToggle;

var offset = function offset(element) {
  if (!element.getClientRects().length) {
    return {
      top: 0,
      left: 0
    };
  } // Get document-relative position by adding viewport scroll to viewport-relative gBCR


  var rect = element.getBoundingClientRect();
  var win = element.ownerDocument.defaultView;
  return {
    top: rect.top + win.pageYOffset,
    left: rect.left + win.pageXOffset
  };
};

exports.offset = offset;

var visible = function visible(element) {
  if (!element) {
    return false;
  }

  return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
};

exports.visible = visible;

var getSiblings = function getSiblings(e) {
  // for collecting siblings
  var siblings = []; // if no parent, return no sibling

  if (!e.parentNode) {
    return siblings;
  } // first child of the parent node


  var sibling = e.parentNode.firstChild; // collecting siblings

  while (sibling) {
    if (sibling.nodeType === 1 && sibling !== e) {
      siblings.push(sibling);
    }

    sibling = sibling.nextSibling;
  }

  return siblings;
}; // Returns true if it is a DOM element


exports.getSiblings = getSiblings;

var isElement = function isElement(o) {
  return (typeof HTMLElement === "undefined" ? "undefined" : _typeof(HTMLElement)) === "object" ? o instanceof HTMLElement // DOM2
  : o && _typeof(o) === "object" && o !== null && o.nodeType === 1 && typeof o.nodeName === "string";
};

exports.isElement = isElement;

var registerWidget = function registerWidget(className, widgetName) {
  var skin = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "default";

  if (!(className || widgetName)) {
    return;
  }
  /**
   * Because Elementor plugin uses jQuery custom event,
   * We also have to use jQuery to use this event
   */


  jQuery(window).on("elementor/frontend/init", function () {
    var addHandler = function addHandler($element) {
      elementorFrontend.elementsHandler.addHandler(className, {
        $element: $element
      });
    };

    elementorFrontend.hooks.addAction("frontend/element_ready/".concat(widgetName, ".").concat(skin), addHandler);
  });
};

exports.registerWidget = registerWidget;

},{}],2:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var _utils = require("../lib/utils");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var OEW_TOC = /*#__PURE__*/function (_elementorModules$fro) {
  _inherits(OEW_TOC, _elementorModules$fro);

  var _super = _createSuper(OEW_TOC);

  function OEW_TOC() {
    _classCallCheck(this, OEW_TOC);

    return _super.apply(this, arguments);
  }

  _createClass(OEW_TOC, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      var elementSettings = this.getElementSettings(),
          listWrapperTag = 'numbers' === elementSettings.marker_view ? 'ol' : 'ul';
      return {
        selectors: {
          widgetTocContainer: '.elementor-widget-oew-toc',
          postContentContainer: '.elementor:not([data-elementor-type="header"]):not([data-elementor-type="footer"]):not([data-elementor-type="popup"])',
          expandButton: '.oew-toc-toggle-button-expand',
          collapseButton: '.oew-toc-toggle-button-collapse',
          body: '.oew-toc-body',
          headerTitle: '.oew-toc-header-title'
        },
        classes: {
          anchor: 'elementor-menu-anchor',
          listWrapper: 'oew-toc-list-wrapper',
          listItem: 'oew-toc-list-item',
          listTextWrapper: 'oew-toc-list-item-text-wrapper',
          firstLevelListItem: 'oew-toc-top-level',
          listItemText: 'oew-toc-list-item-text',
          activeItem: 'elementor-item-active',
          headingAnchor: 'oew-toc-heading-anchor',
          collapsed: 'oew-toc-collapsed'
        },
        listWrapperTag: listWrapperTag
      };
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      var settings = this.getSettings();
      return {
        $pageContainer: this.getTocContainer(),
        $widgetTocContainer: this.$element.find(settings.selectors.widgetTocContainer),
        $expandButton: this.$element.find(settings.selectors.expandButton),
        $collapseButton: this.$element.find(settings.selectors.collapseButton),
        $tocBody: this.$element.find(settings.selectors.body),
        $listItems: this.$element.find('.' + settings.classes.listItem)
      };
    }
  }, {
    key: "getTocContainer",
    value: function getTocContainer() {
      var settings = this.getSettings(),
          elementSettings = this.getElementSettings();

      if (elementSettings.container) {
        return jQuery(elementSettings.container);
      }

      var $documentWrapper = this.$element.parents('.elementor');

      if ('popup' === $documentWrapper.attr('data-elementor-type')) {
        return $documentWrapper;
      }

      return jQuery(settings.selectors.postContentContainer);
    }
  }, {
    key: "bindEvents",
    value: function bindEvents() {
      var _this = this;

      var elementSettings = this.getElementSettings();

      if (elementSettings.minimize_box) {
        this.elements.$expandButton.on('click', function () {
          return _this.expandTocBox();
        });
        this.elements.$collapseButton.on('click', function () {
          return _this.collapseTocBox();
        });
      }

      if (elementSettings.collapse_subitems) {
        this.elements.$listItems.hover(function (event) {
          return jQuery(event.target).slideToggle();
        });
      }
    }
  }, {
    key: "getHeadings",
    value: function getHeadings() {
      // Get all headings from document by user-selected tags
      var elementSettings = this.getElementSettings(),
          tags = elementSettings.headings_by_tags.join(','),
          selectors = this.getSettings('selectors'),
          excludedSelectors = elementSettings.exclude_headings_by_selector;
      return this.elements.$pageContainer.find(tags).not(selectors.headerTitle).filter(function (index, heading) {
        return !jQuery(heading).closest(excludedSelectors).length; // Handle excluded selectors if there are any
      });
    }
  }, {
    key: "addAnchorsBeforeHeadings",
    value: function addAnchorsBeforeHeadings() {
      // Add an anchor element right before each TOC heading to create anchors for TOC links
      var classes = this.getSettings('classes');
      var elementSettings = this.getElementSettings();
      this.elements.$headings.each(function (index) {
        if (elementSettings.duplicate_anchor_fix == 'yes') {
          var anchorText = this.textContent.replace(/\s+/g, '-').replace(/[^\w-]+/g, '').toLowerCase() + '-' + index;
        } else {
          var anchorText = this.textContent.replace(/\s+/g, '-').replace(/[^\w-]+/g, '').toLowerCase();
        }

        this.setAttribute('id', anchorText);
      });
    }
  }, {
    key: "_getPrototypeOf",
    value: function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    }
  }, {
    key: "onInit",
    value: function onInit() {
      var _get2,
          _this6 = this;

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      (_get2 = (0, this._get3)((0, this._getPrototypeOf)(OEW_TOC.prototype), "onInit", this)).call.apply(_get2, [this].concat(args));

      this.viewportItems = [];
      jQuery(document).ready(function () {
        return _this6.run();
      });
    }
  }, {
    key: "onListItemClick",
    value: function onListItemClick(event) {
      var _this7 = this;

      this.itemClicked = true;
      setTimeout(function () {
        return _this7.itemClicked = false;
      }, 2000);
      var $clickedItem = jQuery(event.currentTarget),
          $list = $clickedItem.parent().next(),
          collapseNestedList = this.getElementSettings('collapse_subitems');
      var listIsActive;

      if (collapseNestedList && $clickedItem.hasClass(this.getSettings('classes.firstLevelListItem'))) {
        if ($list.is(':visible')) {
          listIsActive = true;
        }
      }

      this.activateTocItem($clickedItem);

      if (collapseNestedList && listIsActive) {
        $list.slideUp();
      }
    }
  }, {
    key: "activateTocItem",
    value: function activateTocItem($listItem) {
      var classes = this.getSettings('classes');
      this.deactivateTocActiveItem($listItem);
      $listItem.addClass(classes.activeItem);
      this.$activeItem = $listItem;

      if (!this.getElementSettings('collapse_subitems')) {
        return;
      }

      var $activeList;

      if ($listItem.hasClass(classes.firstLevelListItem)) {
        $activeList = $listItem.parent().next();
      } else {
        $activeList = $listItem.parents('.' + classes.listWrapper).eq(-2);
      }

      if (!$activeList.length) {
        delete this.$activeList;
        return;
      }

      this.$activeList = $activeList;
      this.$activeList.stop().slideDown();
    }
  }, {
    key: "deactivateTocActiveItem",
    value: function deactivateTocActiveItem($activeToBe) {
      if (!this.$activeItem || this.$activeItem.is($activeToBe)) {
        return;
      }

      var _this$getSettings = this.getSettings(),
          classes = _this$getSettings.classes;

      this.$activeItem.removeClass(classes.activeItem);

      if (this.$activeList && (!$activeToBe || !this.$activeList[0].contains($activeToBe[0]))) {
        this.$activeList.slideUp();
      }
    }
  }, {
    key: "followTocAnchor",
    value: function followTocAnchor($element, index) {
      var _this2 = this;

      var anchorSelector = $element[0].hash;
      var $anchor;

      try {
        // `decodeURIComponent` for UTF8 characters in the hash.
        $anchor = jQuery(decodeURIComponent(anchorSelector));
      } catch (e) {
        return;
      } // Implement Intersection Observer instead of Waypoint


      var observerOptions = {
        root: null,
        // viewport
        rootMargin: '0px',
        threshold: 0.1 // trigger when 10% of the element is visible

      };

      var callback = function callback(entries) {
        entries.forEach(function (entry) {
          if (_this2.itemClicked) {
            return;
          }

          var id = entry.target.getAttribute('id');

          if (entry.isIntersecting) {
            if (entry.boundingClientRect.top > 0) {
              // Scrolling down
              _this2.viewportItems[id] = true;

              _this2.activateTocItem($element);
            }
          } else {
            if (entry.boundingClientRect.top < 0) {
              // Scrolling up
              delete _this2.viewportItems[id];

              _this2.activateTocItem(_this2.$listItemTexts.eq(index - 1));
            }
          }
        });
      };

      var observer = new IntersectionObserver(callback, observerOptions);
      var target = document.getElementById(anchorSelector.replace('#', ''));

      if (target) {
        observer.observe(target);
      }
    }
  }, {
    key: "followTocAnchors",
    value: function followTocAnchors() {
      var _this3 = this;

      this.$listItemTexts.each(function (index, element) {
        return _this3.followTocAnchor(jQuery(element), index);
      });
    }
  }, {
    key: "populateTOC",
    value: function populateTOC() {
      this.listItemPointer = 0;
      var elementSettings = this.getElementSettings();

      if (elementSettings.hierarchical_view) {
        this.createNestedList();
      } else {
        this.createFlatList();
      }

      this.$listItemTexts = this.$element.find('.oew-toc-list-item-text');
      this.$listItemTexts.on('click', this.onListItemClick.bind(this));

      if (!elementorFrontend.isEditMode()) {
        this.followTocAnchors();
      }
    }
  }, {
    key: "createNestedList",
    value: function createNestedList() {
      var _this4 = this;

      this.headingsData.forEach(function (heading, index) {
        heading.level = 0;

        for (var i = index - 1; i >= 0; i--) {
          var currentOrderedItem = _this4.headingsData[i];

          if (currentOrderedItem.tag <= heading.tag) {
            heading.level = currentOrderedItem.level;

            if (currentOrderedItem.tag < heading.tag) {
              heading.level++;
            }

            break;
          }
        }
      });
      this.elements.$tocBody.html(this.getNestedTocLevel(0));
    }
  }, {
    key: "createFlatList",
    value: function createFlatList() {
      this.elements.$tocBody.html(this.getNestedTocLevel());
    }
  }, {
    key: "getNestedTocLevel",
    value: function getNestedTocLevel(level) {
      var settings = this.getSettings(),
          elementSettings = this.getElementSettings(),
          icon = this.getElementSettings('icon'); // Open new list/nested list

      var html = "<".concat(settings.listWrapperTag, " class=\"").concat(settings.classes.listWrapper, "\">"); // for each list item, build its markup.

      while (this.listItemPointer < this.headingsData.length) {
        var currentItem = this.headingsData[this.listItemPointer];
        var listItemTextClasses = settings.classes.listItemText;

        if (0 === currentItem.level) {
          // If the current list item is a top level item, give it the first level class
          listItemTextClasses += ' ' + settings.classes.firstLevelListItem;
        }

        if (level > currentItem.level) {
          break;
        }

        if (level === currentItem.level) {
          html += "<li class=\"".concat(settings.classes.listItem, "\">");
          html += "<div class=\"".concat(settings.classes.listTextWrapper, "\">");

          if (elementSettings.duplicate_anchor_fix == 'yes') {
            var anchorText = currentItem.text.replace(/\s+/g, '-').replace(/[^\w-]+/g, '').toLowerCase() + '-' + this.listItemPointer;
          } else {
            var anchorText = currentItem.text.replace(/\s+/g, '-').replace(/[^\w-]+/g, '').toLowerCase();
          }

          var liContent = "<a href=\"#".concat(anchorText, "\" class=\"").concat(listItemTextClasses, "\">").concat(currentItem.text, "</a>"); // If list type is bullets, add the bullet icon as an <i> tag

          if ('bullets' === elementSettings.marker_view && icon) {
            liContent = "<i class=\"".concat(icon.value, "\"></i>").concat(liContent);
          }

          html += liContent;
          html += '</div>';
          this.listItemPointer++;
          var nextItem = this.headingsData[this.listItemPointer];

          if (nextItem && level < nextItem.level) {
            // If a new nested list has to be created under the current item,
            // this entire method is called recursively (outside the while loop, a list wrapper is created)
            html += this.getNestedTocLevel(nextItem.level);
          }

          html += '</li>';
        }
      }

      html += "</".concat(settings.listWrapperTag, ">");
      return html;
    }
  }, {
    key: "handleNoHeadingsFound",
    value: function handleNoHeadingsFound() {
      var noHeadingsText = elementorProFrontend.config.i18n['toc_no_headings_found'];

      if (elementorFrontend.isEditMode()) {
        noHeadingsText = elementorPro.translate('toc_no_headings_found');
      }

      return this.elements.$tocBody.html(noHeadingsText);
    }
  }, {
    key: "collapseOnInit",
    value: function collapseOnInit() {
      var minimizedOn = this.getElementSettings('minimized_on'),
          currentDeviceMode = elementorFrontend.getCurrentDeviceMode();

      if ('tablet' === minimizedOn && 'desktop' !== currentDeviceMode || 'mobile' === minimizedOn && 'mobile' === currentDeviceMode) {
        this.collapseTocBox();
      }
    }
  }, {
    key: "setHeadingsData",
    value: function setHeadingsData() {
      var _this5 = this;

      this.headingsData = []; // Create an array for simplifying TOC list creation

      this.elements.$headings.each(function (index, element) {
        _this5.headingsData.push({
          tag: +element.nodeName.slice(1),
          text: element.textContent
        });
      });
    }
  }, {
    key: "run",
    value: function run() {
      this.elements.$headings = this.getHeadings();

      if (!this.elements.$headings.length) {
        return this.handleNoHeadingsFound();
      }

      this.setHeadingsData();

      if (!elementorFrontend.isEditMode()) {
        this.addAnchorsBeforeHeadings();
      }

      this.populateTOC();

      if (this.getElementSettings('minimize_box')) {
        this.collapseOnInit();
      }
    }
  }, {
    key: "expandTocBox",
    value: function expandTocBox() {
      var boxHeight = this.getCurrentDeviceSetting('min_height');
      this.$element.removeClass(this.getSettings('classes.collapsed'));
      this.elements.$tocBody.slideDown(); // return container to the full height in case a min-height is defined by the user

      this.elements.$widgetTocContainer.css('min-height', boxHeight.size + boxHeight.unit);
    }
  }, {
    key: "collapseTocBox",
    value: function collapseTocBox() {
      this.$element.addClass(this.getSettings('classes.collapsed'));
      this.elements.$tocBody.slideUp(); // close container in case a min-height is defined by the user

      this.elements.$widgetTocContainer.css('min-height', '0px');
    }
  }, {
    key: "_superPropBase",
    value: function _superPropBase(object, property) {
      while (!Object.prototype.hasOwnProperty.call(object, property)) {
        object = getPrototypeOf(object);
        if (object === null) break;
      }

      return object;
    }
  }, {
    key: "_get3",
    value: function _get3(target, property, receiver) {
      if (typeof Reflect !== "undefined" && Reflect.get) {
        return Reflect.get(target, property, receiver || target);
        module.exports = _get = Reflect.get;
      } else {
        var base = superPropBase(target, property);
        if (!base) return;
        var desc = Object.getOwnPropertyDescriptor(base, property);

        if (desc.get) {
          return desc.get.call(receiver);
        }

        return desc.value;
      }

      return _get(target, property, receiver || target);
    }
  }]);

  return OEW_TOC;
}(elementorModules.frontend.handlers.Base);

(0, _utils.registerWidget)(OEW_TOC, "oew-toc");

},{"../lib/utils":1}]},{},[2])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJhc3NldHMvc3JjL2pzL2xpYi91dGlscy5qcyIsImFzc2V0cy9zcmMvanMvd2lkZ2V0cy90b2MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7QUNBTyxJQUFNLFNBQVMsR0FBRyxTQUFaLFNBQVksQ0FBQyxPQUFELEVBQTZCO0FBQUEsTUFBbkIsUUFBbUIsdUVBQVIsR0FBUTtBQUNsRCxNQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsZ0JBQVAsQ0FBd0IsT0FBeEIsRUFBaUMsT0FBL0M7O0FBRUEsTUFBSSxPQUFPLEtBQUssTUFBaEIsRUFBd0I7QUFDcEIsSUFBQSxPQUFPLEdBQUcsT0FBVjtBQUNIOztBQUVELEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxrQkFBZCxHQUFtQyxRQUFuQztBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxrQkFBZCxhQUFzQyxRQUF0QztBQUVBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLENBQXhCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBeEI7QUFDQSxNQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsWUFBckI7QUFFQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsTUFBZCxHQUF1QixDQUF2QjtBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLENBQXhCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFFBQWQsR0FBeUIsUUFBekI7QUFFQSxFQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE1BQWQsYUFBMEIsTUFBMUI7QUFDSCxHQUZTLEVBRVAsQ0FGTyxDQUFWO0FBSUEsRUFBQSxNQUFNLENBQUMsVUFBUCxDQUFrQixZQUFNO0FBQ3BCLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFFBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsVUFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixxQkFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixxQkFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixTQUE3QjtBQUNILEdBTkQsRUFNRyxRQUFRLEdBQUcsRUFOZDtBQU9ILENBN0JNOzs7O0FBK0JBLElBQU0sT0FBTyxHQUFHLFNBQVYsT0FBVSxDQUFDLE9BQUQsRUFBNkI7QUFBQSxNQUFuQixRQUFtQix1RUFBUixHQUFRO0FBQ2hELEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxTQUFkLEdBQTBCLFlBQTFCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtCQUFkLEdBQW1DLGdCQUFuQztBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxrQkFBZCxhQUFzQyxRQUF0QztBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxNQUFkLGFBQTBCLE9BQU8sQ0FBQyxZQUFsQztBQUNBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxTQUFkLEdBQTBCLENBQTFCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFlBQWQsR0FBNkIsQ0FBN0I7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsUUFBZCxHQUF5QixRQUF6QjtBQUVBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsTUFBZCxHQUF1QixDQUF2QjtBQUNILEdBRlMsRUFFUCxDQUZPLENBQVY7QUFJQSxFQUFBLE1BQU0sQ0FBQyxVQUFQLENBQWtCLFlBQU07QUFDcEIsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsTUFBeEI7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixRQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFlBQTdCO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGNBQWQsQ0FBNkIsZUFBN0I7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxDQUE2QixVQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLHFCQUE3QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLHFCQUE3QjtBQUNILEdBUkQsRUFRRyxRQUFRLEdBQUcsRUFSZDtBQVNILENBdEJNOzs7O0FBd0JBLElBQU0sV0FBVyxHQUFHLFNBQWQsV0FBYyxDQUFDLE9BQUQsRUFBVSxRQUFWLEVBQXVCO0FBQzlDLEVBQUEsTUFBTSxDQUFDLGdCQUFQLENBQXdCLE9BQXhCLEVBQWlDLE9BQWpDLEtBQTZDLE1BQTdDLEdBQXNELFNBQVMsQ0FBQyxPQUFELEVBQVUsUUFBVixDQUEvRCxHQUFxRixPQUFPLENBQUMsT0FBRCxFQUFVLFFBQVYsQ0FBNUY7QUFDSCxDQUZNOzs7O0FBSUEsSUFBTSxNQUFNLEdBQUcsU0FBVCxNQUFTLENBQUMsT0FBRCxFQUE0QjtBQUFBLE1BQWxCLFFBQWtCLHVFQUFQLEVBQU87O0FBQzlDLE1BQU0sT0FBTyxHQUFHO0FBQ1osSUFBQSxRQUFRLEVBQUUsR0FERTtBQUVaLElBQUEsT0FBTyxFQUFFLElBRkc7QUFHWixJQUFBLE9BQU8sRUFBRSxDQUhHO0FBSVosSUFBQSxRQUFRLEVBQUU7QUFKRSxHQUFoQjtBQU9BLEVBQUEsTUFBTSxDQUFDLE1BQVAsQ0FBYyxPQUFkLEVBQXVCLFFBQXZCO0FBRUEsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsQ0FBeEI7QUFDQSxFQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixPQUFPLENBQUMsT0FBUixJQUFtQixPQUEzQztBQUVBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsVUFBZCxhQUE4QixPQUFPLENBQUMsUUFBdEM7QUFDQSxJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixPQUFPLENBQUMsT0FBaEM7QUFDSCxHQUhTLEVBR1AsQ0FITyxDQUFWO0FBS0EsRUFBQSxVQUFVLENBQUMsWUFBTTtBQUNiLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFlBQTdCO0FBQ0EsS0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFWLElBQXNCLE9BQU8sQ0FBQyxRQUFSLEVBQXRCO0FBQ0gsR0FIUyxFQUdQLE9BQU8sQ0FBQyxRQUFSLEdBQW1CLEVBSFosQ0FBVjtBQUlILENBdEJNOzs7O0FBd0JBLElBQU0sT0FBTyxHQUFHLFNBQVYsT0FBVSxDQUFDLE9BQUQsRUFBNEI7QUFBQSxNQUFsQixRQUFrQix1RUFBUCxFQUFPOztBQUMvQyxNQUFNLE9BQU8sR0FBRztBQUNaLElBQUEsUUFBUSxFQUFFLEdBREU7QUFFWixJQUFBLE9BQU8sRUFBRSxJQUZHO0FBR1osSUFBQSxPQUFPLEVBQUUsQ0FIRztBQUlaLElBQUEsUUFBUSxFQUFFO0FBSkUsR0FBaEI7QUFPQSxFQUFBLE1BQU0sQ0FBQyxNQUFQLENBQWMsT0FBZCxFQUF1QixRQUF2QjtBQUVBLEVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFkLEdBQXdCLENBQXhCO0FBQ0EsRUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBTyxDQUFDLE9BQVIsSUFBbUIsT0FBM0M7QUFFQSxFQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFVBQWQsYUFBOEIsT0FBTyxDQUFDLFFBQXRDO0FBQ0EsSUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLE9BQWQsR0FBd0IsT0FBTyxDQUFDLE9BQWhDO0FBQ0gsR0FIUyxFQUdQLENBSE8sQ0FBVjtBQUtBLEVBQUEsVUFBVSxDQUFDLFlBQU07QUFDYixJQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsT0FBZCxHQUF3QixNQUF4QjtBQUNBLElBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxjQUFkLENBQTZCLFlBQTdCO0FBQ0EsS0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFWLElBQXNCLE9BQU8sQ0FBQyxRQUFSLEVBQXRCO0FBQ0gsR0FKUyxFQUlQLE9BQU8sQ0FBQyxRQUFSLEdBQW1CLEVBSlosQ0FBVjtBQUtILENBdkJNOzs7O0FBeUJBLElBQU0sVUFBVSxHQUFHLFNBQWIsVUFBYSxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQXNCO0FBQzVDLEVBQUEsTUFBTSxDQUFDLGdCQUFQLENBQXdCLE9BQXhCLEVBQWlDLE9BQWpDLEtBQTZDLE1BQTdDLEdBQXNELE1BQU0sQ0FBQyxPQUFELEVBQVUsT0FBVixDQUE1RCxHQUFpRixPQUFPLENBQUMsT0FBRCxFQUFVLE9BQVYsQ0FBeEY7QUFDSCxDQUZNOzs7O0FBSUEsSUFBTSxNQUFNLEdBQUcsU0FBVCxNQUFTLENBQUMsT0FBRCxFQUFhO0FBQy9CLE1BQUksQ0FBQyxPQUFPLENBQUMsY0FBUixHQUF5QixNQUE5QixFQUFzQztBQUNsQyxXQUFPO0FBQUUsTUFBQSxHQUFHLEVBQUUsQ0FBUDtBQUFVLE1BQUEsSUFBSSxFQUFFO0FBQWhCLEtBQVA7QUFDSCxHQUg4QixDQUsvQjs7O0FBQ0EsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLHFCQUFSLEVBQWI7QUFDQSxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsYUFBUixDQUFzQixXQUFsQztBQUNBLFNBQU87QUFDSCxJQUFBLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBTCxHQUFXLEdBQUcsQ0FBQyxXQURqQjtBQUVILElBQUEsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFMLEdBQVksR0FBRyxDQUFDO0FBRm5CLEdBQVA7QUFJSCxDQVpNOzs7O0FBY0EsSUFBTSxPQUFPLEdBQUcsU0FBVixPQUFVLENBQUMsT0FBRCxFQUFhO0FBQ2hDLE1BQUksQ0FBQyxPQUFMLEVBQWM7QUFDVixXQUFPLEtBQVA7QUFDSDs7QUFFRCxTQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsV0FBUixJQUF1QixPQUFPLENBQUMsWUFBL0IsSUFBK0MsT0FBTyxDQUFDLGNBQVIsR0FBeUIsTUFBMUUsQ0FBUjtBQUNILENBTk07Ozs7QUFRQSxJQUFNLFdBQVcsR0FBRyxTQUFkLFdBQWMsQ0FBQyxDQUFELEVBQU87QUFDOUI7QUFDQSxNQUFNLFFBQVEsR0FBRyxFQUFqQixDQUY4QixDQUk5Qjs7QUFDQSxNQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVAsRUFBbUI7QUFDZixXQUFPLFFBQVA7QUFDSCxHQVA2QixDQVM5Qjs7O0FBQ0EsTUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLFVBQUYsQ0FBYSxVQUEzQixDQVY4QixDQVk5Qjs7QUFDQSxTQUFPLE9BQVAsRUFBZ0I7QUFDWixRQUFJLE9BQU8sQ0FBQyxRQUFSLEtBQXFCLENBQXJCLElBQTBCLE9BQU8sS0FBSyxDQUExQyxFQUE2QztBQUN6QyxNQUFBLFFBQVEsQ0FBQyxJQUFULENBQWMsT0FBZDtBQUNIOztBQUVELElBQUEsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFsQjtBQUNIOztBQUVELFNBQU8sUUFBUDtBQUNILENBdEJNLEMsQ0F3QlA7Ozs7O0FBQ08sSUFBTSxTQUFTLEdBQUcsU0FBWixTQUFZLENBQUMsQ0FBRCxFQUFPO0FBQzVCLFNBQU8sUUFBTyxXQUFQLHlDQUFPLFdBQVAsT0FBdUIsUUFBdkIsR0FDRCxDQUFDLFlBQVksV0FEWixDQUN3QjtBQUR4QixJQUVELENBQUMsSUFBSSxRQUFPLENBQVAsTUFBYSxRQUFsQixJQUE4QixDQUFDLEtBQUssSUFBcEMsSUFBNEMsQ0FBQyxDQUFDLFFBQUYsS0FBZSxDQUEzRCxJQUFnRSxPQUFPLENBQUMsQ0FBQyxRQUFULEtBQXNCLFFBRjVGO0FBR0gsQ0FKTTs7OztBQU1BLElBQU0sY0FBYyxHQUFHLFNBQWpCLGNBQWlCLENBQUMsU0FBRCxFQUFZLFVBQVosRUFBNkM7QUFBQSxNQUFyQixJQUFxQix1RUFBZCxTQUFjOztBQUN2RSxNQUFJLEVBQUUsU0FBUyxJQUFJLFVBQWYsQ0FBSixFQUFnQztBQUM1QjtBQUNIO0FBRUQ7QUFDSjtBQUNBO0FBQ0E7OztBQUNJLEVBQUEsTUFBTSxDQUFDLE1BQUQsQ0FBTixDQUFlLEVBQWYsQ0FBa0IseUJBQWxCLEVBQTZDLFlBQU07QUFDL0MsUUFBTSxVQUFVLEdBQUcsU0FBYixVQUFhLENBQUMsUUFBRCxFQUFjO0FBQzdCLE1BQUEsaUJBQWlCLENBQUMsZUFBbEIsQ0FBa0MsVUFBbEMsQ0FBNkMsU0FBN0MsRUFBd0Q7QUFDcEQsUUFBQSxRQUFRLEVBQVI7QUFEb0QsT0FBeEQ7QUFHSCxLQUpEOztBQU1BLElBQUEsaUJBQWlCLENBQUMsS0FBbEIsQ0FBd0IsU0FBeEIsa0NBQTRELFVBQTVELGNBQTBFLElBQTFFLEdBQWtGLFVBQWxGO0FBQ0gsR0FSRDtBQVNILENBbEJNOzs7Ozs7Ozs7QUNyS1A7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFJTSxPOzs7Ozs7Ozs7Ozs7O1dBRUYsOEJBQXFCO0FBQ2pCLFVBQUksZUFBZSxHQUFHLEtBQUssa0JBQUwsRUFBdEI7QUFBQSxVQUNJLGNBQWMsR0FBRyxjQUFjLGVBQWUsQ0FBQyxXQUE5QixHQUE0QyxJQUE1QyxHQUFtRCxJQUR4RTtBQUVBLGFBQU87QUFDSCxRQUFBLFNBQVMsRUFBRTtBQUNQLFVBQUEsa0JBQWtCLEVBQUUsMkJBRGI7QUFFUCxVQUFBLG9CQUFvQixFQUFFLHVIQUZmO0FBR1AsVUFBQSxZQUFZLEVBQUUsK0JBSFA7QUFJUCxVQUFBLGNBQWMsRUFBRSxpQ0FKVDtBQUtQLFVBQUEsSUFBSSxFQUFFLGVBTEM7QUFNUCxVQUFBLFdBQVcsRUFBRTtBQU5OLFNBRFI7QUFTSCxRQUFBLE9BQU8sRUFBRTtBQUNMLFVBQUEsTUFBTSxFQUFFLHVCQURIO0FBRUwsVUFBQSxXQUFXLEVBQUUsc0JBRlI7QUFHTCxVQUFBLFFBQVEsRUFBRSxtQkFITDtBQUlMLFVBQUEsZUFBZSxFQUFFLGdDQUpaO0FBS0wsVUFBQSxrQkFBa0IsRUFBRSxtQkFMZjtBQU1MLFVBQUEsWUFBWSxFQUFFLHdCQU5UO0FBT0wsVUFBQSxVQUFVLEVBQUUsdUJBUFA7QUFRTCxVQUFBLGFBQWEsRUFBRSx3QkFSVjtBQVNMLFVBQUEsU0FBUyxFQUFFO0FBVE4sU0FUTjtBQW9CSCxRQUFBLGNBQWMsRUFBRTtBQXBCYixPQUFQO0FBc0JIOzs7V0FFRCw4QkFBcUI7QUFDakIsVUFBSSxRQUFRLEdBQUcsS0FBSyxXQUFMLEVBQWY7QUFDQSxhQUFPO0FBQ0gsUUFBQSxjQUFjLEVBQUUsS0FBSyxlQUFMLEVBRGI7QUFFSCxRQUFBLG1CQUFtQixFQUFFLEtBQUssUUFBTCxDQUFjLElBQWQsQ0FBbUIsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsa0JBQXRDLENBRmxCO0FBR0gsUUFBQSxhQUFhLEVBQUUsS0FBSyxRQUFMLENBQWMsSUFBZCxDQUFtQixRQUFRLENBQUMsU0FBVCxDQUFtQixZQUF0QyxDQUhaO0FBSUgsUUFBQSxlQUFlLEVBQUUsS0FBSyxRQUFMLENBQWMsSUFBZCxDQUFtQixRQUFRLENBQUMsU0FBVCxDQUFtQixjQUF0QyxDQUpkO0FBS0gsUUFBQSxRQUFRLEVBQUUsS0FBSyxRQUFMLENBQWMsSUFBZCxDQUFtQixRQUFRLENBQUMsU0FBVCxDQUFtQixJQUF0QyxDQUxQO0FBTUgsUUFBQSxVQUFVLEVBQUUsS0FBSyxRQUFMLENBQWMsSUFBZCxDQUFtQixNQUFNLFFBQVEsQ0FBQyxPQUFULENBQWlCLFFBQTFDO0FBTlQsT0FBUDtBQVFIOzs7V0FFRCwyQkFBa0I7QUFDZCxVQUFJLFFBQVEsR0FBRyxLQUFLLFdBQUwsRUFBZjtBQUFBLFVBQ0ksZUFBZSxHQUFHLEtBQUssa0JBQUwsRUFEdEI7O0FBR0EsVUFBSSxlQUFlLENBQUMsU0FBcEIsRUFBK0I7QUFDM0IsZUFBTyxNQUFNLENBQUMsZUFBZSxDQUFDLFNBQWpCLENBQWI7QUFDSDs7QUFHRCxVQUFJLGdCQUFnQixHQUFHLEtBQUssUUFBTCxDQUFjLE9BQWQsQ0FBc0IsWUFBdEIsQ0FBdkI7O0FBRUEsVUFBSSxZQUFZLGdCQUFnQixDQUFDLElBQWpCLENBQXNCLHFCQUF0QixDQUFoQixFQUE4RDtBQUMxRCxlQUFPLGdCQUFQO0FBQ0g7O0FBR0QsYUFBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsb0JBQXBCLENBQWI7QUFDSDs7O1dBQ0Qsc0JBQWE7QUFDVCxVQUFJLEtBQUssR0FBRyxJQUFaOztBQUVBLFVBQUksZUFBZSxHQUFHLEtBQUssa0JBQUwsRUFBdEI7O0FBRUEsVUFBSSxlQUFlLENBQUMsWUFBcEIsRUFBa0M7QUFDOUIsYUFBSyxRQUFMLENBQWMsYUFBZCxDQUE0QixFQUE1QixDQUErQixPQUEvQixFQUF3QyxZQUFXO0FBQy9DLGlCQUFPLEtBQUssQ0FBQyxZQUFOLEVBQVA7QUFDSCxTQUZEO0FBR0EsYUFBSyxRQUFMLENBQWMsZUFBZCxDQUE4QixFQUE5QixDQUFpQyxPQUFqQyxFQUEwQyxZQUFXO0FBQ2pELGlCQUFPLEtBQUssQ0FBQyxjQUFOLEVBQVA7QUFDSCxTQUZEO0FBR0g7O0FBRUQsVUFBSSxlQUFlLENBQUMsaUJBQXBCLEVBQXVDO0FBQ25DLGFBQUssUUFBTCxDQUFjLFVBQWQsQ0FBeUIsS0FBekIsQ0FBK0IsVUFBUyxLQUFULEVBQWdCO0FBQzNDLGlCQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBUCxDQUFOLENBQXFCLFdBQXJCLEVBQVA7QUFDSCxTQUZEO0FBR0g7QUFDSjs7O1dBQ0QsdUJBQWM7QUFDVjtBQUNBLFVBQUksZUFBZSxHQUFHLEtBQUssa0JBQUwsRUFBdEI7QUFBQSxVQUNJLElBQUksR0FBRyxlQUFlLENBQUMsZ0JBQWhCLENBQWlDLElBQWpDLENBQXNDLEdBQXRDLENBRFg7QUFBQSxVQUVJLFNBQVMsR0FBRyxLQUFLLFdBQUwsQ0FBaUIsV0FBakIsQ0FGaEI7QUFBQSxVQUdJLGlCQUFpQixHQUFHLGVBQWUsQ0FBQyw0QkFIeEM7QUFJQSxhQUFPLEtBQUssUUFBTCxDQUFjLGNBQWQsQ0FBNkIsSUFBN0IsQ0FBa0MsSUFBbEMsRUFBd0MsR0FBeEMsQ0FBNEMsU0FBUyxDQUFDLFdBQXRELEVBQW1FLE1BQW5FLENBQTBFLFVBQVMsS0FBVCxFQUFnQixPQUFoQixFQUF5QjtBQUN0RyxlQUFPLENBQUMsTUFBTSxDQUFDLE9BQUQsQ0FBTixDQUFnQixPQUFoQixDQUF3QixpQkFBeEIsRUFBMkMsTUFBbkQsQ0FEc0csQ0FDM0M7QUFDOUQsT0FGTSxDQUFQO0FBR0g7OztXQUNELG9DQUEyQjtBQUN2QjtBQUNBLFVBQUksT0FBTyxHQUFHLEtBQUssV0FBTCxDQUFpQixTQUFqQixDQUFkO0FBQ0EsVUFBSSxlQUFlLEdBQUcsS0FBSyxrQkFBTCxFQUF0QjtBQUNBLFdBQUssUUFBTCxDQUFjLFNBQWQsQ0FBd0IsSUFBeEIsQ0FBNkIsVUFBUyxLQUFULEVBQWdCO0FBQzNDLFlBQUksZUFBZSxDQUFDLG9CQUFoQixJQUF3QyxLQUE1QyxFQUFtRDtBQUMvQyxjQUFJLFVBQVUsR0FBRyxLQUFLLFdBQUwsQ0FBaUIsT0FBakIsQ0FBeUIsTUFBekIsRUFBaUMsR0FBakMsRUFBc0MsT0FBdEMsQ0FBOEMsVUFBOUMsRUFBMEQsRUFBMUQsRUFBOEQsV0FBOUQsS0FBOEUsR0FBOUUsR0FBb0YsS0FBckc7QUFDSCxTQUZELE1BRU87QUFDSCxjQUFJLFVBQVUsR0FBRyxLQUFLLFdBQUwsQ0FBaUIsT0FBakIsQ0FBeUIsTUFBekIsRUFBaUMsR0FBakMsRUFBc0MsT0FBdEMsQ0FBOEMsVUFBOUMsRUFBMEQsRUFBMUQsRUFBOEQsV0FBOUQsRUFBakI7QUFDSDs7QUFDRCxhQUFLLFlBQUwsQ0FBa0IsSUFBbEIsRUFBd0IsVUFBeEI7QUFDSCxPQVBDO0FBU0g7OztXQUNELHlCQUFnQixDQUFoQixFQUFtQjtBQUNmLGFBQU8sQ0FBQyxDQUFDLFNBQUYsSUFBZSxNQUFNLENBQUMsY0FBUCxDQUFzQixDQUF0QixDQUF0QjtBQUNIOzs7V0FDRCxrQkFBUztBQUNMLFVBQUksS0FBSjtBQUFBLFVBQ0ksTUFBTSxHQUFHLElBRGI7O0FBR0EsV0FBSyxJQUFJLElBQUksR0FBRyxTQUFTLENBQUMsTUFBckIsRUFBNkIsSUFBSSxHQUFHLElBQUksS0FBSixDQUFVLElBQVYsQ0FBcEMsRUFBcUQsSUFBSSxHQUFHLENBQWpFLEVBQW9FLElBQUksR0FBRyxJQUEzRSxFQUFpRixJQUFJLEVBQXJGLEVBQXlGO0FBQ3JGLFFBQUEsSUFBSSxDQUFDLElBQUQsQ0FBSixHQUFhLFNBQVMsQ0FBQyxJQUFELENBQXRCO0FBQ0g7O0FBRUQsT0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEtBQUssS0FBVCxFQUFnQixDQUFDLEdBQUcsS0FBSyxlQUFULEVBQTBCLE9BQU8sQ0FBQyxTQUFsQyxDQUFoQixFQUE4RCxRQUE5RCxFQUF3RSxJQUF4RSxDQUFULEVBQXdGLElBQXhGLENBQTZGLEtBQTdGLENBQW1HLEtBQW5HLEVBQTBHLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBYyxJQUFkLENBQTFHOztBQUVBLFdBQUssYUFBTCxHQUFxQixFQUFyQjtBQUNBLE1BQUEsTUFBTSxDQUFDLFFBQUQsQ0FBTixDQUFpQixLQUFqQixDQUF1QixZQUFXO0FBQzlCLGVBQU8sTUFBTSxDQUFDLEdBQVAsRUFBUDtBQUNILE9BRkQ7QUFHSDs7O1dBRUQseUJBQWdCLEtBQWhCLEVBQXVCO0FBQ3JCLFVBQUksTUFBTSxHQUFHLElBQWI7O0FBRUEsV0FBSyxXQUFMLEdBQW1CLElBQW5CO0FBQ0EsTUFBQSxVQUFVLENBQUMsWUFBVztBQUNsQixlQUFPLE1BQU0sQ0FBQyxXQUFQLEdBQXFCLEtBQTVCO0FBQ0gsT0FGUyxFQUVQLElBRk8sQ0FBVjtBQUlBLFVBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBUCxDQUF6QjtBQUFBLFVBQ0ksS0FBSyxHQUFHLFlBQVksQ0FBQyxNQUFiLEdBQXNCLElBQXRCLEVBRFo7QUFBQSxVQUVJLGtCQUFrQixHQUFHLEtBQUssa0JBQUwsQ0FBd0IsbUJBQXhCLENBRnpCO0FBR0EsVUFBSSxZQUFKOztBQUVBLFVBQUksa0JBQWtCLElBQUksWUFBWSxDQUFDLFFBQWIsQ0FBc0IsS0FBSyxXQUFMLENBQWlCLDRCQUFqQixDQUF0QixDQUExQixFQUFpRztBQUM3RixZQUFJLEtBQUssQ0FBQyxFQUFOLENBQVMsVUFBVCxDQUFKLEVBQTBCO0FBQ3RCLFVBQUEsWUFBWSxHQUFHLElBQWY7QUFDSDtBQUNKOztBQUVELFdBQUssZUFBTCxDQUFxQixZQUFyQjs7QUFFQSxVQUFJLGtCQUFrQixJQUFJLFlBQTFCLEVBQXdDO0FBQ3BDLFFBQUEsS0FBSyxDQUFDLE9BQU47QUFDSDtBQUVKOzs7V0FHQyx5QkFBZ0IsU0FBaEIsRUFBMkI7QUFFdkIsVUFBSSxPQUFPLEdBQUcsS0FBSyxXQUFMLENBQWlCLFNBQWpCLENBQWQ7QUFDQSxXQUFLLHVCQUFMLENBQTZCLFNBQTdCO0FBQ0EsTUFBQSxTQUFTLENBQUMsUUFBVixDQUFtQixPQUFPLENBQUMsVUFBM0I7QUFDQSxXQUFLLFdBQUwsR0FBbUIsU0FBbkI7O0FBRUEsVUFBSSxDQUFDLEtBQUssa0JBQUwsQ0FBd0IsbUJBQXhCLENBQUwsRUFBbUQ7QUFDL0M7QUFDSDs7QUFFRCxVQUFJLFdBQUo7O0FBRUEsVUFBSSxTQUFTLENBQUMsUUFBVixDQUFtQixPQUFPLENBQUMsa0JBQTNCLENBQUosRUFBb0Q7QUFDaEQsUUFBQSxXQUFXLEdBQUcsU0FBUyxDQUFDLE1BQVYsR0FBbUIsSUFBbkIsRUFBZDtBQUNILE9BRkQsTUFFTztBQUNILFFBQUEsV0FBVyxHQUFHLFNBQVMsQ0FBQyxPQUFWLENBQWtCLE1BQU0sT0FBTyxDQUFDLFdBQWhDLEVBQTZDLEVBQTdDLENBQWdELENBQUMsQ0FBakQsQ0FBZDtBQUNIOztBQUVELFVBQUksQ0FBQyxXQUFXLENBQUMsTUFBakIsRUFBeUI7QUFDckIsZUFBTyxLQUFLLFdBQVo7QUFDQTtBQUNIOztBQUVELFdBQUssV0FBTCxHQUFtQixXQUFuQjtBQUNBLFdBQUssV0FBTCxDQUFpQixJQUFqQixHQUF3QixTQUF4QjtBQUNIOzs7V0FFRCxpQ0FBd0IsV0FBeEIsRUFBcUM7QUFDakMsVUFBSSxDQUFDLEtBQUssV0FBTixJQUFxQixLQUFLLFdBQUwsQ0FBaUIsRUFBakIsQ0FBb0IsV0FBcEIsQ0FBekIsRUFBMkQ7QUFDdkQ7QUFDSDs7QUFFRCxVQUFJLGlCQUFpQixHQUFHLEtBQUssV0FBTCxFQUF4QjtBQUFBLFVBQ0ksT0FBTyxHQUFHLGlCQUFpQixDQUFDLE9BRGhDOztBQUdBLFdBQUssV0FBTCxDQUFpQixXQUFqQixDQUE2QixPQUFPLENBQUMsVUFBckM7O0FBRUEsVUFBSSxLQUFLLFdBQUwsS0FBcUIsQ0FBQyxXQUFELElBQWdCLENBQUMsS0FBSyxXQUFMLENBQWlCLENBQWpCLEVBQW9CLFFBQXBCLENBQTZCLFdBQVcsQ0FBQyxDQUFELENBQXhDLENBQXRDLENBQUosRUFBeUY7QUFDckYsYUFBSyxXQUFMLENBQWlCLE9BQWpCO0FBQ0g7QUFDSjs7O1dBRUQseUJBQWdCLFFBQWhCLEVBQTBCLEtBQTFCLEVBQWlDO0FBQy9CLFVBQUksTUFBTSxHQUFHLElBQWI7O0FBRUEsVUFBSSxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUQsQ0FBUixDQUFZLElBQWpDO0FBQ0EsVUFBSSxPQUFKOztBQUVBLFVBQUk7QUFDQTtBQUNBLFFBQUEsT0FBTyxHQUFHLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxjQUFELENBQW5CLENBQWhCO0FBQ0gsT0FIRCxDQUdFLE9BQU8sQ0FBUCxFQUFVO0FBQ1I7QUFDSCxPQVg4QixDQWEvQjs7O0FBQ0EsVUFBTSxlQUFlLEdBQUc7QUFDcEIsUUFBQSxJQUFJLEVBQUUsSUFEYztBQUNSO0FBQ1osUUFBQSxVQUFVLEVBQUUsS0FGUTtBQUdwQixRQUFBLFNBQVMsRUFBRSxHQUhTLENBR0w7O0FBSEssT0FBeEI7O0FBTUEsVUFBTSxRQUFRLEdBQUcsU0FBWCxRQUFXLENBQUMsT0FBRCxFQUFhO0FBQzFCLFFBQUEsT0FBTyxDQUFDLE9BQVIsQ0FBZ0IsVUFBQSxLQUFLLEVBQUk7QUFDckIsY0FBSSxNQUFNLENBQUMsV0FBWCxFQUF3QjtBQUNwQjtBQUNIOztBQUVELGNBQU0sRUFBRSxHQUFHLEtBQUssQ0FBQyxNQUFOLENBQWEsWUFBYixDQUEwQixJQUExQixDQUFYOztBQUVBLGNBQUksS0FBSyxDQUFDLGNBQVYsRUFBMEI7QUFDdEIsZ0JBQUksS0FBSyxDQUFDLGtCQUFOLENBQXlCLEdBQXpCLEdBQStCLENBQW5DLEVBQXNDO0FBQUU7QUFDcEMsY0FBQSxNQUFNLENBQUMsYUFBUCxDQUFxQixFQUFyQixJQUEyQixJQUEzQjs7QUFDQSxjQUFBLE1BQU0sQ0FBQyxlQUFQLENBQXVCLFFBQXZCO0FBQ0g7QUFDSixXQUxELE1BS087QUFDSCxnQkFBSSxLQUFLLENBQUMsa0JBQU4sQ0FBeUIsR0FBekIsR0FBK0IsQ0FBbkMsRUFBc0M7QUFBRTtBQUNwQyxxQkFBTyxNQUFNLENBQUMsYUFBUCxDQUFxQixFQUFyQixDQUFQOztBQUNBLGNBQUEsTUFBTSxDQUFDLGVBQVAsQ0FBdUIsTUFBTSxDQUFDLGNBQVAsQ0FBc0IsRUFBdEIsQ0FBeUIsS0FBSyxHQUFHLENBQWpDLENBQXZCO0FBQ0g7QUFDSjtBQUNKLFNBbEJEO0FBbUJILE9BcEJEOztBQXNCQSxVQUFNLFFBQVEsR0FBRyxJQUFJLG9CQUFKLENBQXlCLFFBQXpCLEVBQW1DLGVBQW5DLENBQWpCO0FBQ0EsVUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGNBQVQsQ0FBd0IsY0FBYyxDQUFDLE9BQWYsQ0FBdUIsR0FBdkIsRUFBNEIsRUFBNUIsQ0FBeEIsQ0FBZjs7QUFDQSxVQUFJLE1BQUosRUFBWTtBQUNSLFFBQUEsUUFBUSxDQUFDLE9BQVQsQ0FBaUIsTUFBakI7QUFDSDtBQUVKOzs7V0FHQyw0QkFBbUI7QUFDZixVQUFJLE1BQU0sR0FBRyxJQUFiOztBQUVBLFdBQUssY0FBTCxDQUFvQixJQUFwQixDQUF5QixVQUFTLEtBQVQsRUFBZ0IsT0FBaEIsRUFBeUI7QUFDOUMsZUFBTyxNQUFNLENBQUMsZUFBUCxDQUF1QixNQUFNLENBQUMsT0FBRCxDQUE3QixFQUF3QyxLQUF4QyxDQUFQO0FBQ0gsT0FGRDtBQUdIOzs7V0FFRCx1QkFBYztBQUNWLFdBQUssZUFBTCxHQUF1QixDQUF2QjtBQUNBLFVBQUksZUFBZSxHQUFHLEtBQUssa0JBQUwsRUFBdEI7O0FBRUEsVUFBSSxlQUFlLENBQUMsaUJBQXBCLEVBQXVDO0FBQ25DLGFBQUssZ0JBQUw7QUFDSCxPQUZELE1BRU87QUFDSCxhQUFLLGNBQUw7QUFDSDs7QUFFRCxXQUFLLGNBQUwsR0FBc0IsS0FBSyxRQUFMLENBQWMsSUFBZCxDQUFtQix5QkFBbkIsQ0FBdEI7QUFDQSxXQUFLLGNBQUwsQ0FBb0IsRUFBcEIsQ0FBdUIsT0FBdkIsRUFBZ0MsS0FBSyxlQUFMLENBQXFCLElBQXJCLENBQTBCLElBQTFCLENBQWhDOztBQUVBLFVBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFsQixFQUFMLEVBQXFDO0FBQ2pDLGFBQUssZ0JBQUw7QUFDSDtBQUNKOzs7V0FFRCw0QkFBbUI7QUFDZixVQUFJLE1BQU0sR0FBRyxJQUFiOztBQUVBLFdBQUssWUFBTCxDQUFrQixPQUFsQixDQUEwQixVQUFTLE9BQVQsRUFBa0IsS0FBbEIsRUFBeUI7QUFDL0MsUUFBQSxPQUFPLENBQUMsS0FBUixHQUFnQixDQUFoQjs7QUFFQSxhQUFLLElBQUksQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFyQixFQUF3QixDQUFDLElBQUksQ0FBN0IsRUFBZ0MsQ0FBQyxFQUFqQyxFQUFxQztBQUNqQyxjQUFJLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxZQUFQLENBQW9CLENBQXBCLENBQXpCOztBQUVBLGNBQUksa0JBQWtCLENBQUMsR0FBbkIsSUFBMEIsT0FBTyxDQUFDLEdBQXRDLEVBQTJDO0FBQ3ZDLFlBQUEsT0FBTyxDQUFDLEtBQVIsR0FBZ0Isa0JBQWtCLENBQUMsS0FBbkM7O0FBRUEsZ0JBQUksa0JBQWtCLENBQUMsR0FBbkIsR0FBeUIsT0FBTyxDQUFDLEdBQXJDLEVBQTBDO0FBQ3RDLGNBQUEsT0FBTyxDQUFDLEtBQVI7QUFDSDs7QUFFRDtBQUNIO0FBQ0o7QUFDSixPQWhCRDtBQWlCQSxXQUFLLFFBQUwsQ0FBYyxRQUFkLENBQXVCLElBQXZCLENBQTRCLEtBQUssaUJBQUwsQ0FBdUIsQ0FBdkIsQ0FBNUI7QUFDSDs7O1dBRUQsMEJBQWlCO0FBQ2IsV0FBSyxRQUFMLENBQWMsUUFBZCxDQUF1QixJQUF2QixDQUE0QixLQUFLLGlCQUFMLEVBQTVCO0FBQ0g7OztXQUVELDJCQUFrQixLQUFsQixFQUF5QjtBQUNyQixVQUFJLFFBQVEsR0FBRyxLQUFLLFdBQUwsRUFBZjtBQUFBLFVBQ0ksZUFBZSxHQUFHLEtBQUssa0JBQUwsRUFEdEI7QUFBQSxVQUVJLElBQUksR0FBRyxLQUFLLGtCQUFMLENBQXdCLE1BQXhCLENBRlgsQ0FEcUIsQ0FHdUI7O0FBRTVDLFVBQUksSUFBSSxHQUFHLElBQUksTUFBSixDQUFXLFFBQVEsQ0FBQyxjQUFwQixFQUFvQyxXQUFwQyxFQUFpRCxNQUFqRCxDQUF3RCxRQUFRLENBQUMsT0FBVCxDQUFpQixXQUF6RSxFQUFzRixLQUF0RixDQUFYLENBTHFCLENBS29GOztBQUV6RyxhQUFPLEtBQUssZUFBTCxHQUF1QixLQUFLLFlBQUwsQ0FBa0IsTUFBaEQsRUFBd0Q7QUFDcEQsWUFBSSxXQUFXLEdBQUcsS0FBSyxZQUFMLENBQWtCLEtBQUssZUFBdkIsQ0FBbEI7QUFDQSxZQUFJLG1CQUFtQixHQUFHLFFBQVEsQ0FBQyxPQUFULENBQWlCLFlBQTNDOztBQUVBLFlBQUksTUFBTSxXQUFXLENBQUMsS0FBdEIsRUFBNkI7QUFDekI7QUFDQSxVQUFBLG1CQUFtQixJQUFJLE1BQU0sUUFBUSxDQUFDLE9BQVQsQ0FBaUIsa0JBQTlDO0FBQ0g7O0FBRUQsWUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQXhCLEVBQStCO0FBQzNCO0FBQ0g7O0FBRUQsWUFBSSxLQUFLLEtBQUssV0FBVyxDQUFDLEtBQTFCLEVBQWlDO0FBQzdCLFVBQUEsSUFBSSxJQUFJLGVBQWUsTUFBZixDQUFzQixRQUFRLENBQUMsT0FBVCxDQUFpQixRQUF2QyxFQUFpRCxLQUFqRCxDQUFSO0FBQ0EsVUFBQSxJQUFJLElBQUksZ0JBQWdCLE1BQWhCLENBQXVCLFFBQVEsQ0FBQyxPQUFULENBQWlCLGVBQXhDLEVBQXlELEtBQXpELENBQVI7O0FBQ0EsY0FBSSxlQUFlLENBQUMsb0JBQWhCLElBQXdDLEtBQTVDLEVBQW1EO0FBQy9DLGdCQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsSUFBWixDQUFpQixPQUFqQixDQUF5QixNQUF6QixFQUFpQyxHQUFqQyxFQUFzQyxPQUF0QyxDQUE4QyxVQUE5QyxFQUEwRCxFQUExRCxFQUE4RCxXQUE5RCxLQUE4RSxHQUE5RSxHQUFvRixLQUFLLGVBQTFHO0FBQ0gsV0FGRCxNQUVPO0FBQ0gsZ0JBQUksVUFBVSxHQUFHLFdBQVcsQ0FBQyxJQUFaLENBQWlCLE9BQWpCLENBQXlCLE1BQXpCLEVBQWlDLEdBQWpDLEVBQXNDLE9BQXRDLENBQThDLFVBQTlDLEVBQTBELEVBQTFELEVBQThELFdBQTlELEVBQWpCO0FBQ0g7O0FBRUQsY0FBSSxTQUFTLEdBQUcsY0FBYyxNQUFkLENBQXFCLFVBQXJCLEVBQWlDLGFBQWpDLEVBQWdELE1BQWhELENBQXVELG1CQUF2RCxFQUE0RSxLQUE1RSxFQUFtRixNQUFuRixDQUEwRixXQUFXLENBQUMsSUFBdEcsRUFBNEcsTUFBNUcsQ0FBaEIsQ0FUNkIsQ0FTd0c7O0FBRXJJLGNBQUksY0FBYyxlQUFlLENBQUMsV0FBOUIsSUFBNkMsSUFBakQsRUFBdUQ7QUFDbkQsWUFBQSxTQUFTLEdBQUcsY0FBYyxNQUFkLENBQXFCLElBQUksQ0FBQyxLQUExQixFQUFpQyxTQUFqQyxFQUE0QyxNQUE1QyxDQUFtRCxTQUFuRCxDQUFaO0FBQ0g7O0FBRUQsVUFBQSxJQUFJLElBQUksU0FBUjtBQUNBLFVBQUEsSUFBSSxJQUFJLFFBQVI7QUFDQSxlQUFLLGVBQUw7QUFDQSxjQUFJLFFBQVEsR0FBRyxLQUFLLFlBQUwsQ0FBa0IsS0FBSyxlQUF2QixDQUFmOztBQUVBLGNBQUksUUFBUSxJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBakMsRUFBd0M7QUFDcEM7QUFDQTtBQUNBLFlBQUEsSUFBSSxJQUFJLEtBQUssaUJBQUwsQ0FBdUIsUUFBUSxDQUFDLEtBQWhDLENBQVI7QUFDSDs7QUFFRCxVQUFBLElBQUksSUFBSSxPQUFSO0FBQ0g7QUFDSjs7QUFFRCxNQUFBLElBQUksSUFBSSxLQUFLLE1BQUwsQ0FBWSxRQUFRLENBQUMsY0FBckIsRUFBcUMsR0FBckMsQ0FBUjtBQUNBLGFBQU8sSUFBUDtBQUNIOzs7V0FDRCxpQ0FBd0I7QUFDcEIsVUFBSSxjQUFjLEdBQUcsb0JBQW9CLENBQUMsTUFBckIsQ0FBNEIsSUFBNUIsQ0FBaUMsdUJBQWpDLENBQXJCOztBQUVBLFVBQUksaUJBQWlCLENBQUMsVUFBbEIsRUFBSixFQUFvQztBQUNoQyxRQUFBLGNBQWMsR0FBRyxZQUFZLENBQUMsU0FBYixDQUF1Qix1QkFBdkIsQ0FBakI7QUFDSDs7QUFFRCxhQUFPLEtBQUssUUFBTCxDQUFjLFFBQWQsQ0FBdUIsSUFBdkIsQ0FBNEIsY0FBNUIsQ0FBUDtBQUNIOzs7V0FDRCwwQkFBaUI7QUFDYixVQUFJLFdBQVcsR0FBRyxLQUFLLGtCQUFMLENBQXdCLGNBQXhCLENBQWxCO0FBQUEsVUFDSSxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQyxvQkFBbEIsRUFEeEI7O0FBR0EsVUFBSSxhQUFhLFdBQWIsSUFBNEIsY0FBYyxpQkFBMUMsSUFBK0QsYUFBYSxXQUFiLElBQTRCLGFBQWEsaUJBQTVHLEVBQStIO0FBQzNILGFBQUssY0FBTDtBQUNIO0FBQ0o7OztXQUNELDJCQUFrQjtBQUNkLFVBQUksTUFBTSxHQUFHLElBQWI7O0FBRUEsV0FBSyxZQUFMLEdBQW9CLEVBQXBCLENBSGMsQ0FHVTs7QUFFeEIsV0FBSyxRQUFMLENBQWMsU0FBZCxDQUF3QixJQUF4QixDQUE2QixVQUFTLEtBQVQsRUFBZ0IsT0FBaEIsRUFBeUI7QUFDbEQsUUFBQSxNQUFNLENBQUMsWUFBUCxDQUFvQixJQUFwQixDQUF5QjtBQUNyQixVQUFBLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxRQUFSLENBQWlCLEtBQWpCLENBQXVCLENBQXZCLENBRGU7QUFFckIsVUFBQSxJQUFJLEVBQUUsT0FBTyxDQUFDO0FBRk8sU0FBekI7QUFJSCxPQUxEO0FBTUg7OztXQUNELGVBQU07QUFDRixXQUFLLFFBQUwsQ0FBYyxTQUFkLEdBQTBCLEtBQUssV0FBTCxFQUExQjs7QUFFQSxVQUFJLENBQUMsS0FBSyxRQUFMLENBQWMsU0FBZCxDQUF3QixNQUE3QixFQUFxQztBQUNqQyxlQUFPLEtBQUsscUJBQUwsRUFBUDtBQUNIOztBQUVELFdBQUssZUFBTDs7QUFFQSxVQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBbEIsRUFBTCxFQUFxQztBQUNqQyxhQUFLLHdCQUFMO0FBQ0g7O0FBRUQsV0FBSyxXQUFMOztBQUVBLFVBQUksS0FBSyxrQkFBTCxDQUF3QixjQUF4QixDQUFKLEVBQTZDO0FBQ3pDLGFBQUssY0FBTDtBQUNIO0FBQ0o7OztXQUNELHdCQUFlO0FBQ1gsVUFBSSxTQUFTLEdBQUcsS0FBSyx1QkFBTCxDQUE2QixZQUE3QixDQUFoQjtBQUNBLFdBQUssUUFBTCxDQUFjLFdBQWQsQ0FBMEIsS0FBSyxXQUFMLENBQWlCLG1CQUFqQixDQUExQjtBQUNBLFdBQUssUUFBTCxDQUFjLFFBQWQsQ0FBdUIsU0FBdkIsR0FIVyxDQUd5Qjs7QUFFcEMsV0FBSyxRQUFMLENBQWMsbUJBQWQsQ0FBa0MsR0FBbEMsQ0FBc0MsWUFBdEMsRUFBb0QsU0FBUyxDQUFDLElBQVYsR0FBaUIsU0FBUyxDQUFDLElBQS9FO0FBQ0g7OztXQUNELDBCQUFpQjtBQUNiLFdBQUssUUFBTCxDQUFjLFFBQWQsQ0FBdUIsS0FBSyxXQUFMLENBQWlCLG1CQUFqQixDQUF2QjtBQUNBLFdBQUssUUFBTCxDQUFjLFFBQWQsQ0FBdUIsT0FBdkIsR0FGYSxDQUVxQjs7QUFFbEMsV0FBSyxRQUFMLENBQWMsbUJBQWQsQ0FBa0MsR0FBbEMsQ0FBc0MsWUFBdEMsRUFBb0QsS0FBcEQ7QUFDSDs7O1dBRUQsd0JBQWUsTUFBZixFQUF1QixRQUF2QixFQUFpQztBQUM3QixhQUFPLENBQUMsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsY0FBakIsQ0FBZ0MsSUFBaEMsQ0FBcUMsTUFBckMsRUFBNkMsUUFBN0MsQ0FBUixFQUFnRTtBQUM1RCxRQUFBLE1BQU0sR0FBRyxjQUFjLENBQUMsTUFBRCxDQUF2QjtBQUNBLFlBQUksTUFBTSxLQUFLLElBQWYsRUFBcUI7QUFDeEI7O0FBRUQsYUFBTyxNQUFQO0FBQ0g7OztXQUNELGVBQU0sTUFBTixFQUFjLFFBQWQsRUFBd0IsUUFBeEIsRUFBa0M7QUFDOUIsVUFBSSxPQUFPLE9BQVAsS0FBbUIsV0FBbkIsSUFBa0MsT0FBTyxDQUFDLEdBQTlDLEVBQW1EO0FBQy9DLGVBQU8sT0FBTyxDQUFDLEdBQVIsQ0FBWSxNQUFaLEVBQW9CLFFBQXBCLEVBQThCLFFBQVEsSUFBSSxNQUExQyxDQUFQO0FBQ0EsUUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQWhDO0FBQ0gsT0FIRCxNQUdPO0FBQ0gsWUFBSSxJQUFJLEdBQUcsYUFBYSxDQUFDLE1BQUQsRUFBUyxRQUFULENBQXhCO0FBQ0EsWUFBSSxDQUFDLElBQUwsRUFBVztBQUNYLFlBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyx3QkFBUCxDQUFnQyxJQUFoQyxFQUFzQyxRQUF0QyxDQUFYOztBQUVBLFlBQUksSUFBSSxDQUFDLEdBQVQsRUFBYztBQUNWLGlCQUFPLElBQUksQ0FBQyxHQUFMLENBQVMsSUFBVCxDQUFjLFFBQWQsQ0FBUDtBQUNIOztBQUVELGVBQU8sSUFBSSxDQUFDLEtBQVo7QUFFSDs7QUFFRCxhQUFPLElBQUksQ0FBQyxNQUFELEVBQVMsUUFBVCxFQUFtQixRQUFRLElBQUksTUFBL0IsQ0FBWDtBQUNIOzs7O0VBdGJpQixnQkFBZ0IsQ0FBQyxRQUFqQixDQUEwQixRQUExQixDQUFtQyxJOztBQTJiekQsMkJBQWUsT0FBZixFQUF3QixTQUF4QiIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uKCl7ZnVuY3Rpb24gcihlLG4sdCl7ZnVuY3Rpb24gbyhpLGYpe2lmKCFuW2ldKXtpZighZVtpXSl7dmFyIGM9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZTtpZighZiYmYylyZXR1cm4gYyhpLCEwKTtpZih1KXJldHVybiB1KGksITApO3ZhciBhPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIraStcIidcIik7dGhyb3cgYS5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGF9dmFyIHA9bltpXT17ZXhwb3J0czp7fX07ZVtpXVswXS5jYWxsKHAuZXhwb3J0cyxmdW5jdGlvbihyKXt2YXIgbj1lW2ldWzFdW3JdO3JldHVybiBvKG58fHIpfSxwLHAuZXhwb3J0cyxyLGUsbix0KX1yZXR1cm4gbltpXS5leHBvcnRzfWZvcih2YXIgdT1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlLGk9MDtpPHQubGVuZ3RoO2krKylvKHRbaV0pO3JldHVybiBvfXJldHVybiByfSkoKSIsImV4cG9ydCBjb25zdCBzbGlkZURvd24gPSAoZWxlbWVudCwgZHVyYXRpb24gPSAzMDApID0+IHtcbiAgICBsZXQgZGlzcGxheSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpLmRpc3BsYXk7XG5cbiAgICBpZiAoZGlzcGxheSA9PT0gXCJub25lXCIpIHtcbiAgICAgICAgZGlzcGxheSA9IFwiYmxvY2tcIjtcbiAgICB9XG5cbiAgICBlbGVtZW50LnN0eWxlLnRyYW5zaXRpb25Qcm9wZXJ0eSA9IFwiaGVpZ2h0XCI7XG4gICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uRHVyYXRpb24gPSBgJHtkdXJhdGlvbn1tc2A7XG5cbiAgICBlbGVtZW50LnN0eWxlLm9wYWNpdHkgPSAwO1xuICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IGRpc3BsYXk7XG4gICAgbGV0IGhlaWdodCA9IGVsZW1lbnQub2Zmc2V0SGVpZ2h0O1xuXG4gICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSAwO1xuICAgIGVsZW1lbnQuc3R5bGUub3BhY2l0eSA9IDE7XG4gICAgZWxlbWVudC5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSBgJHtoZWlnaHR9cHhgO1xuICAgIH0sIDUpO1xuXG4gICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwiaGVpZ2h0XCIpO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwib3ZlcmZsb3dcIik7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uLWR1cmF0aW9uXCIpO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwidHJhbnNpdGlvbi1wcm9wZXJ0eVwiKTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm9wYWNpdHlcIik7XG4gICAgfSwgZHVyYXRpb24gKyA1MCk7XG59O1xuXG5leHBvcnQgY29uc3Qgc2xpZGVVcCA9IChlbGVtZW50LCBkdXJhdGlvbiA9IDMwMCkgPT4ge1xuICAgIGVsZW1lbnQuc3R5bGUuYm94U2l6aW5nID0gXCJib3JkZXItYm94XCI7XG4gICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uUHJvcGVydHkgPSBcImhlaWdodCwgbWFyZ2luXCI7XG4gICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uRHVyYXRpb24gPSBgJHtkdXJhdGlvbn1tc2A7XG4gICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSBgJHtlbGVtZW50Lm9mZnNldEhlaWdodH1weGA7XG4gICAgZWxlbWVudC5zdHlsZS5tYXJnaW5Ub3AgPSAwO1xuICAgIGVsZW1lbnQuc3R5bGUubWFyZ2luQm90dG9tID0gMDtcbiAgICBlbGVtZW50LnN0eWxlLm92ZXJmbG93ID0gXCJoaWRkZW5cIjtcblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBlbGVtZW50LnN0eWxlLmhlaWdodCA9IDA7XG4gICAgfSwgNSk7XG5cbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwiaGVpZ2h0XCIpO1xuICAgICAgICBlbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFwibWFyZ2luLXRvcFwiKTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcIm1hcmdpbi1ib3R0b21cIik7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJvdmVyZmxvd1wiKTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcInRyYW5zaXRpb24tZHVyYXRpb25cIik7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uLXByb3BlcnR5XCIpO1xuICAgIH0sIGR1cmF0aW9uICsgNTApO1xufTtcblxuZXhwb3J0IGNvbnN0IHNsaWRlVG9nZ2xlID0gKGVsZW1lbnQsIGR1cmF0aW9uKSA9PiB7XG4gICAgd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkuZGlzcGxheSA9PT0gXCJub25lXCIgPyBzbGlkZURvd24oZWxlbWVudCwgZHVyYXRpb24pIDogc2xpZGVVcChlbGVtZW50LCBkdXJhdGlvbik7XG59O1xuXG5leHBvcnQgY29uc3QgZmFkZUluID0gKGVsZW1lbnQsIF9vcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICBkdXJhdGlvbjogMzAwLFxuICAgICAgICBkaXNwbGF5OiBudWxsLFxuICAgICAgICBvcGFjaXR5OiAxLFxuICAgICAgICBjYWxsYmFjazogbnVsbCxcbiAgICB9O1xuXG4gICAgT2JqZWN0LmFzc2lnbihvcHRpb25zLCBfb3B0aW9ucyk7XG5cbiAgICBlbGVtZW50LnN0eWxlLm9wYWNpdHkgPSAwO1xuICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IG9wdGlvbnMuZGlzcGxheSB8fCBcImJsb2NrXCI7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uID0gYCR7b3B0aW9ucy5kdXJhdGlvbn1tcyBvcGFjaXR5IGVhc2VgO1xuICAgICAgICBlbGVtZW50LnN0eWxlLm9wYWNpdHkgPSBvcHRpb25zLm9wYWNpdHk7XG4gICAgfSwgNSk7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcInRyYW5zaXRpb25cIik7XG4gICAgICAgICEhb3B0aW9ucy5jYWxsYmFjayAmJiBvcHRpb25zLmNhbGxiYWNrKCk7XG4gICAgfSwgb3B0aW9ucy5kdXJhdGlvbiArIDUwKTtcbn07XG5cbmV4cG9ydCBjb25zdCBmYWRlT3V0ID0gKGVsZW1lbnQsIF9vcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICBkdXJhdGlvbjogMzAwLFxuICAgICAgICBkaXNwbGF5OiBudWxsLFxuICAgICAgICBvcGFjaXR5OiAwLFxuICAgICAgICBjYWxsYmFjazogbnVsbCxcbiAgICB9O1xuXG4gICAgT2JqZWN0LmFzc2lnbihvcHRpb25zLCBfb3B0aW9ucyk7XG5cbiAgICBlbGVtZW50LnN0eWxlLm9wYWNpdHkgPSAxO1xuICAgIGVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IG9wdGlvbnMuZGlzcGxheSB8fCBcImJsb2NrXCI7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2l0aW9uID0gYCR7b3B0aW9ucy5kdXJhdGlvbn1tcyBvcGFjaXR5IGVhc2VgO1xuICAgICAgICBlbGVtZW50LnN0eWxlLm9wYWNpdHkgPSBvcHRpb25zLm9wYWNpdHk7XG4gICAgfSwgNSk7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucmVtb3ZlUHJvcGVydHkoXCJ0cmFuc2l0aW9uXCIpO1xuICAgICAgICAhIW9wdGlvbnMuY2FsbGJhY2sgJiYgb3B0aW9ucy5jYWxsYmFjaygpO1xuICAgIH0sIG9wdGlvbnMuZHVyYXRpb24gKyA1MCk7XG59O1xuXG5leHBvcnQgY29uc3QgZmFkZVRvZ2dsZSA9IChlbGVtZW50LCBvcHRpb25zKSA9PiB7XG4gICAgd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkuZGlzcGxheSA9PT0gXCJub25lXCIgPyBmYWRlSW4oZWxlbWVudCwgb3B0aW9ucykgOiBmYWRlT3V0KGVsZW1lbnQsIG9wdGlvbnMpO1xufTtcblxuZXhwb3J0IGNvbnN0IG9mZnNldCA9IChlbGVtZW50KSA9PiB7XG4gICAgaWYgKCFlbGVtZW50LmdldENsaWVudFJlY3RzKCkubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiB7IHRvcDogMCwgbGVmdDogMCB9O1xuICAgIH1cblxuICAgIC8vIEdldCBkb2N1bWVudC1yZWxhdGl2ZSBwb3NpdGlvbiBieSBhZGRpbmcgdmlld3BvcnQgc2Nyb2xsIHRvIHZpZXdwb3J0LXJlbGF0aXZlIGdCQ1JcbiAgICBjb25zdCByZWN0ID0gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCB3aW4gPSBlbGVtZW50Lm93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXc7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgdG9wOiByZWN0LnRvcCArIHdpbi5wYWdlWU9mZnNldCxcbiAgICAgICAgbGVmdDogcmVjdC5sZWZ0ICsgd2luLnBhZ2VYT2Zmc2V0LFxuICAgIH07XG59O1xuXG5leHBvcnQgY29uc3QgdmlzaWJsZSA9IChlbGVtZW50KSA9PiB7XG4gICAgaWYgKCFlbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICByZXR1cm4gISEoZWxlbWVudC5vZmZzZXRXaWR0aCB8fCBlbGVtZW50Lm9mZnNldEhlaWdodCB8fCBlbGVtZW50LmdldENsaWVudFJlY3RzKCkubGVuZ3RoKTtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRTaWJsaW5ncyA9IChlKSA9PiB7XG4gICAgLy8gZm9yIGNvbGxlY3Rpbmcgc2libGluZ3NcbiAgICBjb25zdCBzaWJsaW5ncyA9IFtdO1xuXG4gICAgLy8gaWYgbm8gcGFyZW50LCByZXR1cm4gbm8gc2libGluZ1xuICAgIGlmICghZS5wYXJlbnROb2RlKSB7XG4gICAgICAgIHJldHVybiBzaWJsaW5ncztcbiAgICB9XG5cbiAgICAvLyBmaXJzdCBjaGlsZCBvZiB0aGUgcGFyZW50IG5vZGVcbiAgICBsZXQgc2libGluZyA9IGUucGFyZW50Tm9kZS5maXJzdENoaWxkO1xuXG4gICAgLy8gY29sbGVjdGluZyBzaWJsaW5nc1xuICAgIHdoaWxlIChzaWJsaW5nKSB7XG4gICAgICAgIGlmIChzaWJsaW5nLm5vZGVUeXBlID09PSAxICYmIHNpYmxpbmcgIT09IGUpIHtcbiAgICAgICAgICAgIHNpYmxpbmdzLnB1c2goc2libGluZyk7XG4gICAgICAgIH1cblxuICAgICAgICBzaWJsaW5nID0gc2libGluZy5uZXh0U2libGluZztcbiAgICB9XG5cbiAgICByZXR1cm4gc2libGluZ3M7XG59O1xuXG4vLyBSZXR1cm5zIHRydWUgaWYgaXQgaXMgYSBET00gZWxlbWVudFxuZXhwb3J0IGNvbnN0IGlzRWxlbWVudCA9IChvKSA9PiB7XG4gICAgcmV0dXJuIHR5cGVvZiBIVE1MRWxlbWVudCA9PT0gXCJvYmplY3RcIlxuICAgICAgICA/IG8gaW5zdGFuY2VvZiBIVE1MRWxlbWVudCAvLyBET00yXG4gICAgICAgIDogbyAmJiB0eXBlb2YgbyA9PT0gXCJvYmplY3RcIiAmJiBvICE9PSBudWxsICYmIG8ubm9kZVR5cGUgPT09IDEgJiYgdHlwZW9mIG8ubm9kZU5hbWUgPT09IFwic3RyaW5nXCI7XG59O1xuXG5leHBvcnQgY29uc3QgcmVnaXN0ZXJXaWRnZXQgPSAoY2xhc3NOYW1lLCB3aWRnZXROYW1lLCBza2luID0gXCJkZWZhdWx0XCIpID0+IHtcbiAgICBpZiAoIShjbGFzc05hbWUgfHwgd2lkZ2V0TmFtZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEJlY2F1c2UgRWxlbWVudG9yIHBsdWdpbiB1c2VzIGpRdWVyeSBjdXN0b20gZXZlbnQsXG4gICAgICogV2UgYWxzbyBoYXZlIHRvIHVzZSBqUXVlcnkgdG8gdXNlIHRoaXMgZXZlbnRcbiAgICAgKi9cbiAgICBqUXVlcnkod2luZG93KS5vbihcImVsZW1lbnRvci9mcm9udGVuZC9pbml0XCIsICgpID0+IHtcbiAgICAgICAgY29uc3QgYWRkSGFuZGxlciA9ICgkZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgZWxlbWVudG9yRnJvbnRlbmQuZWxlbWVudHNIYW5kbGVyLmFkZEhhbmRsZXIoY2xhc3NOYW1lLCB7XG4gICAgICAgICAgICAgICAgJGVsZW1lbnQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBlbGVtZW50b3JGcm9udGVuZC5ob29rcy5hZGRBY3Rpb24oYGZyb250ZW5kL2VsZW1lbnRfcmVhZHkvJHt3aWRnZXROYW1lfS4ke3NraW59YCwgYWRkSGFuZGxlcik7XG4gICAgfSk7XG59O1xuIiwiaW1wb3J0IHtcbiAgICByZWdpc3RlcldpZGdldFxufSBmcm9tIFwiLi4vbGliL3V0aWxzXCI7XG5cbmNsYXNzIE9FV19UT0MgZXh0ZW5kcyBlbGVtZW50b3JNb2R1bGVzLmZyb250ZW5kLmhhbmRsZXJzLkJhc2Uge1xuXG4gICAgZ2V0RGVmYXVsdFNldHRpbmdzKCkge1xuICAgICAgICB2YXIgZWxlbWVudFNldHRpbmdzID0gdGhpcy5nZXRFbGVtZW50U2V0dGluZ3MoKSxcbiAgICAgICAgICAgIGxpc3RXcmFwcGVyVGFnID0gJ251bWJlcnMnID09PSBlbGVtZW50U2V0dGluZ3MubWFya2VyX3ZpZXcgPyAnb2wnIDogJ3VsJztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNlbGVjdG9yczoge1xuICAgICAgICAgICAgICAgIHdpZGdldFRvY0NvbnRhaW5lcjogJy5lbGVtZW50b3Itd2lkZ2V0LW9ldy10b2MnLFxuICAgICAgICAgICAgICAgIHBvc3RDb250ZW50Q29udGFpbmVyOiAnLmVsZW1lbnRvcjpub3QoW2RhdGEtZWxlbWVudG9yLXR5cGU9XCJoZWFkZXJcIl0pOm5vdChbZGF0YS1lbGVtZW50b3ItdHlwZT1cImZvb3RlclwiXSk6bm90KFtkYXRhLWVsZW1lbnRvci10eXBlPVwicG9wdXBcIl0pJyxcbiAgICAgICAgICAgICAgICBleHBhbmRCdXR0b246ICcub2V3LXRvYy10b2dnbGUtYnV0dG9uLWV4cGFuZCcsXG4gICAgICAgICAgICAgICAgY29sbGFwc2VCdXR0b246ICcub2V3LXRvYy10b2dnbGUtYnV0dG9uLWNvbGxhcHNlJyxcbiAgICAgICAgICAgICAgICBib2R5OiAnLm9ldy10b2MtYm9keScsXG4gICAgICAgICAgICAgICAgaGVhZGVyVGl0bGU6ICcub2V3LXRvYy1oZWFkZXItdGl0bGUnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY2xhc3Nlczoge1xuICAgICAgICAgICAgICAgIGFuY2hvcjogJ2VsZW1lbnRvci1tZW51LWFuY2hvcicsXG4gICAgICAgICAgICAgICAgbGlzdFdyYXBwZXI6ICdvZXctdG9jLWxpc3Qtd3JhcHBlcicsXG4gICAgICAgICAgICAgICAgbGlzdEl0ZW06ICdvZXctdG9jLWxpc3QtaXRlbScsXG4gICAgICAgICAgICAgICAgbGlzdFRleHRXcmFwcGVyOiAnb2V3LXRvYy1saXN0LWl0ZW0tdGV4dC13cmFwcGVyJyxcbiAgICAgICAgICAgICAgICBmaXJzdExldmVsTGlzdEl0ZW06ICdvZXctdG9jLXRvcC1sZXZlbCcsXG4gICAgICAgICAgICAgICAgbGlzdEl0ZW1UZXh0OiAnb2V3LXRvYy1saXN0LWl0ZW0tdGV4dCcsXG4gICAgICAgICAgICAgICAgYWN0aXZlSXRlbTogJ2VsZW1lbnRvci1pdGVtLWFjdGl2ZScsXG4gICAgICAgICAgICAgICAgaGVhZGluZ0FuY2hvcjogJ29ldy10b2MtaGVhZGluZy1hbmNob3InLFxuICAgICAgICAgICAgICAgIGNvbGxhcHNlZDogJ29ldy10b2MtY29sbGFwc2VkJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGxpc3RXcmFwcGVyVGFnOiBsaXN0V3JhcHBlclRhZ1xuICAgICAgICB9O1xuICAgIH1cblxuICAgIGdldERlZmF1bHRFbGVtZW50cygpIHtcbiAgICAgICAgdmFyIHNldHRpbmdzID0gdGhpcy5nZXRTZXR0aW5ncygpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgJHBhZ2VDb250YWluZXI6IHRoaXMuZ2V0VG9jQ29udGFpbmVyKCksXG4gICAgICAgICAgICAkd2lkZ2V0VG9jQ29udGFpbmVyOiB0aGlzLiRlbGVtZW50LmZpbmQoc2V0dGluZ3Muc2VsZWN0b3JzLndpZGdldFRvY0NvbnRhaW5lciksXG4gICAgICAgICAgICAkZXhwYW5kQnV0dG9uOiB0aGlzLiRlbGVtZW50LmZpbmQoc2V0dGluZ3Muc2VsZWN0b3JzLmV4cGFuZEJ1dHRvbiksXG4gICAgICAgICAgICAkY29sbGFwc2VCdXR0b246IHRoaXMuJGVsZW1lbnQuZmluZChzZXR0aW5ncy5zZWxlY3RvcnMuY29sbGFwc2VCdXR0b24pLFxuICAgICAgICAgICAgJHRvY0JvZHk6IHRoaXMuJGVsZW1lbnQuZmluZChzZXR0aW5ncy5zZWxlY3RvcnMuYm9keSksXG4gICAgICAgICAgICAkbGlzdEl0ZW1zOiB0aGlzLiRlbGVtZW50LmZpbmQoJy4nICsgc2V0dGluZ3MuY2xhc3Nlcy5saXN0SXRlbSlcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBnZXRUb2NDb250YWluZXIoKSB7XG4gICAgICAgIHZhciBzZXR0aW5ncyA9IHRoaXMuZ2V0U2V0dGluZ3MoKSxcbiAgICAgICAgICAgIGVsZW1lbnRTZXR0aW5ncyA9IHRoaXMuZ2V0RWxlbWVudFNldHRpbmdzKCk7XG5cbiAgICAgICAgaWYgKGVsZW1lbnRTZXR0aW5ncy5jb250YWluZXIpIHtcbiAgICAgICAgICAgIHJldHVybiBqUXVlcnkoZWxlbWVudFNldHRpbmdzLmNvbnRhaW5lcik7XG4gICAgICAgIH1cblxuXG4gICAgICAgIHZhciAkZG9jdW1lbnRXcmFwcGVyID0gdGhpcy4kZWxlbWVudC5wYXJlbnRzKCcuZWxlbWVudG9yJyk7XG5cbiAgICAgICAgaWYgKCdwb3B1cCcgPT09ICRkb2N1bWVudFdyYXBwZXIuYXR0cignZGF0YS1lbGVtZW50b3ItdHlwZScpKSB7XG4gICAgICAgICAgICByZXR1cm4gJGRvY3VtZW50V3JhcHBlcjtcbiAgICAgICAgfVxuXG5cbiAgICAgICAgcmV0dXJuIGpRdWVyeShzZXR0aW5ncy5zZWxlY3RvcnMucG9zdENvbnRlbnRDb250YWluZXIpO1xuICAgIH1cbiAgICBiaW5kRXZlbnRzKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgIHZhciBlbGVtZW50U2V0dGluZ3MgPSB0aGlzLmdldEVsZW1lbnRTZXR0aW5ncygpO1xuXG4gICAgICAgIGlmIChlbGVtZW50U2V0dGluZ3MubWluaW1pemVfYm94KSB7XG4gICAgICAgICAgICB0aGlzLmVsZW1lbnRzLiRleHBhbmRCdXR0b24ub24oJ2NsaWNrJywgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmV4cGFuZFRvY0JveCgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmVsZW1lbnRzLiRjb2xsYXBzZUJ1dHRvbi5vbignY2xpY2snLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY29sbGFwc2VUb2NCb3goKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGVsZW1lbnRTZXR0aW5ncy5jb2xsYXBzZV9zdWJpdGVtcykge1xuICAgICAgICAgICAgdGhpcy5lbGVtZW50cy4kbGlzdEl0ZW1zLmhvdmVyKGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGpRdWVyeShldmVudC50YXJnZXQpLnNsaWRlVG9nZ2xlKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBnZXRIZWFkaW5ncygpIHtcbiAgICAgICAgLy8gR2V0IGFsbCBoZWFkaW5ncyBmcm9tIGRvY3VtZW50IGJ5IHVzZXItc2VsZWN0ZWQgdGFnc1xuICAgICAgICB2YXIgZWxlbWVudFNldHRpbmdzID0gdGhpcy5nZXRFbGVtZW50U2V0dGluZ3MoKSxcbiAgICAgICAgICAgIHRhZ3MgPSBlbGVtZW50U2V0dGluZ3MuaGVhZGluZ3NfYnlfdGFncy5qb2luKCcsJyksXG4gICAgICAgICAgICBzZWxlY3RvcnMgPSB0aGlzLmdldFNldHRpbmdzKCdzZWxlY3RvcnMnKSxcbiAgICAgICAgICAgIGV4Y2x1ZGVkU2VsZWN0b3JzID0gZWxlbWVudFNldHRpbmdzLmV4Y2x1ZGVfaGVhZGluZ3NfYnlfc2VsZWN0b3I7XG4gICAgICAgIHJldHVybiB0aGlzLmVsZW1lbnRzLiRwYWdlQ29udGFpbmVyLmZpbmQodGFncykubm90KHNlbGVjdG9ycy5oZWFkZXJUaXRsZSkuZmlsdGVyKGZ1bmN0aW9uKGluZGV4LCBoZWFkaW5nKSB7XG4gICAgICAgICAgICByZXR1cm4gIWpRdWVyeShoZWFkaW5nKS5jbG9zZXN0KGV4Y2x1ZGVkU2VsZWN0b3JzKS5sZW5ndGg7IC8vIEhhbmRsZSBleGNsdWRlZCBzZWxlY3RvcnMgaWYgdGhlcmUgYXJlIGFueVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYWRkQW5jaG9yc0JlZm9yZUhlYWRpbmdzKCkge1xuICAgICAgICAvLyBBZGQgYW4gYW5jaG9yIGVsZW1lbnQgcmlnaHQgYmVmb3JlIGVhY2ggVE9DIGhlYWRpbmcgdG8gY3JlYXRlIGFuY2hvcnMgZm9yIFRPQyBsaW5rc1xuICAgICAgICB2YXIgY2xhc3NlcyA9IHRoaXMuZ2V0U2V0dGluZ3MoJ2NsYXNzZXMnKTtcbiAgICAgICAgdmFyIGVsZW1lbnRTZXR0aW5ncyA9IHRoaXMuZ2V0RWxlbWVudFNldHRpbmdzKCk7XG4gICAgICAgIHRoaXMuZWxlbWVudHMuJGhlYWRpbmdzLmVhY2goZnVuY3Rpb24oaW5kZXgpIHtcbiAgICAgICAgICBpZiAoZWxlbWVudFNldHRpbmdzLmR1cGxpY2F0ZV9hbmNob3JfZml4ID09ICd5ZXMnKSB7XG4gICAgICAgICAgICAgIHZhciBhbmNob3JUZXh0ID0gdGhpcy50ZXh0Q29udGVudC5yZXBsYWNlKC9cXHMrL2csICctJykucmVwbGFjZSgvW15cXHctXSsvZywgJycpLnRvTG93ZXJDYXNlKCkgKyAnLScgKyBpbmRleDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB2YXIgYW5jaG9yVGV4dCA9IHRoaXMudGV4dENvbnRlbnQucmVwbGFjZSgvXFxzKy9nLCAnLScpLnJlcGxhY2UoL1teXFx3LV0rL2csICcnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnaWQnLCBhbmNob3JUZXh0KTtcbiAgICAgIH0pO1xuXG4gICAgfVxuICAgIF9nZXRQcm90b3R5cGVPZihvKSB7XG4gICAgICAgIHJldHVybiBvLl9fcHJvdG9fXyB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2Yobyk7XG4gICAgfVxuICAgIG9uSW5pdCgpIHtcbiAgICAgICAgdmFyIF9nZXQyLFxuICAgICAgICAgICAgX3RoaXM2ID0gdGhpcztcblxuICAgICAgICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgICAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgICAgIH1cblxuICAgICAgICAoX2dldDIgPSAoMCwgdGhpcy5fZ2V0MykoKDAsIHRoaXMuX2dldFByb3RvdHlwZU9mKShPRVdfVE9DLnByb3RvdHlwZSksIFwib25Jbml0XCIsIHRoaXMpKS5jYWxsLmFwcGx5KF9nZXQyLCBbdGhpc10uY29uY2F0KGFyZ3MpKTtcblxuICAgICAgICB0aGlzLnZpZXdwb3J0SXRlbXMgPSBbXTtcbiAgICAgICAgalF1ZXJ5KGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBfdGhpczYucnVuKCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG9uTGlzdEl0ZW1DbGljayhldmVudCkge1xuICAgICAgdmFyIF90aGlzNyA9IHRoaXM7XG5cbiAgICAgIHRoaXMuaXRlbUNsaWNrZWQgPSB0cnVlO1xuICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgICByZXR1cm4gX3RoaXM3Lml0ZW1DbGlja2VkID0gZmFsc2U7XG4gICAgICB9LCAyMDAwKTtcblxuICAgICAgdmFyICRjbGlja2VkSXRlbSA9IGpRdWVyeShldmVudC5jdXJyZW50VGFyZ2V0KSxcbiAgICAgICAgICAkbGlzdCA9ICRjbGlja2VkSXRlbS5wYXJlbnQoKS5uZXh0KCksXG4gICAgICAgICAgY29sbGFwc2VOZXN0ZWRMaXN0ID0gdGhpcy5nZXRFbGVtZW50U2V0dGluZ3MoJ2NvbGxhcHNlX3N1Yml0ZW1zJyk7XG4gICAgICB2YXIgbGlzdElzQWN0aXZlO1xuXG4gICAgICBpZiAoY29sbGFwc2VOZXN0ZWRMaXN0ICYmICRjbGlja2VkSXRlbS5oYXNDbGFzcyh0aGlzLmdldFNldHRpbmdzKCdjbGFzc2VzLmZpcnN0TGV2ZWxMaXN0SXRlbScpKSkge1xuICAgICAgICAgIGlmICgkbGlzdC5pcygnOnZpc2libGUnKSkge1xuICAgICAgICAgICAgICBsaXN0SXNBY3RpdmUgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhpcy5hY3RpdmF0ZVRvY0l0ZW0oJGNsaWNrZWRJdGVtKTtcblxuICAgICAgaWYgKGNvbGxhcHNlTmVzdGVkTGlzdCAmJiBsaXN0SXNBY3RpdmUpIHtcbiAgICAgICAgICAkbGlzdC5zbGlkZVVwKCk7XG4gICAgICB9XG5cbiAgfVxuXG5cbiAgICBhY3RpdmF0ZVRvY0l0ZW0oJGxpc3RJdGVtKSB7XG5cbiAgICAgICAgdmFyIGNsYXNzZXMgPSB0aGlzLmdldFNldHRpbmdzKCdjbGFzc2VzJyk7XG4gICAgICAgIHRoaXMuZGVhY3RpdmF0ZVRvY0FjdGl2ZUl0ZW0oJGxpc3RJdGVtKTtcbiAgICAgICAgJGxpc3RJdGVtLmFkZENsYXNzKGNsYXNzZXMuYWN0aXZlSXRlbSk7XG4gICAgICAgIHRoaXMuJGFjdGl2ZUl0ZW0gPSAkbGlzdEl0ZW07XG5cbiAgICAgICAgaWYgKCF0aGlzLmdldEVsZW1lbnRTZXR0aW5ncygnY29sbGFwc2Vfc3ViaXRlbXMnKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyICRhY3RpdmVMaXN0O1xuXG4gICAgICAgIGlmICgkbGlzdEl0ZW0uaGFzQ2xhc3MoY2xhc3Nlcy5maXJzdExldmVsTGlzdEl0ZW0pKSB7XG4gICAgICAgICAgICAkYWN0aXZlTGlzdCA9ICRsaXN0SXRlbS5wYXJlbnQoKS5uZXh0KCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAkYWN0aXZlTGlzdCA9ICRsaXN0SXRlbS5wYXJlbnRzKCcuJyArIGNsYXNzZXMubGlzdFdyYXBwZXIpLmVxKC0yKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghJGFjdGl2ZUxpc3QubGVuZ3RoKSB7XG4gICAgICAgICAgICBkZWxldGUgdGhpcy4kYWN0aXZlTGlzdDtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuJGFjdGl2ZUxpc3QgPSAkYWN0aXZlTGlzdDtcbiAgICAgICAgdGhpcy4kYWN0aXZlTGlzdC5zdG9wKCkuc2xpZGVEb3duKCk7XG4gICAgfVxuXG4gICAgZGVhY3RpdmF0ZVRvY0FjdGl2ZUl0ZW0oJGFjdGl2ZVRvQmUpIHtcbiAgICAgICAgaWYgKCF0aGlzLiRhY3RpdmVJdGVtIHx8IHRoaXMuJGFjdGl2ZUl0ZW0uaXMoJGFjdGl2ZVRvQmUpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgX3RoaXMkZ2V0U2V0dGluZ3MgPSB0aGlzLmdldFNldHRpbmdzKCksXG4gICAgICAgICAgICBjbGFzc2VzID0gX3RoaXMkZ2V0U2V0dGluZ3MuY2xhc3NlcztcblxuICAgICAgICB0aGlzLiRhY3RpdmVJdGVtLnJlbW92ZUNsYXNzKGNsYXNzZXMuYWN0aXZlSXRlbSk7XG5cbiAgICAgICAgaWYgKHRoaXMuJGFjdGl2ZUxpc3QgJiYgKCEkYWN0aXZlVG9CZSB8fCAhdGhpcy4kYWN0aXZlTGlzdFswXS5jb250YWlucygkYWN0aXZlVG9CZVswXSkpKSB7XG4gICAgICAgICAgICB0aGlzLiRhY3RpdmVMaXN0LnNsaWRlVXAoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGZvbGxvd1RvY0FuY2hvcigkZWxlbWVudCwgaW5kZXgpIHtcbiAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgICB2YXIgYW5jaG9yU2VsZWN0b3IgPSAkZWxlbWVudFswXS5oYXNoO1xuICAgICAgdmFyICRhbmNob3I7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgICAgLy8gYGRlY29kZVVSSUNvbXBvbmVudGAgZm9yIFVURjggY2hhcmFjdGVycyBpbiB0aGUgaGFzaC5cbiAgICAgICAgICAkYW5jaG9yID0galF1ZXJ5KGRlY29kZVVSSUNvbXBvbmVudChhbmNob3JTZWxlY3RvcikpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gSW1wbGVtZW50IEludGVyc2VjdGlvbiBPYnNlcnZlciBpbnN0ZWFkIG9mIFdheXBvaW50XG4gICAgICBjb25zdCBvYnNlcnZlck9wdGlvbnMgPSB7XG4gICAgICAgICAgcm9vdDogbnVsbCwgLy8gdmlld3BvcnRcbiAgICAgICAgICByb290TWFyZ2luOiAnMHB4JyxcbiAgICAgICAgICB0aHJlc2hvbGQ6IDAuMSAvLyB0cmlnZ2VyIHdoZW4gMTAlIG9mIHRoZSBlbGVtZW50IGlzIHZpc2libGVcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IGNhbGxiYWNrID0gKGVudHJpZXMpID0+IHtcbiAgICAgICAgICBlbnRyaWVzLmZvckVhY2goZW50cnkgPT4ge1xuICAgICAgICAgICAgICBpZiAoX3RoaXMyLml0ZW1DbGlja2VkKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBjb25zdCBpZCA9IGVudHJ5LnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2lkJyk7XG5cbiAgICAgICAgICAgICAgaWYgKGVudHJ5LmlzSW50ZXJzZWN0aW5nKSB7XG4gICAgICAgICAgICAgICAgICBpZiAoZW50cnkuYm91bmRpbmdDbGllbnRSZWN0LnRvcCA+IDApIHsgLy8gU2Nyb2xsaW5nIGRvd25cbiAgICAgICAgICAgICAgICAgICAgICBfdGhpczIudmlld3BvcnRJdGVtc1tpZF0gPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgIF90aGlzMi5hY3RpdmF0ZVRvY0l0ZW0oJGVsZW1lbnQpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgaWYgKGVudHJ5LmJvdW5kaW5nQ2xpZW50UmVjdC50b3AgPCAwKSB7IC8vIFNjcm9sbGluZyB1cFxuICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBfdGhpczIudmlld3BvcnRJdGVtc1tpZF07XG4gICAgICAgICAgICAgICAgICAgICAgX3RoaXMyLmFjdGl2YXRlVG9jSXRlbShfdGhpczIuJGxpc3RJdGVtVGV4dHMuZXEoaW5kZXggLSAxKSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKGNhbGxiYWNrLCBvYnNlcnZlck9wdGlvbnMpO1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYW5jaG9yU2VsZWN0b3IucmVwbGFjZSgnIycsICcnKSk7XG4gICAgICBpZiAodGFyZ2V0KSB7XG4gICAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZSh0YXJnZXQpO1xuICAgICAgfVxuXG4gIH1cblxuXG4gICAgZm9sbG93VG9jQW5jaG9ycygpIHtcbiAgICAgICAgdmFyIF90aGlzMyA9IHRoaXM7XG5cbiAgICAgICAgdGhpcy4kbGlzdEl0ZW1UZXh0cy5lYWNoKGZ1bmN0aW9uKGluZGV4LCBlbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gX3RoaXMzLmZvbGxvd1RvY0FuY2hvcihqUXVlcnkoZWxlbWVudCksIGluZGV4KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcG9wdWxhdGVUT0MoKSB7XG4gICAgICAgIHRoaXMubGlzdEl0ZW1Qb2ludGVyID0gMDtcbiAgICAgICAgdmFyIGVsZW1lbnRTZXR0aW5ncyA9IHRoaXMuZ2V0RWxlbWVudFNldHRpbmdzKCk7XG5cbiAgICAgICAgaWYgKGVsZW1lbnRTZXR0aW5ncy5oaWVyYXJjaGljYWxfdmlldykge1xuICAgICAgICAgICAgdGhpcy5jcmVhdGVOZXN0ZWRMaXN0KCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmNyZWF0ZUZsYXRMaXN0KCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLiRsaXN0SXRlbVRleHRzID0gdGhpcy4kZWxlbWVudC5maW5kKCcub2V3LXRvYy1saXN0LWl0ZW0tdGV4dCcpO1xuICAgICAgICB0aGlzLiRsaXN0SXRlbVRleHRzLm9uKCdjbGljaycsIHRoaXMub25MaXN0SXRlbUNsaWNrLmJpbmQodGhpcykpO1xuXG4gICAgICAgIGlmICghZWxlbWVudG9yRnJvbnRlbmQuaXNFZGl0TW9kZSgpKSB7XG4gICAgICAgICAgICB0aGlzLmZvbGxvd1RvY0FuY2hvcnMoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGNyZWF0ZU5lc3RlZExpc3QoKSB7XG4gICAgICAgIHZhciBfdGhpczQgPSB0aGlzO1xuXG4gICAgICAgIHRoaXMuaGVhZGluZ3NEYXRhLmZvckVhY2goZnVuY3Rpb24oaGVhZGluZywgaW5kZXgpIHtcbiAgICAgICAgICAgIGhlYWRpbmcubGV2ZWwgPSAwO1xuXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gaW5kZXggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICAgICAgICAgIHZhciBjdXJyZW50T3JkZXJlZEl0ZW0gPSBfdGhpczQuaGVhZGluZ3NEYXRhW2ldO1xuXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRPcmRlcmVkSXRlbS50YWcgPD0gaGVhZGluZy50YWcpIHtcbiAgICAgICAgICAgICAgICAgICAgaGVhZGluZy5sZXZlbCA9IGN1cnJlbnRPcmRlcmVkSXRlbS5sZXZlbDtcblxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudE9yZGVyZWRJdGVtLnRhZyA8IGhlYWRpbmcudGFnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkaW5nLmxldmVsKys7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmVsZW1lbnRzLiR0b2NCb2R5Lmh0bWwodGhpcy5nZXROZXN0ZWRUb2NMZXZlbCgwKSk7XG4gICAgfVxuXG4gICAgY3JlYXRlRmxhdExpc3QoKSB7XG4gICAgICAgIHRoaXMuZWxlbWVudHMuJHRvY0JvZHkuaHRtbCh0aGlzLmdldE5lc3RlZFRvY0xldmVsKCkpO1xuICAgIH1cblxuICAgIGdldE5lc3RlZFRvY0xldmVsKGxldmVsKSB7XG4gICAgICAgIHZhciBzZXR0aW5ncyA9IHRoaXMuZ2V0U2V0dGluZ3MoKSxcbiAgICAgICAgICAgIGVsZW1lbnRTZXR0aW5ncyA9IHRoaXMuZ2V0RWxlbWVudFNldHRpbmdzKCksXG4gICAgICAgICAgICBpY29uID0gdGhpcy5nZXRFbGVtZW50U2V0dGluZ3MoJ2ljb24nKTsgLy8gT3BlbiBuZXcgbGlzdC9uZXN0ZWQgbGlzdFxuXG4gICAgICAgIHZhciBodG1sID0gXCI8XCIuY29uY2F0KHNldHRpbmdzLmxpc3RXcmFwcGVyVGFnLCBcIiBjbGFzcz1cXFwiXCIpLmNvbmNhdChzZXR0aW5ncy5jbGFzc2VzLmxpc3RXcmFwcGVyLCBcIlxcXCI+XCIpOyAvLyBmb3IgZWFjaCBsaXN0IGl0ZW0sIGJ1aWxkIGl0cyBtYXJrdXAuXG5cbiAgICAgICAgd2hpbGUgKHRoaXMubGlzdEl0ZW1Qb2ludGVyIDwgdGhpcy5oZWFkaW5nc0RhdGEubGVuZ3RoKSB7XG4gICAgICAgICAgICB2YXIgY3VycmVudEl0ZW0gPSB0aGlzLmhlYWRpbmdzRGF0YVt0aGlzLmxpc3RJdGVtUG9pbnRlcl07XG4gICAgICAgICAgICB2YXIgbGlzdEl0ZW1UZXh0Q2xhc3NlcyA9IHNldHRpbmdzLmNsYXNzZXMubGlzdEl0ZW1UZXh0O1xuXG4gICAgICAgICAgICBpZiAoMCA9PT0gY3VycmVudEl0ZW0ubGV2ZWwpIHtcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGUgY3VycmVudCBsaXN0IGl0ZW0gaXMgYSB0b3AgbGV2ZWwgaXRlbSwgZ2l2ZSBpdCB0aGUgZmlyc3QgbGV2ZWwgY2xhc3NcbiAgICAgICAgICAgICAgICBsaXN0SXRlbVRleHRDbGFzc2VzICs9ICcgJyArIHNldHRpbmdzLmNsYXNzZXMuZmlyc3RMZXZlbExpc3RJdGVtO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobGV2ZWwgPiBjdXJyZW50SXRlbS5sZXZlbCkge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobGV2ZWwgPT09IGN1cnJlbnRJdGVtLmxldmVsKSB7XG4gICAgICAgICAgICAgICAgaHRtbCArPSBcIjxsaSBjbGFzcz1cXFwiXCIuY29uY2F0KHNldHRpbmdzLmNsYXNzZXMubGlzdEl0ZW0sIFwiXFxcIj5cIik7XG4gICAgICAgICAgICAgICAgaHRtbCArPSBcIjxkaXYgY2xhc3M9XFxcIlwiLmNvbmNhdChzZXR0aW5ncy5jbGFzc2VzLmxpc3RUZXh0V3JhcHBlciwgXCJcXFwiPlwiKTtcbiAgICAgICAgICAgICAgICBpZiAoZWxlbWVudFNldHRpbmdzLmR1cGxpY2F0ZV9hbmNob3JfZml4ID09ICd5ZXMnKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbmNob3JUZXh0ID0gY3VycmVudEl0ZW0udGV4dC5yZXBsYWNlKC9cXHMrL2csICctJykucmVwbGFjZSgvW15cXHctXSsvZywgJycpLnRvTG93ZXJDYXNlKCkgKyAnLScgKyB0aGlzLmxpc3RJdGVtUG9pbnRlcjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYW5jaG9yVGV4dCA9IGN1cnJlbnRJdGVtLnRleHQucmVwbGFjZSgvXFxzKy9nLCAnLScpLnJlcGxhY2UoL1teXFx3LV0rL2csICcnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBsaUNvbnRlbnQgPSBcIjxhIGhyZWY9XFxcIiNcIi5jb25jYXQoYW5jaG9yVGV4dCwgXCJcXFwiIGNsYXNzPVxcXCJcIikuY29uY2F0KGxpc3RJdGVtVGV4dENsYXNzZXMsIFwiXFxcIj5cIikuY29uY2F0KGN1cnJlbnRJdGVtLnRleHQsIFwiPC9hPlwiKTsgLy8gSWYgbGlzdCB0eXBlIGlzIGJ1bGxldHMsIGFkZCB0aGUgYnVsbGV0IGljb24gYXMgYW4gPGk+IHRhZ1xuXG4gICAgICAgICAgICAgICAgaWYgKCdidWxsZXRzJyA9PT0gZWxlbWVudFNldHRpbmdzLm1hcmtlcl92aWV3ICYmIGljb24pIHtcbiAgICAgICAgICAgICAgICAgICAgbGlDb250ZW50ID0gXCI8aSBjbGFzcz1cXFwiXCIuY29uY2F0KGljb24udmFsdWUsIFwiXFxcIj48L2k+XCIpLmNvbmNhdChsaUNvbnRlbnQpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGh0bWwgKz0gbGlDb250ZW50O1xuICAgICAgICAgICAgICAgIGh0bWwgKz0gJzwvZGl2Pic7XG4gICAgICAgICAgICAgICAgdGhpcy5saXN0SXRlbVBvaW50ZXIrKztcbiAgICAgICAgICAgICAgICB2YXIgbmV4dEl0ZW0gPSB0aGlzLmhlYWRpbmdzRGF0YVt0aGlzLmxpc3RJdGVtUG9pbnRlcl07XG5cbiAgICAgICAgICAgICAgICBpZiAobmV4dEl0ZW0gJiYgbGV2ZWwgPCBuZXh0SXRlbS5sZXZlbCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiBhIG5ldyBuZXN0ZWQgbGlzdCBoYXMgdG8gYmUgY3JlYXRlZCB1bmRlciB0aGUgY3VycmVudCBpdGVtLFxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIGVudGlyZSBtZXRob2QgaXMgY2FsbGVkIHJlY3Vyc2l2ZWx5IChvdXRzaWRlIHRoZSB3aGlsZSBsb29wLCBhIGxpc3Qgd3JhcHBlciBpcyBjcmVhdGVkKVxuICAgICAgICAgICAgICAgICAgICBodG1sICs9IHRoaXMuZ2V0TmVzdGVkVG9jTGV2ZWwobmV4dEl0ZW0ubGV2ZWwpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGh0bWwgKz0gJzwvbGk+JztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGh0bWwgKz0gXCI8L1wiLmNvbmNhdChzZXR0aW5ncy5saXN0V3JhcHBlclRhZywgXCI+XCIpO1xuICAgICAgICByZXR1cm4gaHRtbDtcbiAgICB9XG4gICAgaGFuZGxlTm9IZWFkaW5nc0ZvdW5kKCkge1xuICAgICAgICB2YXIgbm9IZWFkaW5nc1RleHQgPSBlbGVtZW50b3JQcm9Gcm9udGVuZC5jb25maWcuaTE4blsndG9jX25vX2hlYWRpbmdzX2ZvdW5kJ107XG5cbiAgICAgICAgaWYgKGVsZW1lbnRvckZyb250ZW5kLmlzRWRpdE1vZGUoKSkge1xuICAgICAgICAgICAgbm9IZWFkaW5nc1RleHQgPSBlbGVtZW50b3JQcm8udHJhbnNsYXRlKCd0b2Nfbm9faGVhZGluZ3NfZm91bmQnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLmVsZW1lbnRzLiR0b2NCb2R5Lmh0bWwobm9IZWFkaW5nc1RleHQpO1xuICAgIH1cbiAgICBjb2xsYXBzZU9uSW5pdCgpIHtcbiAgICAgICAgdmFyIG1pbmltaXplZE9uID0gdGhpcy5nZXRFbGVtZW50U2V0dGluZ3MoJ21pbmltaXplZF9vbicpLFxuICAgICAgICAgICAgY3VycmVudERldmljZU1vZGUgPSBlbGVtZW50b3JGcm9udGVuZC5nZXRDdXJyZW50RGV2aWNlTW9kZSgpO1xuXG4gICAgICAgIGlmICgndGFibGV0JyA9PT0gbWluaW1pemVkT24gJiYgJ2Rlc2t0b3AnICE9PSBjdXJyZW50RGV2aWNlTW9kZSB8fCAnbW9iaWxlJyA9PT0gbWluaW1pemVkT24gJiYgJ21vYmlsZScgPT09IGN1cnJlbnREZXZpY2VNb2RlKSB7XG4gICAgICAgICAgICB0aGlzLmNvbGxhcHNlVG9jQm94KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0SGVhZGluZ3NEYXRhKCkge1xuICAgICAgICB2YXIgX3RoaXM1ID0gdGhpcztcblxuICAgICAgICB0aGlzLmhlYWRpbmdzRGF0YSA9IFtdOyAvLyBDcmVhdGUgYW4gYXJyYXkgZm9yIHNpbXBsaWZ5aW5nIFRPQyBsaXN0IGNyZWF0aW9uXG5cbiAgICAgICAgdGhpcy5lbGVtZW50cy4kaGVhZGluZ3MuZWFjaChmdW5jdGlvbihpbmRleCwgZWxlbWVudCkge1xuICAgICAgICAgICAgX3RoaXM1LmhlYWRpbmdzRGF0YS5wdXNoKHtcbiAgICAgICAgICAgICAgICB0YWc6ICtlbGVtZW50Lm5vZGVOYW1lLnNsaWNlKDEpLFxuICAgICAgICAgICAgICAgIHRleHQ6IGVsZW1lbnQudGV4dENvbnRlbnRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgcnVuKCkge1xuICAgICAgICB0aGlzLmVsZW1lbnRzLiRoZWFkaW5ncyA9IHRoaXMuZ2V0SGVhZGluZ3MoKTtcblxuICAgICAgICBpZiAoIXRoaXMuZWxlbWVudHMuJGhlYWRpbmdzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlTm9IZWFkaW5nc0ZvdW5kKCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnNldEhlYWRpbmdzRGF0YSgpO1xuXG4gICAgICAgIGlmICghZWxlbWVudG9yRnJvbnRlbmQuaXNFZGl0TW9kZSgpKSB7XG4gICAgICAgICAgICB0aGlzLmFkZEFuY2hvcnNCZWZvcmVIZWFkaW5ncygpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5wb3B1bGF0ZVRPQygpO1xuXG4gICAgICAgIGlmICh0aGlzLmdldEVsZW1lbnRTZXR0aW5ncygnbWluaW1pemVfYm94JykpIHtcbiAgICAgICAgICAgIHRoaXMuY29sbGFwc2VPbkluaXQoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBleHBhbmRUb2NCb3goKSB7XG4gICAgICAgIHZhciBib3hIZWlnaHQgPSB0aGlzLmdldEN1cnJlbnREZXZpY2VTZXR0aW5nKCdtaW5faGVpZ2h0Jyk7XG4gICAgICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3ModGhpcy5nZXRTZXR0aW5ncygnY2xhc3Nlcy5jb2xsYXBzZWQnKSk7XG4gICAgICAgIHRoaXMuZWxlbWVudHMuJHRvY0JvZHkuc2xpZGVEb3duKCk7IC8vIHJldHVybiBjb250YWluZXIgdG8gdGhlIGZ1bGwgaGVpZ2h0IGluIGNhc2UgYSBtaW4taGVpZ2h0IGlzIGRlZmluZWQgYnkgdGhlIHVzZXJcblxuICAgICAgICB0aGlzLmVsZW1lbnRzLiR3aWRnZXRUb2NDb250YWluZXIuY3NzKCdtaW4taGVpZ2h0JywgYm94SGVpZ2h0LnNpemUgKyBib3hIZWlnaHQudW5pdCk7XG4gICAgfVxuICAgIGNvbGxhcHNlVG9jQm94KCkge1xuICAgICAgICB0aGlzLiRlbGVtZW50LmFkZENsYXNzKHRoaXMuZ2V0U2V0dGluZ3MoJ2NsYXNzZXMuY29sbGFwc2VkJykpO1xuICAgICAgICB0aGlzLmVsZW1lbnRzLiR0b2NCb2R5LnNsaWRlVXAoKTsgLy8gY2xvc2UgY29udGFpbmVyIGluIGNhc2UgYSBtaW4taGVpZ2h0IGlzIGRlZmluZWQgYnkgdGhlIHVzZXJcblxuICAgICAgICB0aGlzLmVsZW1lbnRzLiR3aWRnZXRUb2NDb250YWluZXIuY3NzKCdtaW4taGVpZ2h0JywgJzBweCcpO1xuICAgIH1cblxuICAgIF9zdXBlclByb3BCYXNlKG9iamVjdCwgcHJvcGVydHkpIHtcbiAgICAgICAgd2hpbGUgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSkpIHtcbiAgICAgICAgICAgIG9iamVjdCA9IGdldFByb3RvdHlwZU9mKG9iamVjdCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0ID09PSBudWxsKSBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgfVxuICAgIF9nZXQzKHRhcmdldCwgcHJvcGVydHksIHJlY2VpdmVyKSB7XG4gICAgICAgIGlmICh0eXBlb2YgUmVmbGVjdCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBSZWZsZWN0LmdldCkge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcGVydHksIHJlY2VpdmVyIHx8IHRhcmdldCk7XG4gICAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IF9nZXQgPSBSZWZsZWN0LmdldDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBiYXNlID0gc3VwZXJQcm9wQmFzZSh0YXJnZXQsIHByb3BlcnR5KTtcbiAgICAgICAgICAgIGlmICghYmFzZSkgcmV0dXJuO1xuICAgICAgICAgICAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGJhc2UsIHByb3BlcnR5KTtcblxuICAgICAgICAgICAgaWYgKGRlc2MuZ2V0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlc2MuZ2V0LmNhbGwocmVjZWl2ZXIpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gZGVzYy52YWx1ZTtcblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIF9nZXQodGFyZ2V0LCBwcm9wZXJ0eSwgcmVjZWl2ZXIgfHwgdGFyZ2V0KTtcbiAgICB9XG5cblxufVxuXG5yZWdpc3RlcldpZGdldChPRVdfVE9DLCBcIm9ldy10b2NcIik7XG4iXX0=
