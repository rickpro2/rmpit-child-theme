(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _classPrivateFieldInitSpec(obj, privateMap, value) { _checkPrivateRedeclaration(obj, privateMap); privateMap.set(obj, value); }
function _checkPrivateRedeclaration(obj, privateCollection) { if (privateCollection.has(obj)) { throw new TypeError("Cannot initialize the same private elements twice on an object"); } }
function _classPrivateFieldGet(receiver, privateMap) { var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "get"); return _classApplyDescriptorGet(receiver, descriptor); }
function _classApplyDescriptorGet(receiver, descriptor) { if (descriptor.get) { return descriptor.get.call(receiver); } return descriptor.value; }
function _classPrivateFieldSet(receiver, privateMap, value) { var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "set"); _classApplyDescriptorSet(receiver, descriptor, value); return value; }
function _classExtractFieldDescriptor(receiver, privateMap, action) { if (!privateMap.has(receiver)) { throw new TypeError("attempted to " + action + " private field on non-instance"); } return privateMap.get(receiver); }
function _classApplyDescriptorSet(receiver, descriptor, value) { if (descriptor.set) { descriptor.set.call(receiver, value); } else { if (!descriptor.writable) { throw new TypeError("attempted to set read only private field"); } descriptor.value = value; } }
var _settings = /*#__PURE__*/new WeakMap();
var OW_Base = /*#__PURE__*/function () {
  function OW_Base() {
    _classCallCheck(this, OW_Base);
    _classPrivateFieldInitSpec(this, _settings, {
      writable: true,
      value: void 0
    });
    _defineProperty(this, "elements", void 0);
    this.onInit();
    this.bindEvents();
  }
  _createClass(OW_Base, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      return {};
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      return {};
    }
  }, {
    key: "onInit",
    value: function onInit() {
      _classPrivateFieldSet(this, _settings, this.getDefaultSettings());
      this.elements = this.getDefaultElements();
    }
  }, {
    key: "bindEvents",
    value: function bindEvents() {}
  }, {
    key: "getSettings",
    value: function getSettings() {
      var key = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      if (!!key) {
        return _classPrivateFieldGet(this, _settings)[key];
      }
      return _classPrivateFieldGet(this, _settings);
    }
  }, {
    key: "setSettings",
    value: function setSettings() {
      var settings = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      if (!settings) {
        return;
      }
      _classPrivateFieldSet(this, _settings, Object.assign(_classPrivateFieldGet(this, _settings), settings));
    }
  }]);
  return OW_Base;
}();
var _default = OW_Base;
exports["default"] = _default;

},{}],2:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
var _base = _interopRequireDefault(require("./base/base"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _get() { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get.bind(); } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return _get.apply(this, arguments); }
function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }
function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }
function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }
var OW_FullScreen = /*#__PURE__*/function (_OW_Base) {
  _inherits(OW_FullScreen, _OW_Base);
  var _super = _createSuper(OW_FullScreen);
  function OW_FullScreen() {
    _classCallCheck(this, OW_FullScreen);
    return _super.apply(this, arguments);
  }
  _createClass(OW_FullScreen, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      var elSectionsWrapper = "#oceanwp-fullpage .elementor-section-wrap",
        elSections = "#oceanwp-fullpage .elementor-section-wrap > .elementor-section",
        elTopSections = "#oceanwp-fullpage .elementor-top-section";
      if (elementorFrontend.config.experimentalFeatures.e_dom_optimization && !elementorFrontend.config.experimentalFeatures.container) {
        elSectionsWrapper = "#oceanwp-fullpage .elementor";
        elSections = "#oceanwp-fullpage .elementor > .elementor-section";
        elTopSections = "#oceanwp-fullpage .elementor-top-section";
      } else if (elementorFrontend.config.experimentalFeatures.container) {
        elSectionsWrapper = "#oceanwp-fullpage .elementor";
        elSections = "#oceanwp-fullpage .elementor > .elementor-element";
        elTopSections = "#oceanwp-fullpage .e-flex";
      }
      return {
        selectors: {
          sectionsWrapper: elSectionsWrapper,
          sections: elSections,
          topSections: elTopSections
        },
        options: oceanwpLocalize
      };
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      var selectors = this.getSettings("selectors");
      return {
        sectionsWrapper: document.querySelector(selectors.sectionsWrapper),
        sections: document.querySelectorAll(selectors.sections),
        topSections: document.querySelectorAll(selectors.topSections),
        body: document.body
      };
    }
  }, {
    key: "onInit",
    value: function onInit() {
      _get(_getPrototypeOf(OW_FullScreen.prototype), "onInit", this).call(this);
      if (this.isElementorEditorPage()) {
        return;
      }
      this.wrapSections();
      this.initFullPage();
    }
  }, {
    key: "wrapSections",
    value: function wrapSections() {
      var anchors = new Set();
      if (this.elements.sections) {
        this.elements.sections.forEach(function (section, index) {
          if (!section.id) {
            var sectionId = "fs-section-".concat(index);
            while (document.getElementById(sectionId) || anchors.has(sectionId)) {
              index++;
              sectionId = "fs-section-".concat(index);
            }
            section.id = sectionId;
          }
          anchors.add(section.id);
          var sectionWrapperId = "#".concat(section.id);
          section.removeAttribute("id");
          section.outerHTML = "<div id=\"".concat(sectionWrapperId, "\" class=\"wrap-section\" data-anchor=\"").concat(section.id, "\">").concat(section.outerHTML, "</div>");
        });
      }
    }
  }, {
    key: "initFullPage",
    value: function initFullPage() {
      var selectors = this.getSettings("selectors");
      new fullpage(selectors.sectionsWrapper, this.getFullPageOptions());
    }
  }, {
    key: "getFullPageOptions",
    value: function getFullPageOptions() {
      var self = this;
      var options = this.getSettings("options");
      var selectors = this.getSettings("selectors");
      var sections = document.querySelectorAll("".concat(selectors.sectionsWrapper, " > .wrap-section"));
      var fullPageOptions = {
        licenseKey: "2802F989-785845A8-B0E376B6-EA1BD751",
        sectionSelector: ".wrap-section",
        scrollOverflow: true,
        v2compatible: true,
        onLeave: function onLeave(index, nextIndex, direction) {
          var nextSection = sections[nextIndex - 1];
          if (direction === "down" || direction === "up") {
            self.setFullPageNavColor(nextSection);
          }
        },
        afterLoad: function afterLoad(anchorLink, index) {
          var nextSection = this;
          if (nextSection.classList.contains("active")) {
            self.setFullPageNavColor(nextSection);
            var sectionLoadedEvent = new Event('sectionLoaded');
            document.dispatchEvent(sectionLoadedEvent);
          }
        },
        anchors: [] // Reset the anchors array to ensure it's not causing issues
      };

      // Scrolling speed
      if (("0" != options.ofcSpeed || "700" != options.ofcSpeed) && "" != options.ofcSpeed) {
        fullPageOptions.scrollingSpeed = options.ofcSpeed;
      }

      // Responsive
      if ("0" != options.ofcRes && "" != options.ofcRes) {
        fullPageOptions.responsiveWidth = options.ofcRes;
      }

      // If navigation
      if ("enable" == options.ofcNav) {
        // Anchors and tooltips
        var anchors = [];
        var navTooltips = [];
        sections.forEach(function (topSection) {
          var sectionID = topSection.id.replace("#", "");
          if (sectionID) {
            anchors.push(sectionID);
            navTooltips.push(sectionID.replace(/[\-_]/g, " ")); // Replace hyphens with space in tooltips
          } else {
            anchors.push(" ");
            navTooltips.push(" ");
          }
        });

        // Add anchors and tooltips to fullPageOptions
        fullPageOptions.anchors = anchors;

        // Settings
        fullPageOptions.menu = "#fp-nav";
        fullPageOptions.navigation = true;
        fullPageOptions.navigationPosition = options.ofcNavPos;
        fullPageOptions.navigationTooltips = navTooltips;
      }
      return fullPageOptions;
    }
  }, {
    key: "setFullPageNavColor",
    value: function setFullPageNavColor(section) {
      var _iterator = _createForOfIteratorHelper(section.children),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var sectionChild = _step.value;
          this.elements.body.classList.remove("ofc-light-nav");
          this.elements.body.classList.remove("ofc-dark-nav");
          var children = sectionChild.children;
          var lightSection = Array.from(children).some(function (_ref) {
            var classList = _ref.classList;
            return classList.contains("elementor-top-section") && classList.contains("light");
          });
          if (lightSection) {
            this.elements.body.classList.add("ofc-light-nav");
            break;
          }
          var darkSection = Array.from(children).some(function (_ref2) {
            var classList = _ref2.classList;
            return classList.contains("elementor-top-section") && classList.contains("dark");
          });
          if (darkSection) {
            this.elements.body.classList.add("ofc-dark-nav");
            break;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, {
    key: "isElementorEditorPage",
    value: function isElementorEditorPage() {
      return this.elements.body.classList.contains("elementor-editor-active");
    }
  }]);
  return OW_FullScreen;
}(_base["default"]);
"use script";
window.addEventListener("DOMContentLoaded", function () {
  new OW_FullScreen();
});

},{"./base/base":1}]},{},[2])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJhc3NldHMvc3JjL2pzL2Jhc2UvYmFzZS5qcyIsImFzc2V0cy9zcmMvanMvZnVsbC1zY3JlZW4uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNBTSxPQUFPO0VBSVQsU0FBQSxRQUFBLEVBQWM7SUFBQSxlQUFBLE9BQUEsT0FBQTtJQUFBLDBCQUFBLE9BQUEsU0FBQTtNQUFBLFFBQUE7TUFBQSxLQUFBO0lBQUE7SUFBQSxlQUFBO0lBQ1YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQ3JCO0VBQUMsWUFBQSxDQUFBLE9BQUE7SUFBQSxHQUFBO0lBQUEsS0FBQSxFQUVELFNBQUEsbUJBQUEsRUFBcUI7TUFDakIsT0FBTyxDQUFDLENBQUM7SUFDYjtFQUFDO0lBQUEsR0FBQTtJQUFBLEtBQUEsRUFFRCxTQUFBLG1CQUFBLEVBQXFCO01BQ2pCLE9BQU8sQ0FBQyxDQUFDO0lBQ2I7RUFBQztJQUFBLEdBQUE7SUFBQSxLQUFBLEVBRUQsU0FBQSxPQUFBLEVBQVM7TUFDTCxxQkFBQSxLQUFJLEVBQUEsU0FBQSxFQUFhLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO01BQzFDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDN0M7RUFBQztJQUFBLEdBQUE7SUFBQSxLQUFBLEVBRUQsU0FBQSxXQUFBLEVBQWEsQ0FBQztFQUFDO0lBQUEsR0FBQTtJQUFBLEtBQUEsRUFFZixTQUFBLFlBQUEsRUFBd0I7TUFBQSxJQUFaLEdBQUcsR0FBQSxTQUFBLENBQUEsTUFBQSxRQUFBLFNBQUEsUUFBQSxTQUFBLEdBQUEsU0FBQSxNQUFHLElBQUk7TUFDbEIsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1FBQ1AsT0FBTyxxQkFBQSxLQUFJLEVBQUEsU0FBQSxFQUFXLEdBQUcsQ0FBQztNQUM5QjtNQUVBLE9BQUEscUJBQUEsQ0FBTyxJQUFJLEVBQUEsU0FBQTtJQUNmO0VBQUM7SUFBQSxHQUFBO0lBQUEsS0FBQSxFQUVELFNBQUEsWUFBQSxFQUEyQjtNQUFBLElBQWYsUUFBUSxHQUFBLFNBQUEsQ0FBQSxNQUFBLFFBQUEsU0FBQSxRQUFBLFNBQUEsR0FBQSxTQUFBLE1BQUcsQ0FBQyxDQUFDO01BQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUU7UUFDWDtNQUNKO01BRUEscUJBQUEsS0FBSSxFQUFBLFNBQUEsRUFBYSxNQUFNLENBQUMsTUFBTSxDQUFBLHFCQUFBLENBQUMsSUFBSSxFQUFBLFNBQUEsR0FBWSxRQUFRLENBQUM7SUFDNUQ7RUFBQztFQUFBLE9BQUEsT0FBQTtBQUFBO0FBQUEsSUFBQSxRQUFBLEdBR1UsT0FBTztBQUFBLE9BQUEsY0FBQSxRQUFBOzs7Ozs7QUN6Q3RCLElBQUEsS0FBQSxHQUFBLHNCQUFBLENBQUEsT0FBQTtBQUFrQyxTQUFBLHVCQUFBLEdBQUEsV0FBQSxHQUFBLElBQUEsR0FBQSxDQUFBLFVBQUEsR0FBQSxHQUFBLGdCQUFBLEdBQUE7QUFBQSxTQUFBLDJCQUFBLENBQUEsRUFBQSxjQUFBLFFBQUEsRUFBQSxVQUFBLE1BQUEsb0JBQUEsQ0FBQSxDQUFBLE1BQUEsQ0FBQSxRQUFBLEtBQUEsQ0FBQSxxQkFBQSxFQUFBLFFBQUEsS0FBQSxDQUFBLE9BQUEsQ0FBQSxDQUFBLE1BQUEsRUFBQSxHQUFBLDJCQUFBLENBQUEsQ0FBQSxNQUFBLGNBQUEsSUFBQSxDQUFBLFdBQUEsQ0FBQSxDQUFBLE1BQUEscUJBQUEsRUFBQSxFQUFBLENBQUEsR0FBQSxFQUFBLE1BQUEsQ0FBQSxVQUFBLENBQUEsWUFBQSxFQUFBLGVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLFdBQUEsRUFBQSxRQUFBLENBQUEsSUFBQSxDQUFBLENBQUEsTUFBQSxXQUFBLElBQUEsbUJBQUEsSUFBQSxTQUFBLEtBQUEsRUFBQSxDQUFBLENBQUEsQ0FBQSxVQUFBLENBQUEsV0FBQSxFQUFBLEVBQUEsVUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsZ0JBQUEsU0FBQSxpSkFBQSxnQkFBQSxTQUFBLE1BQUEsVUFBQSxHQUFBLFdBQUEsQ0FBQSxXQUFBLEVBQUEsSUFBQSxFQUFBLEdBQUEsRUFBQSxDQUFBLElBQUEsQ0FBQSxDQUFBLE1BQUEsQ0FBQSxXQUFBLEVBQUEsUUFBQSxJQUFBLEdBQUEsRUFBQSxDQUFBLElBQUEsSUFBQSxnQkFBQSxHQUFBLElBQUEsQ0FBQSxJQUFBLFNBQUEsSUFBQSxLQUFBLENBQUEsV0FBQSxFQUFBLEdBQUEsSUFBQSxNQUFBLFNBQUEsR0FBQSxHQUFBLEdBQUEsS0FBQSxDQUFBLFdBQUEsRUFBQSxlQUFBLGdCQUFBLElBQUEsRUFBQSxvQkFBQSxFQUFBLDhCQUFBLE1BQUEsUUFBQSxHQUFBO0FBQUEsU0FBQSw0QkFBQSxDQUFBLEVBQUEsTUFBQSxTQUFBLENBQUEscUJBQUEsQ0FBQSxzQkFBQSxpQkFBQSxDQUFBLENBQUEsRUFBQSxNQUFBLE9BQUEsQ0FBQSxHQUFBLE1BQUEsQ0FBQSxTQUFBLENBQUEsUUFBQSxDQUFBLElBQUEsQ0FBQSxDQUFBLEVBQUEsS0FBQSxhQUFBLENBQUEsaUJBQUEsQ0FBQSxDQUFBLFdBQUEsRUFBQSxDQUFBLEdBQUEsQ0FBQSxDQUFBLFdBQUEsQ0FBQSxJQUFBLE1BQUEsQ0FBQSxjQUFBLENBQUEsbUJBQUEsS0FBQSxDQUFBLElBQUEsQ0FBQSxDQUFBLE9BQUEsQ0FBQSwrREFBQSxJQUFBLENBQUEsQ0FBQSxVQUFBLGlCQUFBLENBQUEsQ0FBQSxFQUFBLE1BQUE7QUFBQSxTQUFBLGtCQUFBLEdBQUEsRUFBQSxHQUFBLFFBQUEsR0FBQSxZQUFBLEdBQUEsR0FBQSxHQUFBLENBQUEsTUFBQSxFQUFBLEdBQUEsR0FBQSxHQUFBLENBQUEsTUFBQSxXQUFBLENBQUEsTUFBQSxJQUFBLE9BQUEsS0FBQSxDQUFBLEdBQUEsR0FBQSxDQUFBLEdBQUEsR0FBQSxFQUFBLENBQUEsSUFBQSxJQUFBLENBQUEsQ0FBQSxJQUFBLEdBQUEsQ0FBQSxDQUFBLFVBQUEsSUFBQTtBQUFBLFNBQUEsZ0JBQUEsUUFBQSxFQUFBLFdBQUEsVUFBQSxRQUFBLFlBQUEsV0FBQSxlQUFBLFNBQUE7QUFBQSxTQUFBLGtCQUFBLE1BQUEsRUFBQSxLQUFBLGFBQUEsQ0FBQSxNQUFBLENBQUEsR0FBQSxLQUFBLENBQUEsTUFBQSxFQUFBLENBQUEsVUFBQSxVQUFBLEdBQUEsS0FBQSxDQUFBLENBQUEsR0FBQSxVQUFBLENBQUEsVUFBQSxHQUFBLFVBQUEsQ0FBQSxVQUFBLFdBQUEsVUFBQSxDQUFBLFlBQUEsd0JBQUEsVUFBQSxFQUFBLFVBQUEsQ0FBQSxRQUFBLFNBQUEsTUFBQSxDQUFBLGNBQUEsQ0FBQSxNQUFBLEVBQUEsY0FBQSxDQUFBLFVBQUEsQ0FBQSxHQUFBLEdBQUEsVUFBQTtBQUFBLFNBQUEsYUFBQSxXQUFBLEVBQUEsVUFBQSxFQUFBLFdBQUEsUUFBQSxVQUFBLEVBQUEsaUJBQUEsQ0FBQSxXQUFBLENBQUEsU0FBQSxFQUFBLFVBQUEsT0FBQSxXQUFBLEVBQUEsaUJBQUEsQ0FBQSxXQUFBLEVBQUEsV0FBQSxHQUFBLE1BQUEsQ0FBQSxjQUFBLENBQUEsV0FBQSxpQkFBQSxRQUFBLG1CQUFBLFdBQUE7QUFBQSxTQUFBLGVBQUEsR0FBQSxRQUFBLEdBQUEsR0FBQSxZQUFBLENBQUEsR0FBQSxvQkFBQSxPQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLEdBQUEsTUFBQSxDQUFBLEdBQUE7QUFBQSxTQUFBLGFBQUEsS0FBQSxFQUFBLElBQUEsUUFBQSxPQUFBLENBQUEsS0FBQSxrQkFBQSxLQUFBLGtCQUFBLEtBQUEsTUFBQSxJQUFBLEdBQUEsS0FBQSxDQUFBLE1BQUEsQ0FBQSxXQUFBLE9BQUEsSUFBQSxLQUFBLFNBQUEsUUFBQSxHQUFBLEdBQUEsSUFBQSxDQUFBLElBQUEsQ0FBQSxLQUFBLEVBQUEsSUFBQSxvQkFBQSxPQUFBLENBQUEsR0FBQSx1QkFBQSxHQUFBLFlBQUEsU0FBQSw0REFBQSxJQUFBLGdCQUFBLE1BQUEsR0FBQSxNQUFBLEVBQUEsS0FBQTtBQUFBLFNBQUEsS0FBQSxlQUFBLE9BQUEsb0JBQUEsT0FBQSxDQUFBLEdBQUEsSUFBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsQ0FBQSxJQUFBLGFBQUEsSUFBQSxZQUFBLEtBQUEsTUFBQSxFQUFBLFFBQUEsRUFBQSxRQUFBLFFBQUEsSUFBQSxHQUFBLGNBQUEsQ0FBQSxNQUFBLEVBQUEsUUFBQSxRQUFBLElBQUEsY0FBQSxJQUFBLEdBQUEsTUFBQSxDQUFBLHdCQUFBLENBQUEsSUFBQSxFQUFBLFFBQUEsT0FBQSxJQUFBLENBQUEsR0FBQSxXQUFBLElBQUEsQ0FBQSxHQUFBLENBQUEsSUFBQSxDQUFBLFNBQUEsQ0FBQSxNQUFBLE9BQUEsTUFBQSxHQUFBLFFBQUEsWUFBQSxJQUFBLENBQUEsS0FBQSxjQUFBLElBQUEsQ0FBQSxLQUFBLE9BQUEsU0FBQTtBQUFBLFNBQUEsZUFBQSxNQUFBLEVBQUEsUUFBQSxZQUFBLE1BQUEsQ0FBQSxTQUFBLENBQUEsY0FBQSxDQUFBLElBQUEsQ0FBQSxNQUFBLEVBQUEsUUFBQSxLQUFBLE1BQUEsR0FBQSxlQUFBLENBQUEsTUFBQSxPQUFBLE1BQUEsMkJBQUEsTUFBQTtBQUFBLFNBQUEsVUFBQSxRQUFBLEVBQUEsVUFBQSxlQUFBLFVBQUEsbUJBQUEsVUFBQSx1QkFBQSxTQUFBLDBEQUFBLFFBQUEsQ0FBQSxTQUFBLEdBQUEsTUFBQSxDQUFBLE1BQUEsQ0FBQSxVQUFBLElBQUEsVUFBQSxDQUFBLFNBQUEsSUFBQSxXQUFBLElBQUEsS0FBQSxFQUFBLFFBQUEsRUFBQSxRQUFBLFFBQUEsWUFBQSxhQUFBLE1BQUEsQ0FBQSxjQUFBLENBQUEsUUFBQSxpQkFBQSxRQUFBLGdCQUFBLFVBQUEsRUFBQSxlQUFBLENBQUEsUUFBQSxFQUFBLFVBQUE7QUFBQSxTQUFBLGdCQUFBLENBQUEsRUFBQSxDQUFBLElBQUEsZUFBQSxHQUFBLE1BQUEsQ0FBQSxjQUFBLEdBQUEsTUFBQSxDQUFBLGNBQUEsQ0FBQSxJQUFBLGNBQUEsZ0JBQUEsQ0FBQSxFQUFBLENBQUEsSUFBQSxDQUFBLENBQUEsU0FBQSxHQUFBLENBQUEsU0FBQSxDQUFBLFlBQUEsZUFBQSxDQUFBLENBQUEsRUFBQSxDQUFBO0FBQUEsU0FBQSxhQUFBLE9BQUEsUUFBQSx5QkFBQSxHQUFBLHlCQUFBLG9CQUFBLHFCQUFBLFFBQUEsS0FBQSxHQUFBLGVBQUEsQ0FBQSxPQUFBLEdBQUEsTUFBQSxNQUFBLHlCQUFBLFFBQUEsU0FBQSxHQUFBLGVBQUEsT0FBQSxXQUFBLEVBQUEsTUFBQSxHQUFBLE9BQUEsQ0FBQSxTQUFBLENBQUEsS0FBQSxFQUFBLFNBQUEsRUFBQSxTQUFBLFlBQUEsTUFBQSxHQUFBLEtBQUEsQ0FBQSxLQUFBLE9BQUEsU0FBQSxZQUFBLDBCQUFBLE9BQUEsTUFBQTtBQUFBLFNBQUEsMkJBQUEsSUFBQSxFQUFBLElBQUEsUUFBQSxJQUFBLEtBQUEsT0FBQSxDQUFBLElBQUEseUJBQUEsSUFBQSwyQkFBQSxJQUFBLGFBQUEsSUFBQSx5QkFBQSxTQUFBLHVFQUFBLHNCQUFBLENBQUEsSUFBQTtBQUFBLFNBQUEsdUJBQUEsSUFBQSxRQUFBLElBQUEseUJBQUEsY0FBQSx3RUFBQSxJQUFBO0FBQUEsU0FBQSwwQkFBQSxlQUFBLE9BQUEscUJBQUEsT0FBQSxDQUFBLFNBQUEsb0JBQUEsT0FBQSxDQUFBLFNBQUEsQ0FBQSxJQUFBLDJCQUFBLEtBQUEsb0NBQUEsT0FBQSxDQUFBLFNBQUEsQ0FBQSxPQUFBLENBQUEsSUFBQSxDQUFBLE9BQUEsQ0FBQSxTQUFBLENBQUEsT0FBQSw4Q0FBQSxDQUFBO0FBQUEsU0FBQSxnQkFBQSxDQUFBLElBQUEsZUFBQSxHQUFBLE1BQUEsQ0FBQSxjQUFBLEdBQUEsTUFBQSxDQUFBLGNBQUEsQ0FBQSxJQUFBLGNBQUEsZ0JBQUEsQ0FBQSxXQUFBLENBQUEsQ0FBQSxTQUFBLElBQUEsTUFBQSxDQUFBLGNBQUEsQ0FBQSxDQUFBLGFBQUEsZUFBQSxDQUFBLENBQUE7QUFBQSxJQUU1QixhQUFhLDBCQUFBLFFBQUE7RUFBQSxTQUFBLENBQUEsYUFBQSxFQUFBLFFBQUE7RUFBQSxJQUFBLE1BQUEsR0FBQSxZQUFBLENBQUEsYUFBQTtFQUFBLFNBQUEsY0FBQTtJQUFBLGVBQUEsT0FBQSxhQUFBO0lBQUEsT0FBQSxNQUFBLENBQUEsS0FBQSxPQUFBLFNBQUE7RUFBQTtFQUFBLFlBQUEsQ0FBQSxhQUFBO0lBQUEsR0FBQTtJQUFBLEtBQUEsRUFFakIsU0FBQSxtQkFBQSxFQUFxQjtNQUVuQixJQUFJLGlCQUFpQixHQUFHLDJDQUEyQztRQUMvRCxVQUFVLEdBQUcsZ0VBQWdFO1FBQzdFLGFBQWEsR0FBRywwQ0FBMEM7TUFFOUQsSUFBSyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLElBQUksQ0FBRSxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFHO1FBQ25JLGlCQUFpQixHQUFHLDhCQUE4QjtRQUNsRCxVQUFVLEdBQUcsbURBQW1EO1FBQ2hFLGFBQWEsR0FBRywwQ0FBMEM7TUFDNUQsQ0FBQyxNQUFNLElBQUssaUJBQWlCLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFBRztRQUNwRSxpQkFBaUIsR0FBRyw4QkFBOEI7UUFDbEQsVUFBVSxHQUFHLG1EQUFtRDtRQUNoRSxhQUFhLEdBQUcsMkJBQTJCO01BQzdDO01BRUEsT0FBTztRQUNMLFNBQVMsRUFBRTtVQUNULGVBQWUsRUFBRSxpQkFBaUI7VUFDbEMsUUFBUSxFQUFFLFVBQVU7VUFDcEIsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNELE9BQU8sRUFBRTtNQUNYLENBQUM7SUFDSDtFQUFDO0lBQUEsR0FBQTtJQUFBLEtBQUEsRUFFRCxTQUFBLG1CQUFBLEVBQXFCO01BQ25CLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDO01BRS9DLE9BQU87UUFDTCxlQUFlLEVBQUUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDO1FBQ2xFLFFBQVEsRUFBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUN2RCxXQUFXLEVBQUUsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7UUFDN0QsSUFBSSxFQUFFLFFBQVEsQ0FBQztNQUNqQixDQUFDO0lBQ0g7RUFBQztJQUFBLEdBQUE7SUFBQSxLQUFBLEVBRUQsU0FBQSxPQUFBLEVBQVM7TUFDUCxJQUFBLENBQUEsZUFBQSxDQUFBLGFBQUEsQ0FBQSxTQUFBLG1CQUFBLElBQUE7TUFFQSxJQUFJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEVBQUU7UUFDaEM7TUFDRjtNQUVBLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztNQUNuQixJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDckI7RUFBQztJQUFBLEdBQUE7SUFBQSxLQUFBLEVBRUQsU0FBQSxhQUFBLEVBQWU7TUFDYixJQUFNLE9BQU8sR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUFDO01BQ3pCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7UUFDeEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLEtBQUssRUFBSztVQUMvQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRTtZQUNiLElBQUksU0FBUyxpQkFBQSxNQUFBLENBQWlCLEtBQUssQ0FBRTtZQUNyQyxPQUFPLFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRTtjQUNqRSxLQUFLLEVBQUU7Y0FDUCxTQUFTLGlCQUFBLE1BQUEsQ0FBaUIsS0FBSyxDQUFFO1lBQ3JDO1lBQ0EsT0FBTyxDQUFDLEVBQUUsR0FBRyxTQUFTO1VBQzFCO1VBQ0EsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1VBQ3ZCLElBQU0sZ0JBQWdCLE9BQUEsTUFBQSxDQUFPLE9BQU8sQ0FBQyxFQUFFLENBQUU7VUFDekMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUM7VUFDN0IsT0FBTyxDQUFDLFNBQVMsZ0JBQUEsTUFBQSxDQUFlLGdCQUFnQiw4Q0FBQSxNQUFBLENBQXVDLE9BQU8sQ0FBQyxFQUFFLFNBQUEsTUFBQSxDQUFLLE9BQU8sQ0FBQyxTQUFTLFdBQVE7UUFDbkksQ0FBQyxDQUFDO01BQ047SUFDRjtFQUFDO0lBQUEsR0FBQTtJQUFBLEtBQUEsRUFFRCxTQUFBLGFBQUEsRUFBZTtNQUNiLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDO01BRS9DLElBQUksUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztJQUNwRTtFQUFDO0lBQUEsR0FBQTtJQUFBLEtBQUEsRUFFRCxTQUFBLG1CQUFBLEVBQXFCO01BQ25CLElBQU0sSUFBSSxHQUFHLElBQUk7TUFDakIsSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUM7TUFDM0MsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUM7TUFDL0MsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixJQUFBLE1BQUEsQ0FDckMsU0FBUyxDQUFDLGVBQWUscUJBQzlCLENBQUM7TUFFRCxJQUFNLGVBQWUsR0FBRztRQUN0QixVQUFVLEVBQUUscUNBQXFDO1FBQ2pELGVBQWUsRUFBRSxlQUFlO1FBQ2hDLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLFlBQVksRUFBRSxJQUFJO1FBQ2xCLE9BQU8sRUFBRSxTQUFBLFFBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUs7VUFDeEMsSUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7VUFFM0MsSUFBSSxTQUFTLEtBQUssTUFBTSxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDOUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQztVQUN2QztRQUNGLENBQUM7UUFDRCxTQUFTLEVBQUUsU0FBQSxVQUFVLFVBQVUsRUFBRSxLQUFLLEVBQUU7VUFDdEMsSUFBTSxXQUFXLEdBQUcsSUFBSTtVQUV4QixJQUFJLFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzVDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUM7WUFFckMsSUFBTSxrQkFBa0IsR0FBRyxJQUFJLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDckQsUUFBUSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQztVQUM1QztRQUNGLENBQUM7UUFDRCxPQUFPLEVBQUUsRUFBRSxDQUFFO01BQ2YsQ0FBQzs7TUFFRDtNQUNBLElBQ0UsQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDLFFBQVEsSUFBSSxLQUFLLElBQUksT0FBTyxDQUFDLFFBQVEsS0FDckQsRUFBRSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEVBQ3RCO1FBQ0EsZUFBZSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsUUFBUTtNQUNuRDs7TUFFQTtNQUNBLElBQUksR0FBRyxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksRUFBRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7UUFDakQsZUFBZSxDQUFDLGVBQWUsR0FBRyxPQUFPLENBQUMsTUFBTTtNQUNsRDs7TUFFQTtNQUNBLElBQUksUUFBUSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7UUFDOUI7UUFDQSxJQUFNLE9BQU8sR0FBRyxFQUFFO1FBQ2xCLElBQU0sV0FBVyxHQUFHLEVBQUU7UUFFdEIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFBLFVBQVUsRUFBSTtVQUM3QixJQUFJLFNBQVMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO1VBRTlDLElBQUksU0FBUyxFQUFFO1lBQ2IsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7WUFDdkIsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFDdEQsQ0FBQyxNQUFNO1lBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDakIsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7VUFDdkI7UUFDRixDQUFDLENBQUM7O1FBRUY7UUFDQSxlQUFlLENBQUMsT0FBTyxHQUFHLE9BQU87O1FBRWpDO1FBQ0EsZUFBZSxDQUFDLElBQUksR0FBRyxTQUFTO1FBQ2hDLGVBQWUsQ0FBQyxVQUFVLEdBQUcsSUFBSTtRQUNqQyxlQUFlLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLFNBQVM7UUFDdEQsZUFBZSxDQUFDLGtCQUFrQixHQUFHLFdBQVc7TUFDbEQ7TUFFQSxPQUFPLGVBQWU7SUFDeEI7RUFBQztJQUFBLEdBQUE7SUFBQSxLQUFBLEVBRUQsU0FBQSxvQkFBb0IsT0FBTyxFQUFFO01BQUEsSUFBQSxTQUFBLEdBQUEsMEJBQUEsQ0FDQSxPQUFPLENBQUMsUUFBUTtRQUFBLEtBQUE7TUFBQTtRQUEzQyxLQUFBLFNBQUEsQ0FBQSxDQUFBLE1BQUEsS0FBQSxHQUFBLFNBQUEsQ0FBQSxDQUFBLElBQUEsSUFBQSxHQUE2QztVQUFBLElBQWxDLFlBQVksR0FBQSxLQUFBLENBQUEsS0FBQTtVQUNyQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQztVQUNwRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQztVQUVuRCxJQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsUUFBUTtVQUV0QyxJQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FDNUMsVUFBQSxJQUFBO1lBQUEsSUFBRyxTQUFTLEdBQUEsSUFBQSxDQUFULFNBQVM7WUFBQSxPQUNWLFNBQVMsQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsSUFDM0MsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFBQSxDQUMvQixDQUFDO1VBRUQsSUFBSSxZQUFZLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7WUFDakQ7VUFDRjtVQUVBLElBQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUMzQyxVQUFBLEtBQUE7WUFBQSxJQUFHLFNBQVMsR0FBQSxLQUFBLENBQVQsU0FBUztZQUFBLE9BQ1YsU0FBUyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxJQUMzQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztVQUFBLENBQzlCLENBQUM7VUFFRCxJQUFJLFdBQVcsRUFBRTtZQUNmLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1lBQ2hEO1VBQ0Y7UUFDRjtNQUFDLFNBQUEsR0FBQTtRQUFBLFNBQUEsQ0FBQSxDQUFBLENBQUEsR0FBQTtNQUFBO1FBQUEsU0FBQSxDQUFBLENBQUE7TUFBQTtJQUNIO0VBQUM7SUFBQSxHQUFBO0lBQUEsS0FBQSxFQUVELFNBQUEsc0JBQUEsRUFBd0I7TUFDdEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDO0lBQ3pFO0VBQUM7RUFBQSxPQUFBLGFBQUE7QUFBQSxFQTFMeUIsZ0JBQU87QUE2TGxDLFlBQVk7QUFDYixNQUFNLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUUsWUFBTTtFQUNoRCxJQUFJLGFBQWEsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uKCl7ZnVuY3Rpb24gcihlLG4sdCl7ZnVuY3Rpb24gbyhpLGYpe2lmKCFuW2ldKXtpZighZVtpXSl7dmFyIGM9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZTtpZighZiYmYylyZXR1cm4gYyhpLCEwKTtpZih1KXJldHVybiB1KGksITApO3ZhciBhPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIraStcIidcIik7dGhyb3cgYS5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGF9dmFyIHA9bltpXT17ZXhwb3J0czp7fX07ZVtpXVswXS5jYWxsKHAuZXhwb3J0cyxmdW5jdGlvbihyKXt2YXIgbj1lW2ldWzFdW3JdO3JldHVybiBvKG58fHIpfSxwLHAuZXhwb3J0cyxyLGUsbix0KX1yZXR1cm4gbltpXS5leHBvcnRzfWZvcih2YXIgdT1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlLGk9MDtpPHQubGVuZ3RoO2krKylvKHRbaV0pO3JldHVybiBvfXJldHVybiByfSkoKSIsImNsYXNzIE9XX0Jhc2Uge1xuICAgICNzZXR0aW5ncztcbiAgICBlbGVtZW50cztcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLm9uSW5pdCgpO1xuICAgICAgICB0aGlzLmJpbmRFdmVudHMoKTtcbiAgICB9XG5cbiAgICBnZXREZWZhdWx0U2V0dGluZ3MoKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG5cbiAgICBnZXREZWZhdWx0RWxlbWVudHMoKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG5cbiAgICBvbkluaXQoKSB7XG4gICAgICAgIHRoaXMuI3NldHRpbmdzID0gdGhpcy5nZXREZWZhdWx0U2V0dGluZ3MoKTtcbiAgICAgICAgdGhpcy5lbGVtZW50cyA9IHRoaXMuZ2V0RGVmYXVsdEVsZW1lbnRzKCk7XG4gICAgfVxuXG4gICAgYmluZEV2ZW50cygpIHt9XG5cbiAgICBnZXRTZXR0aW5ncyhrZXkgPSBudWxsKSB7XG4gICAgICAgIGlmICghIWtleSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuI3NldHRpbmdzW2tleV07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy4jc2V0dGluZ3M7XG4gICAgfVxuXG4gICAgc2V0U2V0dGluZ3Moc2V0dGluZ3MgPSB7fSkge1xuICAgICAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLiNzZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24odGhpcy4jc2V0dGluZ3MsIHNldHRpbmdzKTtcbiAgICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IE9XX0Jhc2U7XG4iLCJpbXBvcnQgT1dfQmFzZSBmcm9tIFwiLi9iYXNlL2Jhc2VcIjtcblxuY2xhc3MgT1dfRnVsbFNjcmVlbiBleHRlbmRzIE9XX0Jhc2Uge1xuXG4gIGdldERlZmF1bHRTZXR0aW5ncygpIHtcblxuICAgIGxldCBlbFNlY3Rpb25zV3JhcHBlciA9IFwiI29jZWFud3AtZnVsbHBhZ2UgLmVsZW1lbnRvci1zZWN0aW9uLXdyYXBcIixcbiAgICAgICAgZWxTZWN0aW9ucyA9IFwiI29jZWFud3AtZnVsbHBhZ2UgLmVsZW1lbnRvci1zZWN0aW9uLXdyYXAgPiAuZWxlbWVudG9yLXNlY3Rpb25cIixcbiAgICAgICAgZWxUb3BTZWN0aW9ucyA9IFwiI29jZWFud3AtZnVsbHBhZ2UgLmVsZW1lbnRvci10b3Atc2VjdGlvblwiO1xuXG4gICAgaWYgKCBlbGVtZW50b3JGcm9udGVuZC5jb25maWcuZXhwZXJpbWVudGFsRmVhdHVyZXMuZV9kb21fb3B0aW1pemF0aW9uICYmICEgZWxlbWVudG9yRnJvbnRlbmQuY29uZmlnLmV4cGVyaW1lbnRhbEZlYXR1cmVzLmNvbnRhaW5lciApIHtcbiAgICAgIGVsU2VjdGlvbnNXcmFwcGVyID0gXCIjb2NlYW53cC1mdWxscGFnZSAuZWxlbWVudG9yXCJcbiAgICAgIGVsU2VjdGlvbnMgPSBcIiNvY2VhbndwLWZ1bGxwYWdlIC5lbGVtZW50b3IgPiAuZWxlbWVudG9yLXNlY3Rpb25cIlxuICAgICAgZWxUb3BTZWN0aW9ucyA9IFwiI29jZWFud3AtZnVsbHBhZ2UgLmVsZW1lbnRvci10b3Atc2VjdGlvblwiXG4gICAgfSBlbHNlIGlmICggZWxlbWVudG9yRnJvbnRlbmQuY29uZmlnLmV4cGVyaW1lbnRhbEZlYXR1cmVzLmNvbnRhaW5lciApIHtcbiAgICAgIGVsU2VjdGlvbnNXcmFwcGVyID0gXCIjb2NlYW53cC1mdWxscGFnZSAuZWxlbWVudG9yXCJcbiAgICAgIGVsU2VjdGlvbnMgPSBcIiNvY2VhbndwLWZ1bGxwYWdlIC5lbGVtZW50b3IgPiAuZWxlbWVudG9yLWVsZW1lbnRcIlxuICAgICAgZWxUb3BTZWN0aW9ucyA9IFwiI29jZWFud3AtZnVsbHBhZ2UgLmUtZmxleFwiXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHNlbGVjdG9yczoge1xuICAgICAgICBzZWN0aW9uc1dyYXBwZXI6IGVsU2VjdGlvbnNXcmFwcGVyLFxuICAgICAgICBzZWN0aW9uczogZWxTZWN0aW9ucyxcbiAgICAgICAgdG9wU2VjdGlvbnM6IGVsVG9wU2VjdGlvbnMsXG4gICAgICB9LFxuICAgICAgb3B0aW9uczogb2NlYW53cExvY2FsaXplLFxuICAgIH07XG4gIH1cblxuICBnZXREZWZhdWx0RWxlbWVudHMoKSB7XG4gICAgY29uc3Qgc2VsZWN0b3JzID0gdGhpcy5nZXRTZXR0aW5ncyhcInNlbGVjdG9yc1wiKTtcblxuICAgIHJldHVybiB7XG4gICAgICBzZWN0aW9uc1dyYXBwZXI6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3JzLnNlY3Rpb25zV3JhcHBlciksXG4gICAgICBzZWN0aW9uczogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcnMuc2VjdGlvbnMpLFxuICAgICAgdG9wU2VjdGlvbnM6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3JzLnRvcFNlY3Rpb25zKSxcbiAgICAgIGJvZHk6IGRvY3VtZW50LmJvZHksXG4gICAgfTtcbiAgfVxuXG4gIG9uSW5pdCgpIHtcbiAgICBzdXBlci5vbkluaXQoKTtcblxuICAgIGlmICh0aGlzLmlzRWxlbWVudG9yRWRpdG9yUGFnZSgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy53cmFwU2VjdGlvbnMoKTtcbiAgICB0aGlzLmluaXRGdWxsUGFnZSgpO1xuICB9XG5cbiAgd3JhcFNlY3Rpb25zKCkge1xuICAgIGNvbnN0IGFuY2hvcnMgPSBuZXcgU2V0KCk7XG4gICAgaWYgKHRoaXMuZWxlbWVudHMuc2VjdGlvbnMpIHtcbiAgICAgICAgdGhpcy5lbGVtZW50cy5zZWN0aW9ucy5mb3JFYWNoKChzZWN0aW9uLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFzZWN0aW9uLmlkKSB7XG4gICAgICAgICAgICAgICAgbGV0IHNlY3Rpb25JZCA9IGBmcy1zZWN0aW9uLSR7aW5kZXh9YDtcbiAgICAgICAgICAgICAgICB3aGlsZSAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoc2VjdGlvbklkKSB8fCBhbmNob3JzLmhhcyhzZWN0aW9uSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgIHNlY3Rpb25JZCA9IGBmcy1zZWN0aW9uLSR7aW5kZXh9YDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2VjdGlvbi5pZCA9IHNlY3Rpb25JZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFuY2hvcnMuYWRkKHNlY3Rpb24uaWQpO1xuICAgICAgICAgICAgY29uc3Qgc2VjdGlvbldyYXBwZXJJZCA9IGAjJHtzZWN0aW9uLmlkfWA7XG4gICAgICAgICAgICBzZWN0aW9uLnJlbW92ZUF0dHJpYnV0ZShcImlkXCIpO1xuICAgICAgICAgICAgc2VjdGlvbi5vdXRlckhUTUwgPSBgPGRpdiBpZD1cIiR7c2VjdGlvbldyYXBwZXJJZH1cIiBjbGFzcz1cIndyYXAtc2VjdGlvblwiIGRhdGEtYW5jaG9yPVwiJHtzZWN0aW9uLmlkfVwiPiR7c2VjdGlvbi5vdXRlckhUTUx9PC9kaXY+YDtcbiAgICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgaW5pdEZ1bGxQYWdlKCkge1xuICAgIGNvbnN0IHNlbGVjdG9ycyA9IHRoaXMuZ2V0U2V0dGluZ3MoXCJzZWxlY3RvcnNcIik7XG5cbiAgICBuZXcgZnVsbHBhZ2Uoc2VsZWN0b3JzLnNlY3Rpb25zV3JhcHBlciwgdGhpcy5nZXRGdWxsUGFnZU9wdGlvbnMoKSk7XG4gIH1cblxuICBnZXRGdWxsUGFnZU9wdGlvbnMoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMuZ2V0U2V0dGluZ3MoXCJvcHRpb25zXCIpO1xuICAgIGNvbnN0IHNlbGVjdG9ycyA9IHRoaXMuZ2V0U2V0dGluZ3MoXCJzZWxlY3RvcnNcIik7XG4gICAgY29uc3Qgc2VjdGlvbnMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgYCR7c2VsZWN0b3JzLnNlY3Rpb25zV3JhcHBlcn0gPiAud3JhcC1zZWN0aW9uYFxuICAgICk7XG5cbiAgICBjb25zdCBmdWxsUGFnZU9wdGlvbnMgPSB7XG4gICAgICBsaWNlbnNlS2V5OiBcIjI4MDJGOTg5LTc4NTg0NUE4LUIwRTM3NkI2LUVBMUJENzUxXCIsXG4gICAgICBzZWN0aW9uU2VsZWN0b3I6IFwiLndyYXAtc2VjdGlvblwiLFxuICAgICAgc2Nyb2xsT3ZlcmZsb3c6IHRydWUsXG4gICAgICB2MmNvbXBhdGlibGU6IHRydWUsXG4gICAgICBvbkxlYXZlOiAoaW5kZXgsIG5leHRJbmRleCwgZGlyZWN0aW9uKSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHRTZWN0aW9uID0gc2VjdGlvbnNbbmV4dEluZGV4IC0gMV07XG5cbiAgICAgICAgaWYgKGRpcmVjdGlvbiA9PT0gXCJkb3duXCIgfHwgZGlyZWN0aW9uID09PSBcInVwXCIpIHtcbiAgICAgICAgICBzZWxmLnNldEZ1bGxQYWdlTmF2Q29sb3IobmV4dFNlY3Rpb24pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgYWZ0ZXJMb2FkOiBmdW5jdGlvbiAoYW5jaG9yTGluaywgaW5kZXgpIHtcbiAgICAgICAgY29uc3QgbmV4dFNlY3Rpb24gPSB0aGlzO1xuXG4gICAgICAgIGlmIChuZXh0U2VjdGlvbi5jbGFzc0xpc3QuY29udGFpbnMoXCJhY3RpdmVcIikpIHtcbiAgICAgICAgICBzZWxmLnNldEZ1bGxQYWdlTmF2Q29sb3IobmV4dFNlY3Rpb24pO1xuXG4gICAgICAgICAgY29uc3Qgc2VjdGlvbkxvYWRlZEV2ZW50ID0gbmV3IEV2ZW50KCdzZWN0aW9uTG9hZGVkJyk7XG4gICAgICAgICAgZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChzZWN0aW9uTG9hZGVkRXZlbnQpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgYW5jaG9yczogW10sIC8vIFJlc2V0IHRoZSBhbmNob3JzIGFycmF5IHRvIGVuc3VyZSBpdCdzIG5vdCBjYXVzaW5nIGlzc3Vlc1xuICAgIH07XG5cbiAgICAvLyBTY3JvbGxpbmcgc3BlZWRcbiAgICBpZiAoXG4gICAgICAoXCIwXCIgIT0gb3B0aW9ucy5vZmNTcGVlZCB8fCBcIjcwMFwiICE9IG9wdGlvbnMub2ZjU3BlZWQpICYmXG4gICAgICBcIlwiICE9IG9wdGlvbnMub2ZjU3BlZWRcbiAgICApIHtcbiAgICAgIGZ1bGxQYWdlT3B0aW9ucy5zY3JvbGxpbmdTcGVlZCA9IG9wdGlvbnMub2ZjU3BlZWQ7XG4gICAgfVxuXG4gICAgLy8gUmVzcG9uc2l2ZVxuICAgIGlmIChcIjBcIiAhPSBvcHRpb25zLm9mY1JlcyAmJiBcIlwiICE9IG9wdGlvbnMub2ZjUmVzKSB7XG4gICAgICBmdWxsUGFnZU9wdGlvbnMucmVzcG9uc2l2ZVdpZHRoID0gb3B0aW9ucy5vZmNSZXM7XG4gICAgfVxuXG4gICAgLy8gSWYgbmF2aWdhdGlvblxuICAgIGlmIChcImVuYWJsZVwiID09IG9wdGlvbnMub2ZjTmF2KSB7XG4gICAgICAvLyBBbmNob3JzIGFuZCB0b29sdGlwc1xuICAgICAgY29uc3QgYW5jaG9ycyA9IFtdO1xuICAgICAgY29uc3QgbmF2VG9vbHRpcHMgPSBbXTtcblxuICAgICAgc2VjdGlvbnMuZm9yRWFjaCh0b3BTZWN0aW9uID0+IHtcbiAgICAgICAgbGV0IHNlY3Rpb25JRCA9IHRvcFNlY3Rpb24uaWQucmVwbGFjZShcIiNcIiwgXCJcIik7XG5cbiAgICAgICAgaWYgKHNlY3Rpb25JRCkge1xuICAgICAgICAgIGFuY2hvcnMucHVzaChzZWN0aW9uSUQpO1xuICAgICAgICAgIG5hdlRvb2x0aXBzLnB1c2goc2VjdGlvbklELnJlcGxhY2UoL1tcXC1fXS9nLCBcIiBcIikpOyAvLyBSZXBsYWNlIGh5cGhlbnMgd2l0aCBzcGFjZSBpbiB0b29sdGlwc1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGFuY2hvcnMucHVzaChcIiBcIik7XG4gICAgICAgICAgbmF2VG9vbHRpcHMucHVzaChcIiBcIik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICAvLyBBZGQgYW5jaG9ycyBhbmQgdG9vbHRpcHMgdG8gZnVsbFBhZ2VPcHRpb25zXG4gICAgICBmdWxsUGFnZU9wdGlvbnMuYW5jaG9ycyA9IGFuY2hvcnM7XG5cbiAgICAgIC8vIFNldHRpbmdzXG4gICAgICBmdWxsUGFnZU9wdGlvbnMubWVudSA9IFwiI2ZwLW5hdlwiO1xuICAgICAgZnVsbFBhZ2VPcHRpb25zLm5hdmlnYXRpb24gPSB0cnVlO1xuICAgICAgZnVsbFBhZ2VPcHRpb25zLm5hdmlnYXRpb25Qb3NpdGlvbiA9IG9wdGlvbnMub2ZjTmF2UG9zO1xuICAgICAgZnVsbFBhZ2VPcHRpb25zLm5hdmlnYXRpb25Ub29sdGlwcyA9IG5hdlRvb2x0aXBzO1xuICAgIH1cblxuICAgIHJldHVybiBmdWxsUGFnZU9wdGlvbnM7XG4gIH1cblxuICBzZXRGdWxsUGFnZU5hdkNvbG9yKHNlY3Rpb24pIHtcbiAgICBmb3IgKGNvbnN0IHNlY3Rpb25DaGlsZCBvZiBzZWN0aW9uLmNoaWxkcmVuKSB7XG4gICAgICB0aGlzLmVsZW1lbnRzLmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcIm9mYy1saWdodC1uYXZcIik7XG4gICAgICB0aGlzLmVsZW1lbnRzLmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcIm9mYy1kYXJrLW5hdlwiKTtcblxuICAgICAgY29uc3QgY2hpbGRyZW4gPSBzZWN0aW9uQ2hpbGQuY2hpbGRyZW47XG5cbiAgICAgIGNvbnN0IGxpZ2h0U2VjdGlvbiA9IEFycmF5LmZyb20oY2hpbGRyZW4pLnNvbWUoXG4gICAgICAgICh7IGNsYXNzTGlzdCB9KSA9PlxuICAgICAgICAgIGNsYXNzTGlzdC5jb250YWlucyhcImVsZW1lbnRvci10b3Atc2VjdGlvblwiKSAmJlxuICAgICAgICAgIGNsYXNzTGlzdC5jb250YWlucyhcImxpZ2h0XCIpXG4gICAgICApO1xuXG4gICAgICBpZiAobGlnaHRTZWN0aW9uKSB7XG4gICAgICAgIHRoaXMuZWxlbWVudHMuYm9keS5jbGFzc0xpc3QuYWRkKFwib2ZjLWxpZ2h0LW5hdlwiKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGRhcmtTZWN0aW9uID0gQXJyYXkuZnJvbShjaGlsZHJlbikuc29tZShcbiAgICAgICAgKHsgY2xhc3NMaXN0IH0pID0+XG4gICAgICAgICAgY2xhc3NMaXN0LmNvbnRhaW5zKFwiZWxlbWVudG9yLXRvcC1zZWN0aW9uXCIpICYmXG4gICAgICAgICAgY2xhc3NMaXN0LmNvbnRhaW5zKFwiZGFya1wiKVxuICAgICAgKTtcblxuICAgICAgaWYgKGRhcmtTZWN0aW9uKSB7XG4gICAgICAgIHRoaXMuZWxlbWVudHMuYm9keS5jbGFzc0xpc3QuYWRkKFwib2ZjLWRhcmstbmF2XCIpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpc0VsZW1lbnRvckVkaXRvclBhZ2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudHMuYm9keS5jbGFzc0xpc3QuY29udGFpbnMoXCJlbGVtZW50b3ItZWRpdG9yLWFjdGl2ZVwiKTtcbiAgfVxufVxuXG4oXCJ1c2Ugc2NyaXB0XCIpO1xud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsICgpID0+IHtcbiAgbmV3IE9XX0Z1bGxTY3JlZW4oKTtcbn0pO1xuIl19
