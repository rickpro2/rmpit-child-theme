<?php return array('dependencies' => array(), 'version' => 'dcfa4600384df04659c8');
