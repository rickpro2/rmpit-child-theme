<?php return array('dependencies' => array('react', 'react-dom', 'wp-components', 'wp-data', 'wp-element', 'wp-primitives'), 'version' => 'cd8dfcf3a1a440c25907');
