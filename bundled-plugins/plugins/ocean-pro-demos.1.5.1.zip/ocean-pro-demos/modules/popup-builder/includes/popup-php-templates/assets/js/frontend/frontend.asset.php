<?php return array('dependencies' => array('react'), 'version' => '081736faac93608a05e1');
