<?php return array('dependencies' => array(), 'version' => 'f7887b782cfeb19401c0');
