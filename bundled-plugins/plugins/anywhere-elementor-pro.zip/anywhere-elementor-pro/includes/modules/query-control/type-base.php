<?php

namespace Aepro\Modules\QueryControl;

abstract class TypeBase {


	public function get_name() {
	}

	public function get_autocomplete_values( array $data ) {
	}

	public function get_value_titles( array $request ) {
	}
}
