<?php
namespace Aepro\Modules\PostBlocksAdv\Classes;

use Aepro\Classes\QueryMaster;

class Query extends QueryMaster {

	public $filter_slug = 'post-blocks-adv';

}
