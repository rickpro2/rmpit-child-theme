/**
 * External dependencies
 */
import styled from '@emotion/styled';

export const StyledModulePanelContainer = styled.div`
	padding: 1.5rem;
`;
