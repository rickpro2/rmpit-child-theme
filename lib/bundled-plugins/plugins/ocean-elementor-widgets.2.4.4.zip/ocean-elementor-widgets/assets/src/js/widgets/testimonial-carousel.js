import { registerWidget } from "../lib/utils";
import OEW_Carousel from "./base/carousel";

class OEW_TestimonialCarousel extends OEW_Carousel {}

registerWidget(OEW_TestimonialCarousel, "oew-testimonial-carousel");
