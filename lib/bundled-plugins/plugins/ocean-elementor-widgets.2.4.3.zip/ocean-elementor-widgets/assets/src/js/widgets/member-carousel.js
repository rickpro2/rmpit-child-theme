import { registerWidget } from "../lib/utils";
import OEW_Carousel from "./base/carousel";

class OEW_MemberCarousel extends OEW_Carousel {}

registerWidget(OEW_MemberCarousel, "oew-member-carousel");
