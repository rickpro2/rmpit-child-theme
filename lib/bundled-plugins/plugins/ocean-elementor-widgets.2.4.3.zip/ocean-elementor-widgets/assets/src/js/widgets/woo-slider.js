import { registerWidget } from "../lib/utils";
import OEW_Carousel from "./base/carousel";

class OEW_WooSlider extends OEW_Carousel {}

registerWidget(OEW_WooSlider, "oew-woo-slider");
