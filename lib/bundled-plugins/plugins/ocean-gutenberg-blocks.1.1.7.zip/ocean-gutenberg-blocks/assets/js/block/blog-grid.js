(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = require('./util');

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ResponsiveAutoHeight = function () {
  function ResponsiveAutoHeight(selector, options) {
    var _this = this;

    _classCallCheck(this, ResponsiveAutoHeight);

    this.selector = selector;
    this.elements = typeof selector === 'string' ? document.querySelectorAll(selector) : selector;
    this.options = options;
    window.addEventListener('resize', function () {
      _this.run();
    });
    this.run();
  }

  _createClass(ResponsiveAutoHeight, [{
    key: 'recalc',
    value: function recalc() {
      this.elements = document.querySelectorAll(this.selector);
      this.run();
    }
  }, {
    key: 'makeGroups',
    value: function makeGroups(elements) {
      var group = [];
      [].forEach.call(elements, function (element) {
        element.style.height = '1px';
        element.style.overflow = 'hidden';
      });
      var idx = 0;
      var height = (0, _util.getOffset)(elements[0]).top;
      group[0] = [];
      [].forEach.call(elements, function (element) {
        if ((0, _util.getOffset)(element).top !== height) {
          height = (0, _util.getOffset)(element).top;
          idx += 1;
          group[idx] = [];
        }
        group[idx].push(element);
      });
      [].forEach.call(elements, function (element) {
        element.style.height = '';
        element.style.overflow = '';
      });
      return group;
    }
  }, {
    key: 'autoHeight',
    value: function autoHeight(group) {
      var heights = group.map(function (element) {
        var computedStyle = getComputedStyle(element);
        var boxSizing = computedStyle.boxSizing;
        if (boxSizing === 'border-box') {
          return element.offsetHeight;
        }
        return element.offsetHeight - parseFloat(computedStyle.paddingTop) - parseFloat(computedStyle.paddingBottom);
      });
      var maxHeight = Math.max.apply(Math, _toConsumableArray(heights));
      group.forEach(function (element) {
        element.style.height = maxHeight + 'px';
      });
    }
  }, {
    key: 'run',
    value: function run() {
      var _this2 = this;

      var elements = this.elements;

      var groups = this.makeGroups(elements);
      groups.forEach(function (group) {
        _this2.autoHeight(group);
      });
    }
  }]);

  return ResponsiveAutoHeight;
}();

exports.default = ResponsiveAutoHeight;
module.exports = exports['default'];
},{"./util":2}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var getScrollTop = function getScrollTop() {
  return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
};

var getScrollLeft = function getScrollLeft() {
  return window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0;
};

var getOffset = exports.getOffset = function getOffset(el) {
  var rect = el.getBoundingClientRect();
  return {
    top: rect.top + getScrollTop(),
    left: rect.left + getScrollLeft()
  };
};
},{}],3:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classPrivateFieldInitSpec(obj, privateMap, value) { _checkPrivateRedeclaration(obj, privateMap); privateMap.set(obj, value); }

function _checkPrivateRedeclaration(obj, privateCollection) { if (privateCollection.has(obj)) { throw new TypeError("Cannot initialize the same private elements twice on an object"); } }

function _classPrivateFieldGet(receiver, privateMap) { var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "get"); return _classApplyDescriptorGet(receiver, descriptor); }

function _classApplyDescriptorGet(receiver, descriptor) { if (descriptor.get) { return descriptor.get.call(receiver); } return descriptor.value; }

function _classPrivateFieldSet(receiver, privateMap, value) { var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "set"); _classApplyDescriptorSet(receiver, descriptor, value); return value; }

function _classExtractFieldDescriptor(receiver, privateMap, action) { if (!privateMap.has(receiver)) { throw new TypeError("attempted to " + action + " private field on non-instance"); } return privateMap.get(receiver); }

function _classApplyDescriptorSet(receiver, descriptor, value) { if (descriptor.set) { descriptor.set.call(receiver, value); } else { if (!descriptor.writable) { throw new TypeError("attempted to set read only private field"); } descriptor.value = value; } }

var _settings = /*#__PURE__*/new WeakMap();

var OW_Base = /*#__PURE__*/function () {
  function OW_Base() {
    _classCallCheck(this, OW_Base);

    _classPrivateFieldInitSpec(this, _settings, {
      writable: true,
      value: void 0
    });

    _defineProperty(this, "elements", void 0);

    this.onInit();
    this.bindEvents();
  }

  _createClass(OW_Base, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      return {};
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      return {};
    }
  }, {
    key: "onInit",
    value: function onInit() {
      _classPrivateFieldSet(this, _settings, this.getDefaultSettings());

      this.elements = this.getDefaultElements();
    }
  }, {
    key: "bindEvents",
    value: function bindEvents() {}
  }, {
    key: "getSettings",
    value: function getSettings() {
      var key = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (!!key) {
        return _classPrivateFieldGet(this, _settings)[key];
      }

      return _classPrivateFieldGet(this, _settings);
    }
  }, {
    key: "setSettings",
    value: function setSettings() {
      var settings = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      if (!settings) {
        return;
      }

      _classPrivateFieldSet(this, _settings, Object.assign(_classPrivateFieldGet(this, _settings), settings));
    }
  }]);

  return OW_Base;
}();

var _default = OW_Base;
exports["default"] = _default;

},{}],4:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

var _responsiveAutoHeight = _interopRequireDefault(require("responsive-auto-height"));

var _base = _interopRequireDefault(require("./base"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _get() { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get.bind(); } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(arguments.length < 3 ? target : receiver); } return desc.value; }; } return _get.apply(this, arguments); }

function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var OGB_BlogGridBlock = /*#__PURE__*/function (_OW_Base) {
  _inherits(OGB_BlogGridBlock, _OW_Base);

  var _super = _createSuper(OGB_BlogGridBlock);

  function OGB_BlogGridBlock() {
    _classCallCheck(this, OGB_BlogGridBlock);

    return _super.apply(this, arguments);
  }

  _createClass(OGB_BlogGridBlock, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      return {
        selectors: {
          blogGrid: ".ogb-blog-grid",
          blogMasonry: ".ogb-blog-grid.ogb-masonry"
        },
        options: oceanwpLocalize
      };
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      var selectors = this.getSettings("selectors");
      return {
        blogGrid: document.querySelectorAll(selectors.blogGrid),
        blogMasonry: document.querySelectorAll(selectors.blogMasonry)
      };
    }
  }, {
    key: "onInit",
    value: function onInit() {
      var _get2;

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      (_get2 = _get(_getPrototypeOf(OGB_BlogGridBlock.prototype), "onInit", this)).call.apply(_get2, [this].concat(args));

      if (this.isMasonry()) {
        this.initMasonry();
      }

      if (this.isEqualHeight()) {
        this.initEqualHeight();
      }
    }
  }, {
    key: "initMasonry",
    value: function initMasonry() {
      var _this$elements$blogMa;

      var options = this.getSettings("options");
      (_this$elements$blogMa = this.elements.blogMasonry) === null || _this$elements$blogMa === void 0 ? void 0 : _this$elements$blogMa.forEach(function (blogMasonry) {
        imagesLoaded(blogMasonry, function (instance) {
          new Isotope(blogMasonry, {
            itemSelector: ".isotope-entry",
            transformsEnabled: true,
            isOriginLeft: options.isRTL ? false : true,
            transitionDuration: 0
          });
        });
      });
    }
  }, {
    key: "initEqualHeight",
    value: function initEqualHeight() {
      var blogGridItemsSelector = "".concat(this.getSettings("selectors").blogGrid, " .ogb-grid-inner");
      new _responsiveAutoHeight["default"](blogGridItemsSelector);
    }
  }, {
    key: "isMasonry",
    value: function isMasonry() {
      if (document.body.classList.contains("no-isotope")) {
        return false;
      }

      return this.elements.blogMasonry.length > 0;
    }
  }, {
    key: "isEqualHeight",
    value: function isEqualHeight() {
      return Array.from(this.elements.blogGrid).some(function (_ref) {
        var classList = _ref.classList;
        return classList.contains("match-height-grid");
      });
    }
  }]);

  return OGB_BlogGridBlock;
}(_base["default"]);

document.addEventListener("DOMContentLoaded", function () {
  new OGB_BlogGridBlock();
});

},{"./base":3,"responsive-auto-height":1}]},{},[4])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJub2RlX21vZHVsZXMvcmVzcG9uc2l2ZS1hdXRvLWhlaWdodC9saWIvaW5kZXguanMiLCJub2RlX21vZHVsZXMvcmVzcG9uc2l2ZS1hdXRvLWhlaWdodC9saWIvdXRpbC5qcyIsInNyYy9ibG9jay1qcy9iYXNlLmpzIiwic3JjL2Jsb2NrLWpzL2Jsb2ctZ3JpZC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQ25CTSxPO0VBSUYsbUJBQWM7SUFBQTs7SUFBQTtNQUFBO01BQUE7SUFBQTs7SUFBQTs7SUFDVixLQUFLLE1BQUw7SUFDQSxLQUFLLFVBQUw7RUFDSDs7OztXQUVELDhCQUFxQjtNQUNqQixPQUFPLEVBQVA7SUFDSDs7O1dBRUQsOEJBQXFCO01BQ2pCLE9BQU8sRUFBUDtJQUNIOzs7V0FFRCxrQkFBUztNQUNMLHVDQUFpQixLQUFLLGtCQUFMLEVBQWpCOztNQUNBLEtBQUssUUFBTCxHQUFnQixLQUFLLGtCQUFMLEVBQWhCO0lBQ0g7OztXQUVELHNCQUFhLENBQUU7OztXQUVmLHVCQUF3QjtNQUFBLElBQVosR0FBWSx1RUFBTixJQUFNOztNQUNwQixJQUFJLENBQUMsQ0FBQyxHQUFOLEVBQVc7UUFDUCxPQUFPLHVDQUFlLEdBQWYsQ0FBUDtNQUNIOztNQUVELDZCQUFPLElBQVA7SUFDSDs7O1dBRUQsdUJBQTJCO01BQUEsSUFBZixRQUFlLHVFQUFKLEVBQUk7O01BQ3ZCLElBQUksQ0FBQyxRQUFMLEVBQWU7UUFDWDtNQUNIOztNQUVELHVDQUFpQixNQUFNLENBQUMsTUFBUCx1QkFBYyxJQUFkLGNBQThCLFFBQTlCLENBQWpCO0lBQ0g7Ozs7OztlQUdVLE87Ozs7Ozs7O0FDekNmOztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBRU0saUI7Ozs7Ozs7Ozs7Ozs7V0FDRiw4QkFBcUI7TUFDakIsT0FBTztRQUNILFNBQVMsRUFBRTtVQUNQLFFBQVEsRUFBRSxnQkFESDtVQUVQLFdBQVcsRUFBRTtRQUZOLENBRFI7UUFLSCxPQUFPLEVBQUU7TUFMTixDQUFQO0lBT0g7OztXQUVELDhCQUFxQjtNQUNqQixJQUFNLFNBQVMsR0FBRyxLQUFLLFdBQUwsQ0FBaUIsV0FBakIsQ0FBbEI7TUFFQSxPQUFPO1FBQ0gsUUFBUSxFQUFFLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQixTQUFTLENBQUMsUUFBcEMsQ0FEUDtRQUVILFdBQVcsRUFBRSxRQUFRLENBQUMsZ0JBQVQsQ0FBMEIsU0FBUyxDQUFDLFdBQXBDO01BRlYsQ0FBUDtJQUlIOzs7V0FFRCxrQkFBZ0I7TUFBQTs7TUFBQSxrQ0FBTixJQUFNO1FBQU4sSUFBTTtNQUFBOztNQUNaLDZHQUFnQixJQUFoQjs7TUFFQSxJQUFJLEtBQUssU0FBTCxFQUFKLEVBQXNCO1FBQ2xCLEtBQUssV0FBTDtNQUNIOztNQUVELElBQUksS0FBSyxhQUFMLEVBQUosRUFBMEI7UUFDdEIsS0FBSyxlQUFMO01BQ0g7SUFDSjs7O1dBRUQsdUJBQWM7TUFBQTs7TUFDVixJQUFNLE9BQU8sR0FBRyxLQUFLLFdBQUwsQ0FBaUIsU0FBakIsQ0FBaEI7TUFFQSw4QkFBSyxRQUFMLENBQWMsV0FBZCxnRkFBMkIsT0FBM0IsQ0FBbUMsVUFBQyxXQUFELEVBQWlCO1FBQ2hELFlBQVksQ0FBQyxXQUFELEVBQWMsVUFBQyxRQUFELEVBQWM7VUFDcEMsSUFBSSxPQUFKLENBQVksV0FBWixFQUF5QjtZQUNyQixZQUFZLEVBQUUsZ0JBRE87WUFFckIsaUJBQWlCLEVBQUUsSUFGRTtZQUdyQixZQUFZLEVBQUUsT0FBTyxDQUFDLEtBQVIsR0FBZ0IsS0FBaEIsR0FBd0IsSUFIakI7WUFJckIsa0JBQWtCLEVBQUU7VUFKQyxDQUF6QjtRQU1ILENBUFcsQ0FBWjtNQVFILENBVEQ7SUFVSDs7O1dBRUQsMkJBQWtCO01BQ2QsSUFBTSxxQkFBcUIsYUFBTSxLQUFLLFdBQUwsQ0FBaUIsV0FBakIsRUFBOEIsUUFBcEMscUJBQTNCO01BRUEsSUFBSSxnQ0FBSixDQUF5QixxQkFBekI7SUFDSDs7O1dBRUQscUJBQVk7TUFDUixJQUFJLFFBQVEsQ0FBQyxJQUFULENBQWMsU0FBZCxDQUF3QixRQUF4QixDQUFpQyxZQUFqQyxDQUFKLEVBQW9EO1FBQ2hELE9BQU8sS0FBUDtNQUNIOztNQUVELE9BQU8sS0FBSyxRQUFMLENBQWMsV0FBZCxDQUEwQixNQUExQixHQUFtQyxDQUExQztJQUNIOzs7V0FFRCx5QkFBZ0I7TUFDWixPQUFPLEtBQUssQ0FBQyxJQUFOLENBQVcsS0FBSyxRQUFMLENBQWMsUUFBekIsRUFBbUMsSUFBbkMsQ0FBd0M7UUFBQSxJQUFHLFNBQUgsUUFBRyxTQUFIO1FBQUEsT0FBbUIsU0FBUyxDQUFDLFFBQVYsQ0FBbUIsbUJBQW5CLENBQW5CO01BQUEsQ0FBeEMsQ0FBUDtJQUNIOzs7O0VBL0QyQixnQjs7QUFrRWhDLFFBQVEsQ0FBQyxnQkFBVCxDQUEwQixrQkFBMUIsRUFBOEMsWUFBTTtFQUNoRCxJQUFJLGlCQUFKO0FBQ0gsQ0FGRCIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uKCl7ZnVuY3Rpb24gcihlLG4sdCl7ZnVuY3Rpb24gbyhpLGYpe2lmKCFuW2ldKXtpZighZVtpXSl7dmFyIGM9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZTtpZighZiYmYylyZXR1cm4gYyhpLCEwKTtpZih1KXJldHVybiB1KGksITApO3ZhciBhPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIraStcIidcIik7dGhyb3cgYS5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGF9dmFyIHA9bltpXT17ZXhwb3J0czp7fX07ZVtpXVswXS5jYWxsKHAuZXhwb3J0cyxmdW5jdGlvbihyKXt2YXIgbj1lW2ldWzFdW3JdO3JldHVybiBvKG58fHIpfSxwLHAuZXhwb3J0cyxyLGUsbix0KX1yZXR1cm4gbltpXS5leHBvcnRzfWZvcih2YXIgdT1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlLGk9MDtpPHQubGVuZ3RoO2krKylvKHRbaV0pO3JldHVybiBvfXJldHVybiByfSkoKSIsIid1c2Ugc3RyaWN0JztcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcblxudmFyIF9jcmVhdGVDbGFzcyA9IGZ1bmN0aW9uICgpIHsgZnVuY3Rpb24gZGVmaW5lUHJvcGVydGllcyh0YXJnZXQsIHByb3BzKSB7IGZvciAodmFyIGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHsgdmFyIGRlc2NyaXB0b3IgPSBwcm9wc1tpXTsgZGVzY3JpcHRvci5lbnVtZXJhYmxlID0gZGVzY3JpcHRvci5lbnVtZXJhYmxlIHx8IGZhbHNlOyBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSA9IHRydWU7IGlmIChcInZhbHVlXCIgaW4gZGVzY3JpcHRvcikgZGVzY3JpcHRvci53cml0YWJsZSA9IHRydWU7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGRlc2NyaXB0b3Iua2V5LCBkZXNjcmlwdG9yKTsgfSB9IHJldHVybiBmdW5jdGlvbiAoQ29uc3RydWN0b3IsIHByb3RvUHJvcHMsIHN0YXRpY1Byb3BzKSB7IGlmIChwcm90b1Byb3BzKSBkZWZpbmVQcm9wZXJ0aWVzKENvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvdG9Qcm9wcyk7IGlmIChzdGF0aWNQcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvciwgc3RhdGljUHJvcHMpOyByZXR1cm4gQ29uc3RydWN0b3I7IH07IH0oKTtcblxudmFyIF91dGlsID0gcmVxdWlyZSgnLi91dGlsJyk7XG5cbmZ1bmN0aW9uIF90b0NvbnN1bWFibGVBcnJheShhcnIpIHsgaWYgKEFycmF5LmlzQXJyYXkoYXJyKSkgeyBmb3IgKHZhciBpID0gMCwgYXJyMiA9IEFycmF5KGFyci5sZW5ndGgpOyBpIDwgYXJyLmxlbmd0aDsgaSsrKSB7IGFycjJbaV0gPSBhcnJbaV07IH0gcmV0dXJuIGFycjI7IH0gZWxzZSB7IHJldHVybiBBcnJheS5mcm9tKGFycik7IH0gfVxuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb25cIik7IH0gfVxuXG52YXIgUmVzcG9uc2l2ZUF1dG9IZWlnaHQgPSBmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIFJlc3BvbnNpdmVBdXRvSGVpZ2h0KHNlbGVjdG9yLCBvcHRpb25zKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBSZXNwb25zaXZlQXV0b0hlaWdodCk7XG5cbiAgICB0aGlzLnNlbGVjdG9yID0gc2VsZWN0b3I7XG4gICAgdGhpcy5lbGVtZW50cyA9IHR5cGVvZiBzZWxlY3RvciA9PT0gJ3N0cmluZycgPyBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKSA6IHNlbGVjdG9yO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgIF90aGlzLnJ1bigpO1xuICAgIH0pO1xuICAgIHRoaXMucnVuKCk7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoUmVzcG9uc2l2ZUF1dG9IZWlnaHQsIFt7XG4gICAga2V5OiAncmVjYWxjJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVjYWxjKCkge1xuICAgICAgdGhpcy5lbGVtZW50cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGhpcy5zZWxlY3Rvcik7XG4gICAgICB0aGlzLnJ1bigpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ21ha2VHcm91cHMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBtYWtlR3JvdXBzKGVsZW1lbnRzKSB7XG4gICAgICB2YXIgZ3JvdXAgPSBbXTtcbiAgICAgIFtdLmZvckVhY2guY2FsbChlbGVtZW50cywgZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSAnMXB4JztcbiAgICAgICAgZWxlbWVudC5zdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xuICAgICAgfSk7XG4gICAgICB2YXIgaWR4ID0gMDtcbiAgICAgIHZhciBoZWlnaHQgPSAoMCwgX3V0aWwuZ2V0T2Zmc2V0KShlbGVtZW50c1swXSkudG9wO1xuICAgICAgZ3JvdXBbMF0gPSBbXTtcbiAgICAgIFtdLmZvckVhY2guY2FsbChlbGVtZW50cywgZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgICAgICAgaWYgKCgwLCBfdXRpbC5nZXRPZmZzZXQpKGVsZW1lbnQpLnRvcCAhPT0gaGVpZ2h0KSB7XG4gICAgICAgICAgaGVpZ2h0ID0gKDAsIF91dGlsLmdldE9mZnNldCkoZWxlbWVudCkudG9wO1xuICAgICAgICAgIGlkeCArPSAxO1xuICAgICAgICAgIGdyb3VwW2lkeF0gPSBbXTtcbiAgICAgICAgfVxuICAgICAgICBncm91cFtpZHhdLnB1c2goZWxlbWVudCk7XG4gICAgICB9KTtcbiAgICAgIFtdLmZvckVhY2guY2FsbChlbGVtZW50cywgZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSAnJztcbiAgICAgICAgZWxlbWVudC5zdHlsZS5vdmVyZmxvdyA9ICcnO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gZ3JvdXA7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnYXV0b0hlaWdodCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGF1dG9IZWlnaHQoZ3JvdXApIHtcbiAgICAgIHZhciBoZWlnaHRzID0gZ3JvdXAubWFwKGZ1bmN0aW9uIChlbGVtZW50KSB7XG4gICAgICAgIHZhciBjb21wdXRlZFN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbiAgICAgICAgdmFyIGJveFNpemluZyA9IGNvbXB1dGVkU3R5bGUuYm94U2l6aW5nO1xuICAgICAgICBpZiAoYm94U2l6aW5nID09PSAnYm9yZGVyLWJveCcpIHtcbiAgICAgICAgICByZXR1cm4gZWxlbWVudC5vZmZzZXRIZWlnaHQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGVsZW1lbnQub2Zmc2V0SGVpZ2h0IC0gcGFyc2VGbG9hdChjb21wdXRlZFN0eWxlLnBhZGRpbmdUb3ApIC0gcGFyc2VGbG9hdChjb21wdXRlZFN0eWxlLnBhZGRpbmdCb3R0b20pO1xuICAgICAgfSk7XG4gICAgICB2YXIgbWF4SGVpZ2h0ID0gTWF0aC5tYXguYXBwbHkoTWF0aCwgX3RvQ29uc3VtYWJsZUFycmF5KGhlaWdodHMpKTtcbiAgICAgIGdyb3VwLmZvckVhY2goZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5oZWlnaHQgPSBtYXhIZWlnaHQgKyAncHgnO1xuICAgICAgfSk7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAncnVuJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcnVuKCkge1xuICAgICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICAgIHZhciBlbGVtZW50cyA9IHRoaXMuZWxlbWVudHM7XG5cbiAgICAgIHZhciBncm91cHMgPSB0aGlzLm1ha2VHcm91cHMoZWxlbWVudHMpO1xuICAgICAgZ3JvdXBzLmZvckVhY2goZnVuY3Rpb24gKGdyb3VwKSB7XG4gICAgICAgIF90aGlzMi5hdXRvSGVpZ2h0KGdyb3VwKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBSZXNwb25zaXZlQXV0b0hlaWdodDtcbn0oKTtcblxuZXhwb3J0cy5kZWZhdWx0ID0gUmVzcG9uc2l2ZUF1dG9IZWlnaHQ7XG5tb2R1bGUuZXhwb3J0cyA9IGV4cG9ydHNbJ2RlZmF1bHQnXTsiLCJcInVzZSBzdHJpY3RcIjtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcbnZhciBnZXRTY3JvbGxUb3AgPSBmdW5jdGlvbiBnZXRTY3JvbGxUb3AoKSB7XG4gIHJldHVybiB3aW5kb3cucGFnZVlPZmZzZXQgfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbFRvcCB8fCBkb2N1bWVudC5ib2R5LnNjcm9sbFRvcCB8fCAwO1xufTtcblxudmFyIGdldFNjcm9sbExlZnQgPSBmdW5jdGlvbiBnZXRTY3JvbGxMZWZ0KCkge1xuICByZXR1cm4gd2luZG93LnBhZ2VYT2Zmc2V0IHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxMZWZ0IHx8IGRvY3VtZW50LmJvZHkuc2Nyb2xsTGVmdCB8fCAwO1xufTtcblxudmFyIGdldE9mZnNldCA9IGV4cG9ydHMuZ2V0T2Zmc2V0ID0gZnVuY3Rpb24gZ2V0T2Zmc2V0KGVsKSB7XG4gIHZhciByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIHJldHVybiB7XG4gICAgdG9wOiByZWN0LnRvcCArIGdldFNjcm9sbFRvcCgpLFxuICAgIGxlZnQ6IHJlY3QubGVmdCArIGdldFNjcm9sbExlZnQoKVxuICB9O1xufTsiLCJjbGFzcyBPV19CYXNlIHtcbiAgICAjc2V0dGluZ3M7XG4gICAgZWxlbWVudHM7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5vbkluaXQoKTtcbiAgICAgICAgdGhpcy5iaW5kRXZlbnRzKCk7XG4gICAgfVxuXG4gICAgZ2V0RGVmYXVsdFNldHRpbmdzKCkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgZ2V0RGVmYXVsdEVsZW1lbnRzKCkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgb25Jbml0KCkge1xuICAgICAgICB0aGlzLiNzZXR0aW5ncyA9IHRoaXMuZ2V0RGVmYXVsdFNldHRpbmdzKCk7XG4gICAgICAgIHRoaXMuZWxlbWVudHMgPSB0aGlzLmdldERlZmF1bHRFbGVtZW50cygpO1xuICAgIH1cblxuICAgIGJpbmRFdmVudHMoKSB7fVxuXG4gICAgZ2V0U2V0dGluZ3Moa2V5ID0gbnVsbCkge1xuICAgICAgICBpZiAoISFrZXkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLiNzZXR0aW5nc1trZXldO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuI3NldHRpbmdzO1xuICAgIH1cblxuICAgIHNldFNldHRpbmdzKHNldHRpbmdzID0ge30pIHtcbiAgICAgICAgaWYgKCFzZXR0aW5ncykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy4jc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHRoaXMuI3NldHRpbmdzLCBzZXR0aW5ncyk7XG4gICAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBPV19CYXNlO1xuIiwiaW1wb3J0IFJlc3BvbnNpdmVBdXRvSGVpZ2h0IGZyb20gXCJyZXNwb25zaXZlLWF1dG8taGVpZ2h0XCI7XHJcbmltcG9ydCBPV19CYXNlIGZyb20gXCIuL2Jhc2VcIjtcclxuXHJcbmNsYXNzIE9HQl9CbG9nR3JpZEJsb2NrIGV4dGVuZHMgT1dfQmFzZSB7XHJcbiAgICBnZXREZWZhdWx0U2V0dGluZ3MoKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc2VsZWN0b3JzOiB7XHJcbiAgICAgICAgICAgICAgICBibG9nR3JpZDogXCIub2diLWJsb2ctZ3JpZFwiLFxyXG4gICAgICAgICAgICAgICAgYmxvZ01hc29ucnk6IFwiLm9nYi1ibG9nLWdyaWQub2diLW1hc29ucnlcIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3B0aW9uczogb2NlYW53cExvY2FsaXplLFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0RGVmYXVsdEVsZW1lbnRzKCkge1xyXG4gICAgICAgIGNvbnN0IHNlbGVjdG9ycyA9IHRoaXMuZ2V0U2V0dGluZ3MoXCJzZWxlY3RvcnNcIik7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGJsb2dHcmlkOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9ycy5ibG9nR3JpZCksXHJcbiAgICAgICAgICAgIGJsb2dNYXNvbnJ5OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9ycy5ibG9nTWFzb25yeSksXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBvbkluaXQoLi4uYXJncykge1xyXG4gICAgICAgIHN1cGVyLm9uSW5pdCguLi5hcmdzKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuaXNNYXNvbnJ5KCkpIHtcclxuICAgICAgICAgICAgdGhpcy5pbml0TWFzb25yeSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuaXNFcXVhbEhlaWdodCgpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW5pdEVxdWFsSGVpZ2h0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGluaXRNYXNvbnJ5KCkge1xyXG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLmdldFNldHRpbmdzKFwib3B0aW9uc1wiKTtcclxuXHJcbiAgICAgICAgdGhpcy5lbGVtZW50cy5ibG9nTWFzb25yeT8uZm9yRWFjaCgoYmxvZ01hc29ucnkpID0+IHtcclxuICAgICAgICAgICAgaW1hZ2VzTG9hZGVkKGJsb2dNYXNvbnJ5LCAoaW5zdGFuY2UpID0+IHtcclxuICAgICAgICAgICAgICAgIG5ldyBJc290b3BlKGJsb2dNYXNvbnJ5LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbVNlbGVjdG9yOiBcIi5pc290b3BlLWVudHJ5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3Jtc0VuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgaXNPcmlnaW5MZWZ0OiBvcHRpb25zLmlzUlRMID8gZmFsc2UgOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb25EdXJhdGlvbjogMCxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBpbml0RXF1YWxIZWlnaHQoKSB7XHJcbiAgICAgICAgY29uc3QgYmxvZ0dyaWRJdGVtc1NlbGVjdG9yID0gYCR7dGhpcy5nZXRTZXR0aW5ncyhcInNlbGVjdG9yc1wiKS5ibG9nR3JpZH0gLm9nYi1ncmlkLWlubmVyYDtcclxuXHJcbiAgICAgICAgbmV3IFJlc3BvbnNpdmVBdXRvSGVpZ2h0KGJsb2dHcmlkSXRlbXNTZWxlY3Rvcik7XHJcbiAgICB9XHJcblxyXG4gICAgaXNNYXNvbnJ5KCkge1xyXG4gICAgICAgIGlmIChkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5jb250YWlucyhcIm5vLWlzb3RvcGVcIikpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZWxlbWVudHMuYmxvZ01hc29ucnkubGVuZ3RoID4gMDtcclxuICAgIH1cclxuXHJcbiAgICBpc0VxdWFsSGVpZ2h0KCkge1xyXG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKHRoaXMuZWxlbWVudHMuYmxvZ0dyaWQpLnNvbWUoKHsgY2xhc3NMaXN0IH0pID0+IGNsYXNzTGlzdC5jb250YWlucyhcIm1hdGNoLWhlaWdodC1ncmlkXCIpKTtcclxuICAgIH1cclxufVxyXG5cclxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwgKCkgPT4ge1xyXG4gICAgbmV3IE9HQl9CbG9nR3JpZEJsb2NrKCk7XHJcbn0pO1xyXG4iXX0=
