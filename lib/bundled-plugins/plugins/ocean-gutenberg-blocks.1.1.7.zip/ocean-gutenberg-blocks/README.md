# ocean-gutenberg-blocks

* **Contributors** - oceanwp, apprimit

A premium plugin to add magnificent and various blocks to the WordPress default Gutenberg editor. Enrich your blog posts or build stunning pages.
This plugin requires the [OceanWP](https://oceanwp.org/) theme to be installed.

== Installation ==

1. Upload `ocean-gutenberg-blocks` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Frequently Asked Questions ==

= I installed the plugin but it does not work =

This plugin will function only with the [OceanWP](https://oceanwp.org/) theme.
