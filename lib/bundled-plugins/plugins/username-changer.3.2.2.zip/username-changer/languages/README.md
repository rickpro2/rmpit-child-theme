# Username Changer

This folder contains translation files for Username Changer.

Do not store custom translations in this folder, they will be deleted on updates.
Store custom translations in `wp-content/languages/username-changer`.
